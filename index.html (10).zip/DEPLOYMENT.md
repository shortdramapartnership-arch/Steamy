# Deploying Steamy

## 1. Database

The app needs a PostgreSQL database. Create one on [Neon](https://neon.tech),
[Supabase](https://supabase.com) or any hosted Postgres, then add it in Netlify:

**Site configuration → Environment variables → Add a variable**

| Key | Value | Scopes |
| --- | --- | --- |
| `DATABASE_URL` | `postgresql://user:password@host/dbname?sslmode=require` | Builds, Functions |

The **build does not require the database** — `src/db/index.ts` creates the client
lazily on the first query, so `npm run build` succeeds with or without
`DATABASE_URL`. It is only needed at runtime.

## 2. Apply the schema

Run once from your machine against the production database:

```bash
DATABASE_URL="postgres://..." npx drizzle-kit push
```

## 3. Build

```bash
npm install
npm run build
```

`netlify.toml` already sets the build command, Node 20 and
`@netlify/plugin-nextjs`.

## 4. Dubbing engine

Dubbing runs in `worker/linly_dub.py`, built on
[Linly-Dubbing](https://github.com/Kedreamix/Linly-Dubbing):

- **ASR** — faster-whisper with word-level timestamps on the real audio
- **TTS** — Microsoft Edge neural voices (free, no API key)
- **Casting** — male characters get a male voice, female characters a female voice

Netlify Functions run Node only, so the Python worker cannot execute there. The
platform detects this and falls back to on-device neural voices, so nothing
breaks — but for the full Whisper + Edge-voice dubbing, deploy to a Node host
that allows a Python sidecar (Render, Railway, Fly.io, a VPS), or set
`DUB_WORKER_URL` to point at a small worker service.

Optional environment variables:

| Variable | Purpose |
| --- | --- |
| `DUB_PYTHON` | Python binary used for the worker (default `python3`) |
| `NEXT_PUBLIC_FIREBASE_API_KEY` | Override the Firebase API key |
| `NEXT_PUBLIC_FIREBASE_DB_URL` | Override the Realtime Database URL |
| `NEXT_PUBLIC_FIREBASE_MIRROR` | Set to `off` to disable RTDB mirroring |
| `OPENAI_API_KEY` | Optional OpenAI TTS fallback |
| `CRON_KEY` | Protects `/api/cron/autofetch` if set |

## 5. After the first deploy

Open the platform and click the small 🦅 in the footer to open the developer
console. There you can set the daily 4-digit code, subscription prices, payment
methods per country, the voice cast and the branding.
