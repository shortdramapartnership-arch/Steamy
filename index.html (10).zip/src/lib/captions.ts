import { db } from "@/db";
import { dubTracks, type DubCue } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { videoById } from "@/lib/ingest";
import { linlyTranscribe } from "@/lib/dubWorker";

/** Guards against two requests transcribing the same title at once. */
const inFlight = new Set<number>();

export type CaptionsState = {
  status: "ready" | "generating" | "failed";
  source?: string;
  language?: string;
  cues?: DubCue[];
  message?: string;
};

async function loadSourceCues(videoId: number): Promise<{ cues: DubCue[]; source: string } | null> {
  const rows = await db
    .select()
    .from(dubTracks)
    .where(and(eq(dubTracks.videoId, videoId), eq(dubTracks.lang, "src")))
    .limit(1);
  if (!rows[0]?.cues?.length) return null;
  return { cues: rows[0].cues, source: rows[0].source };
}

/**
 * YouTube-style caption generation: the first time a title is opened, its real
 * audio is transcribed with faster-whisper (the ASR stage of Linly-Dubbing) to
 * produce English captions with word-level timings. Every other language is
 * then dubbed from that same transcript, so the dub follows the original audio.
 */
export async function ensureEnglishTranscript(videoId: number, seconds = 150): Promise<CaptionsState> {
  const existing = await loadSourceCues(videoId);
  if (existing) return { status: "ready", source: existing.source, language: "en", cues: existing.cues };

  if (inFlight.has(videoId)) {
    return { status: "generating", message: "English captions are being generated from the original audio." };
  }

  const video = await videoById(videoId);
  if (!video) return { status: "failed", message: "Video not found." };

  inFlight.add(videoId);
  try {
    const result = await linlyTranscribe({ dmId: video.dmId, seconds, model: "base" });
    if (!result.ok || !result.utterances?.length) {
      return { status: "failed", message: "No speech was detected in this title." };
    }
    const cues: DubCue[] = result.utterances.map((u) => ({
      start: u.start,
      end: u.end,
      speaker: u.speaker,
      text: u.text,
      words: u.words,
    }));
    await db.insert(dubTracks).values({ videoId, lang: "src", source: "linly-asr", cues }).onConflictDoNothing();
    return { status: "ready", source: "linly-asr", language: result.language, cues };
  } catch (error) {
    return {
      status: "failed",
      message: error instanceof Error ? error.message : "Caption generation failed.",
    };
  } finally {
    inFlight.delete(videoId);
  }
}

/** Fire-and-forget caption generation used right after a title is added. */
export async function warmTranscript(videoId: number, seconds = 120) {
  try {
    await ensureEnglishTranscript(videoId, seconds);
  } catch {
    /* never block ingest on caption generation */
  }
}

export function describeCaptionSource(source?: string): string {
  if (!source) return "Auto-generated";
  if (source === "linly-asr") return "Auto-generated (Whisper) from the original audio";
  if (source === "dailymotion-subtitles") return "Official subtitle track";
  if (source === "manual-script") return "Uploaded script";
  return "AI dub script";
}
