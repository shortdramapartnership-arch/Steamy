export type ApiVideo = {
  id: number;
  dmId: string;
  title: string;
  description: string;
  thumbnail: string;
  url: string;
  duration: number;
  owner: string;
  category: string;
  tags: string[];
  language: string;
  views: number;
  trendingScore: number;
  featured: boolean;
  hidden: boolean;
  createdAt: string;
};

export type SearchItem = {
  id: number;
  dmId: string;
  title: string;
  thumbnail: string;
  duration: number;
  owner: string;
  category: string;
  views: number;
  inCatalog: boolean;
};

export type PublicSettings = {
  platformName: string;
  logoUrl: string;
  tagline: string;
  heroHeadline: string;
  heroSubline: string;
  accent: string;
  categories: string[];
  monthlyPrice: number;
  monthlyCurrency: string;
  freePreviewSeconds: number;
  freeAccessSteps: { title: string; body: string; ctaLabel: string; ctaUrl: string; proofLabel: string }[];
  appLinks: { label: string; url: string; icon: string }[];
  dubLanguages: string[];
  dailyCodeActive: boolean;
};

export type AccessInfo = {
  deviceId: string;
  level: "none" | "free" | "day" | "month";
  kind: string | null;
  label: string;
  expiresAt: string | null;
  hoursLeft: number;
  pendingPayment: { id: number; status: string; amount: string; currency: string; createdAt: string } | null;
};

export type ApiChannel = {
  id: number;
  platform: string;
  title: string;
  url: string;
  handle: string;
  thumbnail: string;
  description: string;
  stepOrder: number;
  active: boolean;
};

export type SessionUser = {
  id: number;
  provider: string;
  name: string;
  email: string;
  picture: string;
};

export type CatalogResponse = {
  settings: PublicSettings;
  access: AccessInfo;
  user: SessionUser | null;
  videos: ApiVideo[];
  channels: ApiChannel[];
  categoryCounts: { category: string; n: number }[];
};

export type DubCueDto = {
  start: number;
  end: number;
  speaker: string;
  text: string;
  translated?: string;
  words?: { w: string; t: number; d: number }[];
};
