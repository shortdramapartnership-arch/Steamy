import { db } from "@/db";
import { settings, videos } from "@/db/schema";
import { sql } from "drizzle-orm";
import { DEFAULT_SETTINGS, saveSettings } from "./settings";

let bootstrapped = false;

/**
 * Guarantees the settings row exists. Deliberately cheap: it never touches the
 * network and never seeds the catalog, so API routes stay fast enough for
 * serverless platforms such as Netlify where a function is killed after ~10s.
 */
export async function ensureBootstrap() {
  if (bootstrapped) return;
  try {
    const rows = await db.select({ id: settings.id }).from(settings).limit(1);
    if (!rows.length) await saveSettings(DEFAULT_SETTINGS);
    bootstrapped = true;
  } catch {
    /* a missing database must never break rendering */
  }
}

export async function countVideos() {
  try {
    const count = await db.select({ n: sql<number>`count(*)::int` }).from(videos);
    return count[0]?.n ?? 0;
  } catch {
    return 0;
  }
}

/** True when the catalog still needs its first fill. */
export async function catalogIsEmpty() {
  return (await countVideos()) < 6;
}
