import { db } from "@/db";
import { paymentMethods } from "@/db/schema";
import { COUNTRIES, methodByKey } from "./countries";

/** Rough local-currency units per 1 USD, used to pre-fill local prices. */
const PER_USD: Record<string, number> = {
  USD: 1, EUR: 0.92, GBP: 0.78, PKR: 278, INR: 84, BDT: 120, IDR: 15800, MYR: 4.7, PHP: 58, VND: 25400,
  THB: 36, CNY: 7.2, JPY: 152, KRW: 1380, TRY: 34, AED: 3.67, SAR: 3.75, EGP: 48, NGN: 1550, KES: 129,
  GHS: 15, ZAR: 18, MAD: 10, CAD: 1.37, BRL: 5.6, MXN: 18, ARS: 950, COP: 4100, PEN: 3.8, PLN: 4,
  RUB: 95, UAH: 41, UZS: 12700, AFN: 72, IQD: 1310, IRR: 42000, AUD: 1.52, NZD: 1.65, SGD: 1.34,
  HKD: 7.8, TWD: 32, NPR: 135, LKR: 300, MMK: 2100, KZT: 480, AZN: 1.7,
};

const round = (n: number) => (n >= 100 ? Math.round(n / 50) * 50 : n >= 20 ? Math.round(n) : Number(n.toFixed(2)));

/**
 * Pre-configures a sensible set of local payment rails for every supported
 * country the first time the platform boots. The developer can then edit each
 * country, its rails and the local price from the console.
 */
export async function seedPaymentMethods(defaultPrice: number) {
  const existing = await db.select({ id: paymentMethods.id }).from(paymentMethods).limit(1);
  if (existing.length) return 0;

  const rows: (typeof paymentMethods.$inferInsert)[] = [];
  for (const country of COUNTRIES) {
    const keys = [...new Set([...country.methods, "crypto"])];
    const rate = PER_USD[country.currency] ?? 1;
    const localPrice = round(defaultPrice * rate);
    let order = 0;
    for (const key of keys) {
      const def = methodByKey(key);
      if (!def) continue;
      const isCrypto = def.group === "crypto";
      rows.push({
        countryCode: country.code,
        methodKey: key,
        label: def.label,
        icon: def.icon,
        address: "",
        accountName: "",
        details: def.fields.map((label) => ({ label, value: "" })),
        instructions: isCrypto
          ? "Send the exact amount, then upload a screenshot of the transaction hash or wallet confirmation."
          : `Send ${country.currency} ${localPrice} to the account above, then upload the receipt screenshot.`,
        amount: String(isCrypto ? defaultPrice : localPrice),
        currency: isCrypto ? "USD" : country.currency,
        active: true,
        sortOrder: order++,
      });
    }
  }
  // One multi-row insert per chunk instead of 170 sequential round-trips.
  const BATCH = 40;
  for (let i = 0; i < rows.length; i += BATCH) {
    try {
      await db.insert(paymentMethods).values(rows.slice(i, i + BATCH));
    } catch {
      /* ignore */
    }
  }
  return rows.length;
}
