const DM_API = "https://api.dailymotion.com";

export type DmVideo = {
  dmId: string;
  title: string;
  description: string;
  thumbnail: string;
  url: string;
  duration: number;
  owner: string;
  tags: string[];
  language: string;
  views: number;
  createdAt: Date;
};

const FIELDS = "id,title,description,thumbnail_720_url,thumbnail_1080_url,url,duration,owner.screenname,views_total,created_time,language,tags,channel";

type RawDm = {
  id: string;
  title?: string;
  description?: string;
  thumbnail_720_url?: string;
  thumbnail_1080_url?: string;
  thumbnail_url?: string;
  url?: string;
  duration?: number;
  "owner.screenname"?: string;
  views_total?: number;
  created_time?: number;
  language?: string;
  tags?: string[];
  channel?: string;
};

async function dmRequest<T>(path: string, params: Record<string, string | number | undefined>): Promise<T | null> {
  const url = new URL(`${DM_API}${path}`);
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined && v !== null && v !== "") url.searchParams.set(k, String(v));
  }
  try {
    const res = await fetch(url.toString(), {
      headers: { Accept: "application/json" },
      cache: "no-store",
      signal: AbortSignal.timeout(12_000),
    });
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch {
    return null;
  }
}

function normalize(raw: RawDm): DmVideo | null {
  if (!raw?.id || !raw.title) return null;
  const thumb = raw.thumbnail_1080_url || raw.thumbnail_720_url || raw.thumbnail_url || "";
  return {
    dmId: raw.id,
    title: raw.title,
    description: (raw.description ?? "").slice(0, 1400),
    thumbnail: thumb,
    url: raw.url || `https://www.dailymotion.com/video/${raw.id}`,
    duration: Math.max(0, Math.round(raw.duration ?? 0)),
    owner: raw["owner.screenname"] ?? "Dailymotion",
    tags: Array.isArray(raw.tags) ? raw.tags.slice(0, 18) : [],
    language: raw.language || "en",
    views: raw.views_total ?? 0,
    createdAt: raw.created_time ? new Date(raw.created_time * 1000) : new Date(),
  };
}

export type DmResult = { videos: DmVideo[]; total: number };

export async function dmSearch(query: string, limit = 30, sort = "relevance"): Promise<DmResult> {
  const data = await dmRequest<{ list?: RawDm[]; total?: number }>("/videos", {
    fields: FIELDS,
    search: query,
    limit: Math.min(100, limit),
    page: 1,
    sort,
    longer_than: 60,
  });
  const list = (data?.list ?? []).map(normalize).filter((v): v is DmVideo => !!v);
  return { videos: list, total: data?.total ?? list.length };
}

/** Broad trending sweep across multiple queries, de-duplicated. */
export async function dmSweep(queries: string[], perQuery = 12): Promise<DmVideo[]> {
  const seen = new Map<string, DmVideo>();
  const results = await Promise.all(
    queries.map(async (q) => {
      const r = await dmSearch(q, perQuery, "trending");
      return r.videos;
    }),
  );
  for (const list of results) {
    for (const v of list) {
      if (v.duration < 90) continue;
      if (!seen.has(v.dmId)) seen.set(v.dmId, v);
    }
  }
  return [...seen.values()];
}

export async function dmVideo(id: string): Promise<DmVideo | null> {
  const data = await dmRequest<RawDm>(`/video/${id}`, { fields: FIELDS });
  return data ? normalize(data) : null;
}

type DmSubtitle = { id?: string; language?: string; language_label?: string; url?: string };

/** Returns the raw VTT/SRT of a video's subtitle track, when one exists. */
export async function dmSubtitleText(id: string, preferred = "en"): Promise<string | null> {
  const data = await dmRequest<{ list?: DmSubtitle[] }>(`/video/${id}/subtitles`, {
    fields: "id,language,language_label,url",
  });
  const list = data?.list ?? [];
  if (!list.length) return null;
  const chosen = list.find((s) => s.language?.startsWith(preferred)) ?? list[0];
  if (!chosen?.url) return null;
  try {
    const res = await fetch(chosen.url, { cache: "no-store", signal: AbortSignal.timeout(9000) });
    if (!res.ok) return null;
    return await res.text();
  } catch {
    return null;
  }
}

/** Cheap availability probe — search results sometimes include deleted/private videos. */
export async function dmExists(id: string): Promise<boolean> {
  const data = await dmRequest<{ id?: string }>(`/video/${id}`, { fields: "id" });
  return Boolean(data?.id);
}

export function extractDmId(input: string): string | null {
  const trimmed = input.trim();
  if (/^[a-zA-Z0-9]{5,12}$/.test(trimmed)) return trimmed;
  const m =
    trimmed.match(/dailymotion\.com\/video\/([a-zA-Z0-9]+)/i) ||
    trimmed.match(/dai\.ly\/([a-zA-Z0-9]+)/i) ||
    trimmed.match(/(?:^|[?&])video=([a-zA-Z0-9]+)/i);
  return m ? m[1] : null;
}

/* ----------------------------- category engine ---------------------------- */

const CATEGORY_RULES: { category: string; patterns: RegExp[] }[] = [
  { category: "Korean Drama", patterns: [/korean|k-drama|kdrama|korea|hanguk|여주인공/i] },
  { category: "Chinese Drama", patterns: [/chinese|cdrama|c-drama|china|mandarin|billionaire.*(wife|husband)|zongcai/i] },
  { category: "Turkish Drama", patterns: [/turkish|türkçe|turkce|dizi|turkiye|türkiye/i] },
  { category: "ReelShort", patterns: [/reelshort|reel short/i] },
  { category: "DramaBox", patterns: [/dramabox|drama box/i] },
  { category: "CEO & Billionaire", patterns: [/ceo|billionaire|millionaire|tycoon|rich|wealthy|heir|mafia|don/i] },
  { category: "Revenge", patterns: [/revenge|betray|cheat|divorce|ex-|comeback|counterattack/i] },
  { category: "Fantasy", patterns: [/dragon|magic|werewolf|vampire|immortal|cultivation|rebirth|reincarnat|system|ghost|demon/i] },
  { category: "Romance", patterns: [/romance|love|marriage|wedding|kiss|honeymoon|sweet|heart/i] },
  { category: "Vertical Series", patterns: [/vertical|short drama|micro drama|mini drama|episode|ep\b|full movie/i] },
];

export function classify(video: { title: string; tags?: string[]; description?: string }): string {
  const haystack = `${video.title} ${(video.tags ?? []).join(" ")} ${(video.description ?? "").slice(0, 240)}`;
  for (const rule of CATEGORY_RULES) {
    if (rule.patterns.some((p) => p.test(haystack))) return rule.category;
  }
  return "Micro Drama";
}

export function isDramaLike(video: DmVideo): boolean {
  const haystack = `${video.title} ${video.tags.join(" ")}`.toLowerCase();
  const dramaWords = [
    "drama", "episode", "ep", "movie", "film", "story", "series", "reelshort", "dramabox",
    "short", "micro", "mini", "romance", "love", "ceo", "billionaire", "wife", "husband",
    "marriage", "revenge", "korean", "chinese", "turkish", "vertical",
  ];
  const hits = dramaWords.filter((w) => haystack.includes(w)).length;
  if (hits >= 1) return true;
  return video.duration >= 300;
}
