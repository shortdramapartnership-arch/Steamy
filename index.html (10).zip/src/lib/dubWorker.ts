import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import path from "node:path";
import { db } from "@/db";
import { dubClips } from "@/db/schema";
import { eq, inArray, sql } from "drizzle-orm";

/** The one dubbing worker — Linly-Dubbing (ASR + Edge TTS render). */
const WORKER = path.join(process.cwd(), "worker", "linly_dub.py");
const PYTHON = process.env.DUB_PYTHON ?? "python3";

export type WorkerProbe = {
  ok: boolean;
  engine: string;
  faster_whisper: boolean;
  edge_tts: boolean;
  ffmpeg: boolean;
  pyav: boolean;
  numpy?: boolean;
  python?: string;
};

export type RenderClip = {
  index: number;
  start: number;
  end: number;
  audio: string | null;
  duration: number;
  speed: number;
  speaker?: string;
  voice?: string;
};

export type RenderResult = {
  engine: string;
  engine_detail?: { faster_whisper?: boolean; edge_tts?: boolean; ffmpeg?: boolean; pyav?: boolean };
  voices_used?: string[];
  clips: RenderClip[];
  rendered: number;
  requested: number;
  elapsed_ms: number;
};

let installing: Promise<void> | null = null;

/** Installs the Linly-Dubbing runtime (faster-whisper + Edge TTS) on first use. */
async function ensureEdgeTts() {
  const probe = await probeWorker();
  if (probe.edge_tts) return;
  if (!installing) {
    installing = new Promise<void>((resolve) => {
      const child = spawn(PYTHON, ["-m", "pip", "install", "--quiet", "--break-system-packages", "edge-tts"]);
      const timer = setTimeout(() => child.kill("SIGKILL"), 120_000);
      child.on("close", () => {
        clearTimeout(timer);
        resolve();
      });
      child.on("error", () => {
        clearTimeout(timer);
        resolve();
      });
    });
  }
  await installing;
}

/** Runs a Python worker, piping the payload through stdin. */
function runWorker(script: string, payload: Record<string, unknown>, timeoutMs: number): Promise<string> {
  return new Promise<string>((resolve, reject) => {
    const child = spawn(PYTHON, [script], { cwd: process.cwd() });
    let stdout = "";
    let stderr = "";
    const timer = setTimeout(() => {
      child.kill("SIGKILL");
      reject(new Error(`dub worker timed out after ${timeoutMs}ms`));
    }, timeoutMs);

    child.stdout.on("data", (chunk: Buffer) => {
      stdout += chunk.toString();
    });
    child.stderr.on("data", (chunk: Buffer) => {
      stderr += chunk.toString();
    });
    child.on("error", (error) => {
      clearTimeout(timer);
      reject(error);
    });
    child.on("close", (code) => {
      clearTimeout(timer);
      if (code !== 0) reject(new Error(stderr.trim().slice(-400) || `dub worker exited with ${code}`));
      else resolve(stdout);
    });

    child.stdin.on("error", () => undefined);
    child.stdin.end(JSON.stringify(payload));
  });
}

/**
 * Cached probe. Hosts without Python (Netlify Functions) would otherwise spawn a
 * doomed process on every single call, adding latency to every dubbing request.
 */
let probeCache: { at: number; value: WorkerProbe } | null = null;
const PROBE_TTL = 60_000;

export async function probeWorker(): Promise<WorkerProbe> {
  if (probeCache && Date.now() - probeCache.at < PROBE_TTL) return probeCache.value;
  const result = await probeWorkerUncached();
  probeCache = { at: Date.now(), value: result };
  return result;
}

async function probeWorkerUncached(): Promise<WorkerProbe> {
  try {
    const stdout = await runWorker(WORKER, { probe: true }, 20_000);
    return JSON.parse(stdout.trim().split("\n").pop() ?? "{}") as WorkerProbe;
  } catch {
    return { ok: false, engine: "unavailable", faster_whisper: false, edge_tts: false, ffmpeg: false, pyav: false };
  }
}

async function callWorker(payload: Record<string, unknown>, timeoutMs: number): Promise<Record<string, unknown>> {
  const stdout = await runWorker(WORKER, payload, timeoutMs);
  return JSON.parse(stdout.trim().split("\n").pop() ?? "{}") as Record<string, unknown>;
}

const hashOf = (lang: string, voice: string, text: string) =>
  createHash("sha1").update(`${lang}|${voice}|${text}`).digest("hex");

export type UtteranceInput = { index: number; start: number; end: number; speaker: string; text: string; gender?: string; voice?: string };

/**
 * Renders a window of dub phrases with Linly-Dubbing. Clips are cached
 * in Postgres so each phrase is only ever synthesised once per language.
 */
export async function renderUtterances(opts: {
  videoId: number;
  lang: string;
  utterances: UtteranceInput[];
  voices?: Record<string, { male: string; female: string }>;
  preferFemale?: boolean;
}): Promise<RenderResult> {
  const { videoId, lang } = opts;
  if (!opts.utterances.length) return { engine: "linly-dubbing", clips: [], rendered: 0, requested: 0, elapsed_ms: 0 };

  await ensureEdgeTts();

  const pair = opts.voices?.[lang] ?? { male: "", female: "" };
  /**
   * The voice is resolved exactly once, here, and is the single source of truth
   * for the cache key, the worker payload and the returned clip. That guarantees
   * a phrase can never be synthesised under one voice and looked up under another.
   */
  /**
   * The character cast decided by the caller wins. Only when no gender was
   * supplied do we fall back to a per-speaker hash, so every phrase keeps a
   * stable voice either way.
   */
  const resolve = (u: UtteranceInput) => {
    const gender: "male" | "female" = u.gender === "female" || u.gender === "male" ? u.gender : "male";
    const voice = u.voice || (gender === "female" ? pair.female : pair.male);
    return { ...u, gender, voice: voice || gender };
  };
  const resolved = opts.utterances.map(resolve);
  const keyOf = (u: { voice: string; text: string }) => hashOf(lang, u.voice, u.text);

  const keys = resolved.map(keyOf);
  const cached = keys.length ? await db.select().from(dubClips).where(inArray(dubClips.hash, keys)) : [];
  const cacheMap = new Map(cached.map((c) => [c.hash, c]));

  const missing = resolved.filter((u) => !cacheMap.has(keyOf(u)));
  let detail: RenderResult["engine_detail"];
  const voicesUsed = new Set<string>();

  if (missing.length) {
    const payload = {
      mode: "render",
      lang,
      voices: opts.voices,
      preferFemale: opts.preferFemale ?? false,
      utterances: missing.map((u) => ({
        index: u.index,
        start: u.start,
        end: u.end,
        speaker: u.speaker,
        gender: u.gender,
        voice: u.voice,
        text: u.text,
      })),
    };
    const raw = (await callWorker(payload, 180_000)) as unknown as RenderResult & { error?: string };
    if (raw.error) throw new Error(String(raw.error));
    detail = raw.engine_detail;

    for (const clip of raw.clips ?? []) {
      if (!clip.audio) continue;
      const source = missing.find((u) => u.index === clip.index);
      if (!source) continue;
      const hash = keyOf(source);
      const row = {
        hash,
        videoId,
        lang,
        voice: source.voice,
        audio: clip.audio,
        durationMs: Math.round((clip.duration ?? 0) * 1000),
        speed: String(clip.speed ?? 1),
      };
      await db.insert(dubClips).values(row).onConflictDoNothing();
      cacheMap.set(hash, { ...row, createdAt: new Date() } as never);
      voicesUsed.add(source.voice);
    }
  }

  const clips: RenderClip[] = resolved.map((u) => {
    const hit = cacheMap.get(keyOf(u));
    const duration = hit ? Number(hit.durationMs) / 1000 : 0;
    const speed = hit ? Number(hit.speed) : 1;
    return {
      index: u.index,
      start: u.start,
      end: u.end,
      audio: hit?.audio ? `data:audio/mpeg;base64,${hit.audio}` : null,
      duration,
      speed,
      speaker: u.speaker,
      voice: u.voice,
    };
  });

  return {
    engine: "linly-dubbing",
    engine_detail: detail,
    voices_used: [...voicesUsed],
    clips,
    rendered: clips.filter((c) => c.audio).length,
    requested: resolved.length,
    elapsed_ms: 0,
  };
}

export async function dubCacheStats() {
  const rows = await db
    .select({ n: sql<number>`count(*)::int`, bytes: sql<number>`coalesce(sum(length(audio),0)::int` })
    .from(dubClips);
  return rows[0] ?? { n: 0, bytes: 0 };
}

export async function clearDubCache(videoId?: number) {
  if (videoId) await db.delete(dubClips).where(eq(dubClips.videoId, videoId));
  else await db.delete(dubClips);
}


/* ================= Linly-Dubbing speech recognition stage ================= */

export type LinlyProbe = {
  ok: boolean;
  engine: string;
  faster_whisper: boolean;
  edge_tts: boolean;
  ffmpeg: boolean;
  pyav: boolean;
  numpy?: boolean;
};

export type LinlyUtterance = {
  start: number;
  end: number;
  speaker: string;
  text: string;
  words: { w: string; t: number; d: number }[];
};

export type LinlyResult = {
  ok: boolean;
  engine: string;
  model: string;
  language: string;
  languageProbability: number;
  audioSeconds: number;
  utterances: LinlyUtterance[];
  wordCount: number;
  elapsedMs: number;
};

/**
 * faster-whisper and edge-tts resolve against different dependency sets, so they
 * must be installed together or pip will silently remove one of them.
 */
let linlyInstall: Promise<void> | null = null;
async function ensureLinlyDeps() {
  const probe = await probeLinly();
  if (probe.faster_whisper && probe.edge_tts) return;
  if (!linlyInstall) {
    linlyInstall = new Promise<void>((resolve) => {
      const child = spawn(PYTHON, [
        "-m", "pip", "install", "--quiet", "--break-system-packages",
        "numpy", "faster-whisper", "edge-tts", "imageio-ffmpeg",
      ]);
      const timer = setTimeout(() => child.kill("SIGKILL"), 600_000);
      child.on("close", () => {
        clearTimeout(timer);
        resolve();
      });
      child.on("error", () => {
        clearTimeout(timer);
        resolve();
      });
    });
  }
  await linlyInstall;
}

export async function probeLinly(): Promise<LinlyProbe> {
  try {
    const stdout = await runWorker(WORKER, { probe: true }, 25_000);
    return JSON.parse(stdout.trim().split("\n").pop() ?? "{}") as LinlyProbe;
  } catch {
    return { ok: false, engine: "unavailable", faster_whisper: false, edge_tts: false, ffmpeg: false, pyav: false, numpy: false };
  }
}

/**
 * Transcribes the real audio of a Dailymotion title with word-level timestamps,
 * exactly like the ASR stage of Linly-Dubbing.
 */
export async function linlyTranscribe(opts: { dmId: string; seconds?: number; model?: string }): Promise<LinlyResult> {
  const probe = await probeWorker();
  if (!probe.faster_whisper || !probe.pyav) await ensureLinlyDeps();
  const stdout = await runWorker(
    WORKER,
    { mode: "asr", dmId: opts.dmId, seconds: opts.seconds ?? 300, model: opts.model ?? "base" },
    600_000,
  );
  return JSON.parse(stdout.trim().split("\n").pop() ?? "{}") as LinlyResult;
}
