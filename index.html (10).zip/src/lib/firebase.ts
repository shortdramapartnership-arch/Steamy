import { initializeApp, getApps, getApp, type FirebaseApp } from "firebase/app";
import { getDatabase, ref, set, type Database } from "firebase/database";

/**
 * Firebase project used by the platform.
 *
 * The console snippet does not include a databaseURL, so the Realtime Database
 * endpoint is derived from the project id (the standard Firebase convention).
 * Every value can still be overridden with NEXT_PUBLIC_* environment variables.
 */
export const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY ?? "AIzaSyARESnuIdRkGDVgOV4g-5XTDeFMPnWc57M",
  authDomain: "steamy-26f21.firebaseapp.com",
  databaseURL:
    process.env.NEXT_PUBLIC_FIREBASE_DB_URL ?? "https://steamy-26f21-default-rtdb.firebaseio.com",
  projectId: "steamy-26f21",
  storageBucket: "steamy-26f21.firebasestorage.app",
  messagingSenderId: "89514758713",
  appId: "1:89514758713:web:77748f9b172347c5a2b3e8",
  measurementId: "G-7TMPXLTK4H",
};

let appRef: FirebaseApp | null = null;
let dbRef: Database | null = null;

export function getFirebaseApp(): FirebaseApp {
  if (!appRef) appRef = getApps().length ? getApp() : initializeApp(firebaseConfig);
  return appRef;
}

export function getFirebaseDb(): Database {
  if (!dbRef) dbRef = getDatabase(getFirebaseApp());
  return dbRef;
}

/**
 * The mirror is on unless explicitly disabled with NEXT_PUBLIC_FIREBASE_MIRROR=off.
 * Deliberately reads no server-only modules: this file is imported by client
 * components, and pulling the database driver into the browser bundle would
 * break the production build.
 */
const mirrorEnabled = () => process.env.NEXT_PUBLIC_FIREBASE_MIRROR !== "off";

/**
 * Best-effort mirror write to the Realtime Database.
 *
 * Postgres is always the source of truth, so every failure is swallowed — the
 * platform must keep working (and keep building) even if the RTDB rules deny
 * access or the project is offline.
 */
export async function firebaseSet(path: string, value: unknown): Promise<boolean> {
  try {
    if (!mirrorEnabled()) return false;
    await set(ref(getFirebaseDb(), path), value as never);
    return true;
  } catch {
    return false;
  }
}

export async function firebasePushLog(event: string, payload: Record<string, unknown>) {
  await firebaseSet(`live/events/${Date.now()}`, { event, payload, at: Date.now() });
}

/** Never throws — used by status cards. */
export async function firebasePing(): Promise<boolean> {
  try {
    await set(ref(getFirebaseDb(), "catalog/ping"), Date.now());
    return true;
  } catch {
    return false;
  }
}

export { ref, set };
