"use client";

import { useEffect } from "react";

/**
 * Firebase Analytics from the new SDK. Loaded lazily in the browser only, and
 * only when the browser supports it — this keeps SSR and the production build
 * completely free of Firebase side effects.
 */
export function useAnalytics() {
  useEffect(() => {
    if (typeof window === "undefined") return;
    let cancelled = false;
    (async () => {
      try {
        const [{ isSupported, getAnalytics }, { getFirebaseApp }] = await Promise.all([
          import("firebase/analytics"),
          import("@/lib/firebase"),
        ]);
        if (cancelled || !(await isSupported())) return;
        getAnalytics(getFirebaseApp());
      } catch {
        /* analytics is optional — never surface an error */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);
}
