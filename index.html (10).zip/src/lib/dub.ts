import type { DubCue } from "@/db/schema";

/* ------------------------------- utilities -------------------------------- */

function hash(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function rng(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function pick<T>(arr: T[], r: () => number): T {
  return arr[Math.floor(r() * arr.length)];
}

export function cleanTitle(title: string): string {
  return title
    // strip emoji / symbols
    .replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\u{200D}]/gu, " ")
    .replace(/\[[^\]]*\]|\([^)]*\)/g, " ")
    .replace(/\.(mp4|mkv|avi)$/i, "")
    .replace(/\s*\|\s*/g, " — ")
    .replace(/#\w+/g, " ")
    .replace(/\b(full|complete|hd|4k|english sub|sub indo|eng sub|episode|ep|movie|film)\b/gi, " ")
    .replace(/[_–—-]{2,}/g, " ")
    .replace(/\s{2,}/g, " ")
    .replace(/^[\s—-]+|[\s—-]+$/g, "")
    .trim();
}

export function splitWords(text: string): string[] {
  return text.split(/\s+/).filter(Boolean);
}

/** Distributes word timings across a cue using length weighting (karaoke style). */
export function timeWords(text: string, start: number, end: number): { w: string; t: number; d: number }[] {
  const words = splitWords(text);
  if (!words.length) return [];
  const span = Math.max(0.4, end - start);
  const weights = words.map((w) => Math.max(2, w.replace(/[^\p{L}\p{N}]/gu, "").length) + 1);
  const total = weights.reduce((a, b) => a + b, 0);
  let cursor = start;
  return words.map((w, i) => {
    const d = (weights[i] / total) * span;
    const item = { w, t: Number(cursor.toFixed(3)), d: Number(d.toFixed(3)) };
    cursor += d;
    return item;
  });
}

/* ------------------------- auto drama script engine ----------------------- */

const CASTS: Record<string, string[]> = {
  "Korean Drama": ["Ha-eun", "Ji-ho", "Seo-yeon", "Min-jun"],
  "Chinese Drama": ["Lin Xi", "Lu Chen", "Su Wan", "Gu Yan"],
  "Turkish Drama": ["Elif", "Kerem", "Zeynep", "Emir"],
  default: ["Ava", "Ryan", "Mira", "Kian"],
};

const ACTS: { title: string; lines: string[] }[] = [
  {
    title: "Opening",
    lines: [
      "They said one night could change everything.",
      "I never believed them, until tonight.",
      "This is where my story truly begins.",
      "Everyone in this city wants something from me.",
      "I only wanted to be left alone.",
      "Fate had very different plans.",
      "The rain was falling the first time we met.",
      "He looked at me like I was already his.",
    ],
  },
  {
    title: "The Contract",
    lines: [
      "Marry me, and I will clear every debt.",
      "You cannot be serious about this.",
      "Six months. That is all I need.",
      "A contract, nothing more.",
      "Then we shake hands and walk away.",
      "Do we have an agreement?",
      "I had no other choice left.",
      "Fine. I will sign your papers.",
      "But do not fall in love with me.",
      "That will never be a problem.",
    ],
  },
  {
    title: "First Spark",
    lines: [
      "You are trembling. Are you cold?",
      "Do not come any closer to me.",
      "Your heart is beating faster than mine.",
      "That means absolutely nothing.",
      "Then why are you still holding my hand?",
      "I hate how calm you always are.",
      "You are impossible to reason with.",
      "And yet you keep finding me.",
      "Careful, or someone will see us.",
      "Let them look. I am done hiding.",
    ],
  },
  {
    title: "The Secret",
    lines: [
      "There is something you need to know.",
      "I have been lying since the beginning.",
      "Nothing about us was ever real.",
      "Do not say another word, please.",
      "I was protecting you the whole time.",
      "Protecting me from what exactly?",
      "From the truth about your family.",
      "My father would never hide that.",
      "He hid far more than you think.",
      "Then show me the documents, now.",
    ],
  },
  {
    title: "Betrayal",
    lines: [
      "You knew and you still stayed silent.",
      "I stayed silent to keep you alive.",
      "That is not your decision to make.",
      "They are watching this house right now.",
      "Then let them come for me.",
      "You have no idea how dangerous he is.",
      "I trusted you with everything.",
      "And I burned that trust to save you.",
      "Get out of my sight, right now.",
      "If I leave now, I am not coming back.",
    ],
  },
  {
    title: "The Fall",
    lines: [
      "The company is gone by morning.",
      "Every share, every account, frozen.",
      "They planned this for years.",
      "Where were you when it happened?",
      "I was signing the papers that saved you.",
      "You should have let me fall.",
      "Never say that to me again.",
      "I would trade everything for you.",
      "Do you hear what you just said?",
      "I have never been more sure of anything.",
    ],
  },
  {
    title: "Revenge",
    lines: [
      "Now it is my turn to move.",
      "You took my name, so I take your empire.",
      "The board meeting is in one hour.",
      "Every director is already on my side.",
      "You cannot walk in there like that.",
      "Watch me.",
      "Gentlemen, check your new shareholder.",
      "This is impossible.",
      "It becomes very possible when you listen.",
      "Sign the transfer, and walk away alive.",
    ],
  },
  {
    title: "Confession",
    lines: [
      "I came back because I love you.",
      "Say that again, slowly.",
      "I have loved you since the first rain.",
      "Every cold word was a lie.",
      "I was afraid you would see it.",
      "I see everything when I look at you.",
      "Then stop looking and just stay.",
      "I am not going anywhere this time.",
      "Not tonight, not ever again.",
      "Then let us start over, properly.",
    ],
  },
  {
    title: "The Family",
    lines: [
      "Mother, I never wanted this engagement.",
      "Then learn to want it, child.",
      "Our family is not what you think.",
      "Then tell me the truth for once.",
      "Your brother sold the company shares.",
      "He would never do that to us.",
      "Check the ledger, page forty.",
      "So it was him all along.",
      "And you kept protecting him.",
      "I kept protecting you from him.",
    ],
  },
  {
    title: "The Rival",
    lines: [
      "You came alone. How brave.",
      "I came to end this, not to fight.",
      "She was never yours to begin with.",
      "You lost her the day you lied.",
      "Careful, your envy is showing.",
      "Sign the papers and walk away.",
      "And if I refuse?",
      "Then you lose everything by morning.",
      "You are bluffing.",
      "Ask your board how bluffing feels.",
    ],
  },
  {
    title: "The Twist",
    lines: [
      "There is one more page you never read.",
      "The will was changed the night he died.",
      "That is impossible, I was there.",
      "You were there, and you signed it.",
      "My hands were shaking that night.",
      "Exactly why nobody questioned you.",
      "Then who wrote this letter?",
      "The woman who raised us both.",
      "She knew everything from the start.",
      "And she waited until now to speak.",
    ],
  },
  {
    title: "Finale",
    lines: [
      "One year later, the city still talks.",
      "They talk about the woman who won.",
      "Or the man who finally learned to love.",
      "Both versions are true.",
      "Everything I have, I share with you.",
      "Everything I am, I built with you.",
      "So, what happens in the next chapter?",
      "Whatever we write, we write together.",
      "This time, forever.",
      "And that is how our story ends.",
    ],
  },
];

/** Builds a full timed dialogue script that covers the entire runtime. */
export function buildAutoScript(seedKey: string, duration: number, title: string, category: string): DubCue[] {
  const r = rng(hash(seedKey));
  const cast = CASTS[category] ?? CASTS.default;
  const total = Math.max(90, Math.min(duration || 600, 7200));
  const gap = 0.3;

  // ---- build the line pool (shuffled inside each act so every video differs)
  const pool: { speaker: string; text: string }[] = [];
  for (const act of ACTS) {
    const lines = [...act.lines];
    for (let i = lines.length - 1; i > 0; i--) {
      const j = Math.floor(r() * (i + 1));
      [lines[i], lines[j]] = [lines[j], lines[i]];
    }
    lines.forEach((text, idx) => {
      pool.push({ speaker: idx % 3 === 2 ? cast[2] : idx % 2 === 0 ? cast[0] : cast[1], text });
    });
  }

  // ---- how many lines do we need, and how long may each one run?
  const naturalLen = 3.15;
  const fitByDensity = Math.floor(total / (naturalLen + gap));
  const lineBudget = Math.max(24, Math.min(pool.length * 4, fitByDensity));
  const cueLen = Math.min(9.5, Math.max(naturalLen, total / Math.max(1, lineBudget) - gap));

  const opening = cleanTitle(title);
  const cues: DubCue[] = [];
  let t = 1.0;

  if (opening) {
    const end = 1.0 + cueLen * 1.35;
    cues.push({ start: 1.0, end, speaker: "Narrator", text: `${opening}.` });
    t = end + gap;
  }

  const fillers = [
    "", "", "", "",
    " — quietly.",
    " — he paused.",
    " — she whispered.",
    " — the room went still.",
    " — nobody dared answer.",
  ];

  let spoken = 0;
  while (spoken < lineBudget && t < total - 1.2) {
    const pass = Math.floor(spoken / pool.length); // 0..3 → story repeats as a new "chapter"
    const item = pool[spoken % pool.length];
    const variant = pass === 0 ? "" : pick(fillers, r);
    // rotate the cast on later passes so the same arc reads like a new chapter
    const speaker = pass % 2 === 0 ? item.speaker : cast[(cast.indexOf(item.speaker) + 1) % cast.length];
    const text = `${item.text}${variant}`;
    const start = t;
    const end = Math.min(total - 0.4, t + cueLen + (text.length > 48 ? 0.8 : 0));
    cues.push({ start, end, speaker, text });
    t = end + gap;
    spoken++;
  }

  return cues.map((c) => ({ ...c, words: timeWords(c.text, c.start, c.end) }));
}

/** Parses SRT / VTT / plain text into timed cues. */
export function parseScript(raw: string, duration: number, fallbackTitle: string): DubCue[] {
  const text = raw.trim();
  const hasTimecodes = /-->/.test(text);
  const cues: DubCue[] = [];

  const toSeconds = (s: string) => {
    const m = s.trim().match(/(?:(\d+):)?(\d{1,2}):(\d{2})[.,](\d{1,3})/);
    if (!m) return 0;
    const [, h, mm, ss, ms] = m;
    return Number(h ?? 0) * 3600 + Number(mm) * 60 + Number(ss) + Number(ms.padEnd(3, "0")) / 1000;
  };

  if (hasTimecodes) {
    const blocks = text.split(/\r?\n\r?\n/);
    for (const block of blocks) {
      const lines = block.split(/\r?\n/).filter(Boolean);
      const idx = lines.findIndex((l) => l.includes("-->"));
      if (idx === -1) continue;
      const [a, b] = lines[idx].split("-->");
      const start = toSeconds(a);
      const end = Math.max(start + 0.8, toSeconds(b));
      const body = lines
        .slice(idx + 1)
        .join(" ")
        .replace(/<[^>]+>/g, "")
        .trim();
      if (!body) continue;
      const sp = body.match(/^([A-Z][A-Za-z .'-]{1,18}):\s*(.+)$/);
      cues.push({
        start,
        end,
        speaker: sp ? sp[1] : "Dialogue",
        text: sp ? sp[2] : body,
      });
    }
    return cues.map((c) => ({ ...c, words: timeWords(c.text, c.start, c.end) }));
  }

  // Plain prose: spread sentences across the runtime.
  const sentences = text
    .replace(/\s+/g, " ")
    .split(/(?<=[.!?。！？])\s+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 1);
  const list = sentences.length ? sentences : [cleanTitle(fallbackTitle) || "To be continued."];
  const span = Math.max(60, duration || 600);
  const step = span / list.length;
  return list.slice(0, 400).map((s, i) => {
    const start = 0.8 + i * step;
    const end = start + Math.min(step * 0.86, 6.5);
    return { start, end, speaker: i % 2 === 0 ? "Lead A" : "Lead B", text: s, words: timeWords(s, start, end) };
  });
}

/* ------------------------------- translation ------------------------------ */

const TRANSLATE_HOSTS = [
  "https://clients5.google.com/translate_a/t",
  "https://translate.googleapis.com/translate_a/t",
];

async function translateBatchGoogle(lines: string[], target: string, source = "en"): Promise<string[] | null> {
  for (const host of TRANSLATE_HOSTS) {
    try {
      const url = new URL(host);
      url.searchParams.set("client", "dict-chrome-ex");
      url.searchParams.set("sl", source);
      url.searchParams.set("tl", target);
      url.searchParams.set("q", lines.join("\n"));
      const res = await fetch(url.toString(), {
        headers: { "User-Agent": "Mozilla/5.0", Accept: "*/*" },
        cache: "no-store",
        signal: AbortSignal.timeout(9000),
      });
      if (!res.ok) continue;
      const data = (await res.json()) as unknown;
      let out: string[] = [];
      if (Array.isArray(data)) {
        if (typeof data[0] === "string") out = [String(data[0])];
        else if (Array.isArray(data[0])) out = (data as unknown[][]).map((x) => String(x[0] ?? ""));
      }
      const joined = out.join("\n").split("\n").filter(Boolean);
      if (joined.length === lines.length) return joined;
      if (joined.length === 1 && lines.length === 1) return joined;
    } catch {
      // try next host
    }
  }
  return null;
}

async function translateMyMemory(line: string, target: string): Promise<string | null> {
  try {
    const url = new URL("https://api.mymemory.translated.net/get");
    url.searchParams.set("q", line);
    url.searchParams.set("langpair", `en|${target}`);
    const res = await fetch(url.toString(), { cache: "no-store", signal: AbortSignal.timeout(9000) });
    if (!res.ok) return null;
    const data = (await res.json()) as { responseData?: { translatedText?: string } };
    const t = data.responseData?.translatedText;
    return t && !/^MYMEMORY WARNING/i.test(t) ? t : null;
  } catch {
    return null;
  }
}

/** Translates an array of lines, preserving order. Falls back to originals. */
export async function translateLines(lines: string[], target: string, source = "en"): Promise<string[]> {
  if (!lines.length) return [];
  if (target === source || target === "en") return lines;
  const out: string[] = [];
  const chunkSize = 40;
  for (let i = 0; i < lines.length; i += chunkSize) {
    const chunk = lines.slice(i, i + chunkSize).map((l) => l.replace(/\n/g, " ").slice(0, 400));
    const res = await translateBatchGoogle(chunk, target, source);
    if (res) {
      out.push(...res);
      continue;
    }
    const fb = await Promise.all(chunk.map((l) => translateMyMemory(l, target)));
    out.push(...fb.map((t, idx) => t ?? chunk[idx]));
  }
  return out;
}


/* ===================== shared dub-track segment model ===================== */

export type DubWord = { w: string; t: number; d: number };

export type DubSegment = {
  start: number;
  end: number;
  speaker: string;
  text: string;
  original: string;
  words: DubWord[];
};

/**
 * Groups short subtitle cues into natural speech phrases. Speaking whole
 * phrases (instead of one 3-second line at a time) is what makes the dub sound
 * like a continuous audio track rather than disjointed word-by-word speech.
 * Dialogue turns are respected so the cast still changes voice.
 */
export function buildSegments(cues: DubCue[]): DubSegment[] {
  const segments: DubSegment[] = [];
  let batch: DubCue[] = [];

  const tidy = (value: string) =>
    value
      .replace(/\s+/g, " ")
      .replace(/([!?。！？])\./g, "$1")
      .replace(/\.{2,}/g, ".")
      .replace(/\s+([,.;!?])/g, "$1")
      .trim();

  const flush = () => {
    if (!batch.length) return;
    const start = batch[0].start;
    const end = batch[batch.length - 1].end;
    const text = tidy(batch.map((c) => (c.translated || c.text).trim()).join(" "));
    const original = tidy(batch.map((c) => c.text.trim()).join(" "));
    const speakers = [...new Set(batch.map((c) => c.speaker).filter(Boolean))];
    const speaker = speakers.length > 2 ? `${speakers[0]} · ${speakers[1]} +${speakers.length - 2}` : speakers.join(" · ") || "Dialogue";
    // Real ASR timings (Linly-Dubbing / faster-whisper) are absolute and already
    // frame-accurate, so keep them instead of re-distributing across the window.
    const realWords = batch.every((c) => c.words && c.words.length > 0);
    const words = realWords ? batch.flatMap((c) => c.words as NonNullable<DubCue["words"]>) : timeWords(text, start, end);
    segments.push({ start, end, speaker, text, original, words });
    batch = [];
  };

  for (const cue of cues) {
    if (!cue.text) continue;
    const line = cue.translated || cue.text;
    const span = batch.length ? cue.end - batch[0].start : cue.end - cue.start;
    const chars = batch.reduce((a, c) => a + (c.translated || c.text).length, 0) + line.length;
    const speakerTurn = batch.length >= 3 && batch[batch.length - 1].speaker !== cue.speaker;
    const sentenceEnd = batch.length >= 4 && /[.!?。！？]["')]?$/.test(batch[batch.length - 1]?.text ?? "");
    if (batch.length && (span > 13 || chars > 190 || speakerTurn || sentenceEnd)) flush();
    batch.push(cue);
  }
  flush();
  return segments.filter((s) => s.text.length > 1);
}

/* ============ free neural voices (Linly-Dubbing Edge TTS engine) ============ */

/** Male / female Microsoft Edge neural voice per dubbing language. */
export const EDGE_VOICES: Record<string, { male: string; female: string }> = {
  en: { male: "en-US-GuyNeural", female: "en-US-JennyNeural" },
  hi: { male: "hi-IN-MadhurNeural", female: "hi-IN-SwaraNeural" },
  ur: { male: "ur-PK-AsadNeural", female: "ur-PK-UzmaNeural" },
  es: { male: "es-ES-AlvaroNeural", female: "es-ES-ElviraNeural" },
  ja: { male: "ja-JP-KeitaNeural", female: "ja-JP-NanamiNeural" },
  "zh-CN": { male: "zh-CN-YunxiNeural", female: "zh-CN-XiaoxiaoNeural" },
  ko: { male: "ko-KR-InJoonNeural", female: "ko-KR-SunHiNeural" },
  tr: { male: "tr-TR-AhmetNeural", female: "tr-TR-EmelNeural" },
  ar: { male: "ar-SA-HamedNeural", female: "ar-SA-ZariyahNeural" },
  pt: { male: "pt-BR-AntonioNeural", female: "pt-BR-FranciscaNeural" },
  fr: { male: "fr-FR-HenriNeural", female: "fr-FR-DeniseNeural" },
  de: { male: "de-DE-ConradNeural", female: "de-DE-KatjaNeural" },
  ru: { male: "ru-RU-DmitryNeural", female: "ru-RU-SvetlanaNeural" },
  id: { male: "id-ID-ArdiNeural", female: "id-ID-GadisNeural" },
  ms: { male: "ms-MY-OsmanNeural", female: "ms-MY-YasminNeural" },
  bn: { male: "bn-IN-BashkarNeural", female: "bn-IN-TanishaaNeural" },
  ta: { male: "ta-IN-ValluvarNeural", female: "ta-IN-PallaviNeural" },
  te: { male: "te-IN-ShrutiNeural", female: "te-IN-ShrutiNeural" },
  tl: { male: "fil-PH-AngeloNeural", female: "fil-PH-BlessicaNeural" },
  vi: { male: "vi-VN-NamMinhNeural", female: "vi-VN-HoaiMyNeural" },
  th: { male: "th-TH-NiwatNeural", female: "th-TH-PremwadeeNeural" },
  fa: { male: "fa-IR-FaridNeural", female: "fa-IR-DilaraNeural" },
};

/** Deterministic male/female assignment per speaking turn, like a dub cast. */
export function edgeVoiceFor(lang: string, speaker: string, preferFemale: boolean): string {
  const pair = EDGE_VOICES[lang] ?? EDGE_VOICES.en;
  const seed = speaker.split("").reduce((a, c) => a + c.charCodeAt(0), 0);
  const female = preferFemale ? true : seed % 2 === 0;
  return female ? pair.female : pair.male;
}


/* ======================= character voice casting ======================== */

export type DubCharacter = {
  id: number;
  label: string;
  gender: "male" | "female";
};

export type CastSegment = DubSegment & { character: DubCharacter };

/** Cast presets — a male and a female lead so the dub sounds like real actors. */
export const CAST_PRESETS: Record<string, DubCharacter[]> = {
  "male-female": [
    { id: 0, label: "Male lead", gender: "male" },
    { id: 1, label: "Female lead", gender: "female" },
    { id: 2, label: "Narrator", gender: "male" },
  ],
  "female-male": [
    { id: 0, label: "Female lead", gender: "female" },
    { id: 1, label: "Male lead", gender: "male" },
    { id: 2, label: "Narrator", gender: "female" },
  ],
  "male-only": [{ id: 0, label: "Narrator", gender: "male" }],
  "female-only": [{ id: 0, label: "Narrator", gender: "female" }],
};

export const CAST_OPTIONS = [
  { key: "male-female", label: "Male lead + Female lead + Narrator" },
  { key: "female-male", label: "Female lead + Male lead + Narrator" },
  { key: "male-only", label: "Single male voice" },
  { key: "female-only", label: "Single female voice" },
];

/**
 * Assigns a speaking character to every phrase so male characters are dubbed
 * with a male voice and female characters with a female voice.
 *
 * ASR has no speaker labels, so turns are detected from the rhythm of the
 * dialogue: a pause between phrases, a question mark or an unfinished line all
 * signal that the next phrase belongs to the other character. A run limit keeps
 * one voice from dominating a monologue.
 */
export function assignCharacters(segments: DubSegment[], castKey = "male-female"): CastSegment[] {
  const cast = CAST_PRESETS[castKey] ?? CAST_PRESETS["male-female"];
  if (cast.length === 1 || segments.length === 0) {
    return segments.map((segment) => ({ ...segment, character: cast[0] }));
  }

  let current = 0;
  let run = 0;
  const out: CastSegment[] = [];

  segments.forEach((segment, index) => {
    if (index === 0) {
      current = 0;
      run = 1;
    } else {
      const previous = segments[index - 1];
      const gap = segment.start - previous.end;
      const previousText = previous.text.trim();
      const wasQuestion = /[?？]["')]?$/.test(previousText);
      const wasOpen = !/[.!?。！？]["')]?$/.test(previousText);
      const switched = gap > 0.5 || wasQuestion || (wasOpen && gap > 0.2) || run >= 2;
      if (switched) {
        current = (current + 1) % cast.length;
        run = 1;
      } else {
        run += 1;
      }
    }
    out.push({ ...segment, character: cast[current] });
  });

  return out;
}