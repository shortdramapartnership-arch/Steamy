import { cookies, headers } from "next/headers";
import { createHash } from "node:crypto";
import { db } from "@/db";
import { accessGrants, payments, users, type UserRow } from "@/db/schema";
import { and, desc, eq, gt, or, sql } from "drizzle-orm";

export const DEVICE_COOKIE = "steam_device";
export const USER_COOKIE = "steam_uid";

export type AccessLevel = "none" | "free" | "day" | "month";

export type AccessState = {
  deviceId: string;
  level: AccessLevel;
  kind: string | null;
  label: string;
  expiresAt: string | null;
  hoursLeft: number;
  pendingPayment: { id: number; status: string; amount: string; currency: string; createdAt: string } | null;
};

export type SessionUser = {
  id: number;
  provider: string;
  name: string;
  email: string;
  picture: string;
};

const LABELS: Record<string, string> = {
  daily_code: "Day Pass",
  subscription: "Premium Monthly",
  free_steps: "Free Access (3 steps)",
  promo: "Promo Access",
};

/**
 * Stable viewer identity. The cookie is the primary key, but if cookies are
 * blocked the request fingerprint keeps a stable fallback so a day pass or an
 * approved subscription still activates instead of silently showing "free".
 */
export async function getDeviceId(): Promise<string> {
  const store = await cookies();
  const fromCookie = store.get(DEVICE_COOKIE)?.value;
  if (fromCookie) return fromCookie;
  try {
    const h = await headers();
    const ip = (h.get("x-forwarded-for") ?? h.get("x-real-ip") ?? "local").split(",")[0].trim();
    const ua = h.get("user-agent") ?? "unknown";
    return `dk_${createHash("sha256").update(`${ip}|${ua}`).digest("hex").slice(0, 24)}`;
  } catch {
    return "anonymous";
  }
}

export async function getAccess(deviceIdOverride?: string): Promise<AccessState> {
  const deviceId = deviceIdOverride ?? (await getDeviceId());
  const now = new Date();
  let state: AccessState = {
    deviceId,
    level: deviceId === "anonymous" ? "none" : "free",
    kind: null,
    label: "Free preview",
    expiresAt: null,
    hoursLeft: 0,
    pendingPayment: null,
  };
  if (deviceId === "anonymous") return state;

  try {
    const uid = await currentUserId();
    const scope = uid ? or(eq(accessGrants.deviceId, deviceId), eq(accessGrants.userId, uid)) : eq(accessGrants.deviceId, deviceId);
    const grants = await db
      .select()
      .from(accessGrants)
      .where(and(scope, gt(accessGrants.expiresAt, now)))
      .orderBy(desc(accessGrants.expiresAt))
      .limit(1);
    const grant = grants[0];
    if (grant) {
      const kind = grant.kind;
      const level: AccessLevel = kind === "subscription" ? "month" : kind === "daily_code" ? "day" : "month";
      const hoursLeft = Math.max(0, (grant.expiresAt.getTime() - now.getTime()) / 3_600_000);
      state = {
        deviceId,
        level,
        kind,
        label: `${LABELS[kind] ?? "Premium"}${grant.label ? ` · ${grant.label}` : ""}`,
        expiresAt: grant.expiresAt.toISOString(),
        hoursLeft: Number(hoursLeft.toFixed(1)),
        pendingPayment: null,
      };
    }
    const pending = await db
      .select()
      .from(payments)
      .where(and(eq(payments.deviceId, deviceId), eq(payments.status, "pending")))
      .orderBy(desc(payments.createdAt))
      .limit(1);
    if (pending[0]) {
      state = {
        ...state,
        pendingPayment: {
          id: pending[0].id,
          status: "pending",
          amount: String(pending[0].amount),
          currency: pending[0].currency,
          createdAt: pending[0].createdAt.toISOString(),
        },
      };
    }
  } catch {
    // table not ready yet — treat as free
  }
  return state;
}

export const isPremium = (a: AccessState) => a.level === "day" || a.level === "month";


/** Reads the signed-in account id from the cookie. */
export async function currentUserId(): Promise<number | null> {
  try {
    const store = await cookies();
    const raw = store.get(USER_COOKIE)?.value;
    const id = raw ? Number(raw.split(".")[0]) : NaN;
    return Number.isFinite(id) && id > 0 ? id : null;
  } catch {
    return null;
  }
}

export async function getSessionUser(): Promise<UserRow | null> {
  const id = await currentUserId();
  if (!id) return null;
  const rows = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return rows[0] ?? null;
}

/**
 * Signs an account in on this device and carries premium across devices: any
 * active grant owned by the account is cloned to the current device, and an
 * active device grant is attached to the account.
 */
export async function linkSessionToDevice(user: UserRow, deviceId: string) {
  if (!deviceId || deviceId === "anonymous") return;
  await db.update(users).set({ lastDeviceId: deviceId, lastSeenAt: new Date() }).where(eq(users.id, user.id));
  const now = new Date();
  const active = await db
    .select()
    .from(accessGrants)
    .where(and(gt(accessGrants.expiresAt, now), or(eq(accessGrants.userId, user.id), eq(accessGrants.deviceId, deviceId))))
    .orderBy(desc(accessGrants.expiresAt))
    .limit(1);
  const best = active[0];
  if (!best) return;
  // attach the device grant to the account so it follows the login
  if (best.deviceId === deviceId && !best.userId) {
    await db.update(accessGrants).set({ userId: user.id }).where(eq(accessGrants.id, best.id));
  }
  // clone the account grant onto this device
  if (best.deviceId !== deviceId) {
    await db.insert(accessGrants).values({
      deviceId,
      userId: user.id,
      kind: best.kind,
      label: best.label,
      expiresAt: best.expiresAt,
    });
  }
}

export async function grantAccess(deviceId: string, kind: string, hours: number, label = "", userId: number | null = null) {
  const expiresAt = new Date(Date.now() + hours * 3_600_000);
  await db.insert(accessGrants).values({ deviceId, kind, label, expiresAt, userId });
  return expiresAt;
}

/** Trims the TTS audio cache so it cannot grow without bound. */
export async function trimTtsCache(keep = 500) {
  await db.execute(
    sql`delete from tts_cache where hash not in (select hash from tts_cache order by created_at desc limit ${keep})`,
  );
}
