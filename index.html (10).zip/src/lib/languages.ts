export type DubLanguage = {
  code: string;
  /** BCP-47 tag used for speech synthesis + translation targets. */
  speech: string;
  label: string;
  nativeLabel: string;
  flag: string;
  rtl?: boolean;
};

/** Dubbing languages offered inside the player's Dub Studio. */
export const DUB_LANGUAGES: DubLanguage[] = [
  { code: "en", speech: "en-US", label: "English", nativeLabel: "English", flag: "🇬🇧" },
  { code: "hi", speech: "hi-IN", label: "Hindi", nativeLabel: "हिन्दी", flag: "🇮🇳" },
  { code: "ur", speech: "ur-PK", label: "Urdu", nativeLabel: "اردو", flag: "🇵🇰", rtl: true },
  { code: "es", speech: "es-ES", label: "Spanish", nativeLabel: "Español", flag: "🇪🇸" },
  { code: "ja", speech: "ja-JP", label: "Japanese", nativeLabel: "日本語", flag: "🇯🇵" },
  { code: "zh-CN", speech: "zh-CN", label: "Chinese (Mandarin)", nativeLabel: "简体中文", flag: "🇨🇳" },
  { code: "ko", speech: "ko-KR", label: "Korean", nativeLabel: "한국어", flag: "🇰🇷" },
  { code: "tr", speech: "tr-TR", label: "Turkish", nativeLabel: "Türkçe", flag: "🇹🇷" },
  { code: "ar", speech: "ar-SA", label: "Arabic", nativeLabel: "العربية", flag: "🇸🇦", rtl: true },
  { code: "pt", speech: "pt-BR", label: "Portuguese", nativeLabel: "Português", flag: "🇧🇷" },
  { code: "fr", speech: "fr-FR", label: "French", nativeLabel: "Français", flag: "🇫🇷" },
  { code: "de", speech: "de-DE", label: "German", nativeLabel: "Deutsch", flag: "🇩🇪" },
  { code: "ru", speech: "ru-RU", label: "Russian", nativeLabel: "Русский", flag: "🇷🇺" },
  { code: "id", speech: "id-ID", label: "Indonesian", nativeLabel: "Bahasa Indonesia", flag: "🇮🇩" },
  { code: "ms", speech: "ms-MY", label: "Malay", nativeLabel: "Bahasa Melayu", flag: "🇲🇾" },
  { code: "bn", speech: "bn-IN", label: "Bengali", nativeLabel: "বাংলা", flag: "🇧🇩" },
  { code: "ta", speech: "ta-IN", label: "Tamil", nativeLabel: "தமிழ்", flag: "🇮🇳" },
  { code: "te", speech: "te-IN", label: "Telugu", nativeLabel: "తెలుగు", flag: "🇮🇳" },
  { code: "tl", speech: "fil-PH", label: "Filipino", nativeLabel: "Filipino", flag: "🇵🇭" },
  { code: "vi", speech: "vi-VN", label: "Vietnamese", nativeLabel: "Tiếng Việt", flag: "🇻🇳" },
  { code: "th", speech: "th-TH", label: "Thai", nativeLabel: "ไทย", flag: "🇹🇭" },
  { code: "fa", speech: "fa-IR", label: "Persian", nativeLabel: "فارسی", flag: "🇮🇷", rtl: true },
];

export const DEFAULT_DUB_LANGUAGES = ["en", "hi", "ur", "es", "ja", "zh-CN", "ko", "tr", "ar", "pt", "fr", "ru", "id", "tl"];

export const languageByCode = (code: string) => DUB_LANGUAGES.find((l) => l.code === code);

/** Voice presets — tuned so the dub does not sound robotic. */
export const VOICE_PRESETS = [
  { key: "studio", label: "Studio Neutral", pitch: 1, rate: 1 },
  { key: "narrator", label: "Cinematic Narrator", pitch: 0.85, rate: 0.94 },
  { key: "heroine", label: "Female Lead", pitch: 1.18, rate: 1.02 },
  { key: "hero", label: "Male Lead", pitch: 0.8, rate: 0.98 },
  { key: "fast", label: "Binge Speed", pitch: 1, rate: 1.18 },
];
