import { db } from "@/db";
import { settings, type SettingsData } from "@/db/schema";
import { eq } from "drizzle-orm";
import { DEFAULT_DUB_LANGUAGES } from "./languages";

export type { SettingsData };
export const SETTINGS_ID = "global";

export const DEFAULT_SETTINGS: SettingsData = {
  platformName: "Steamy",
  logoUrl: "",
  tagline: "World's first micro-drama streaming platform",
  heroHeadline: "Micro dramas. Dubbed in your language.",
  heroSubline:
    "Binge the world's trending short dramas from ReelShort, DramaBox, RigTV, Jowo, FlexTV and more — with studio-grade AI dubbing and word-by-word captions.",
  accent: "#e11d48",
  dailyCode: "7867",
  dailyCodeActive: true,
  categories: [
    "Trending Now",
    "All Platforms",
    "Korean Drama",
    "Chinese Drama",
    "Turkish Drama",
    "Micro Drama",
    "Romance",
    "CEO & Billionaire",
    "Revenge",
    "Fantasy",
    "ReelShort",
    "DramaBox",
    "Vertical Series",
  ],
  autoFetchEnabled: true,
  autoFetchLimit: 40,
  autoFetchQueries: [
    "reelshort drama full episode english",
    "reelshort full movie hd",
    "dramabox full movie english",
    "dramabox drama complete",
    "flextv drama full episode",
    "goodshort short drama",
    "rig tv short drama",
    "jowo short drama",
    "star short drama full",
    "flick reels short drama",
    "moboreels drama",
    "shortmax drama full episode",
    "kalostv drama",
    "dramaverse short drama",
    "micro drama vertical series",
    "chinese short drama english subtitle",
    "korean short drama full episode",
    "turkish short drama full episode",
    "ceo billionaire romance short drama",
    "revenge romance micro drama",
  ],
  monthlyPrice: 4.99,
  monthlyCurrency: "USD",
  freePreviewSeconds: 120,
  freeAccessSteps: [
    {
      title: "Step 1 · Subscribe to our YouTube channel",
      body: "Open the channel below and press the Subscribe button plus the 🔔 bell so you never miss a new episode drop.",
      ctaLabel: "Open YouTube Channel",
      ctaUrl: "https://www.youtube.com/",
      proofLabel: "Your YouTube account name",
    },
    {
      title: "Step 2 · Like & comment on the pinned video",
      body: "Watch the pinned trailer on the channel, drop a like and leave a comment with the word STEAMY.",
      ctaLabel: "Open pinned trailer",
      ctaUrl: "https://www.youtube.com/",
      proofLabel: "The comment you posted",
    },
    {
      title: "Step 3 · Share with 2 friends",
      body: "Share the platform link with two friends on WhatsApp, TikTok or Instagram and paste their names below.",
      ctaLabel: "Copy share link",
      ctaUrl: "/",
      proofLabel: "Names of the 2 friends you invited",
    },
  ],
  appLinks: [
    { label: "Android App", url: "https://play.google.com/store", icon: "🤖" },
    { label: "iOS App", url: "https://www.apple.com/app-store/", icon: "" },
    { label: "Telegram", url: "https://telegram.org/", icon: "✈️" },
    { label: "TikTok", url: "https://tiktok.com/", icon: "🎵" },
  ],
  dubLanguages: DEFAULT_DUB_LANGUAGES,
  dubCast: "male-female",
  ttsProvider: "openai",
  ttsApiKey: "",
  ttsModel: "gpt-4o-mini-tts",
  ttsVoice: "alloy",
  firebaseEnabled: true,
};

export async function getSettings(): Promise<SettingsData> {
  try {
    const rows = await db.select().from(settings).where(eq(settings.id, SETTINGS_ID)).limit(1);
    const stored = (rows[0]?.data ?? {}) as Partial<SettingsData>;
    return { ...DEFAULT_SETTINGS, ...stored };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export async function saveSettings(patch: Partial<SettingsData>): Promise<SettingsData> {
  const current = await getSettings();
  const next: SettingsData = { ...current, ...patch };
  await db
    .insert(settings)
    .values({ id: SETTINGS_ID, data: next })
    .onConflictDoUpdate({ target: settings.id, set: { data: next, updatedAt: new Date() } });
  return next;
}
