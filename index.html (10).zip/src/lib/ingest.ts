import { db } from "@/db";
import { fetchRuns, videos, type VideoRow } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";
import { classify, dmSweep, dmVideo, extractDmId, isDramaLike, type DmVideo } from "./dailymotion";
import { detectPlatform } from "./platforms";
import { firebaseSet } from "./firebase";

export async function ingestDmList(list: DmVideo[], kind = "auto") {
  let added = 0;
  const rows = list.map((v) => ({
    dmId: v.dmId,
    title: v.title,
    description: v.description,
    thumbnail: v.thumbnail,
    url: v.url,
    duration: v.duration,
    owner: v.owner,
    category: classify(v),
    platform: detectPlatform(`${v.title} ${v.tags.join(" ")} ${v.owner}`),
    tags: v.tags,
    language: v.language,
    views: v.views,
    trendingScore: Math.min(9999, Math.round(v.views / 100) + Math.round(v.duration / 60)),
  }));

  // Insert in batches so a large sweep does not become one round-trip per row —
  // that is what made cold starts slow enough to trip serverless timeouts.
  const BATCH = 25;
  for (let i = 0; i < rows.length; i += BATCH) {
    try {
      const inserted = await db
        .insert(videos)
        .values(rows.slice(i, i + BATCH))
        .onConflictDoNothing({ target: videos.dmId })
        .returning({ id: videos.id });
      added += inserted.length;
    } catch {
      /* skip a bad batch rather than failing the sweep */
    }
  }
  await db.insert(fetchRuns).values({ kind, queries: list.map((v) => v.title).slice(0, 20), found: list.length, added, ok: true, message: "ok" });
  return { added, found: list.length };
}

export async function autoFetch(queries: string[], perQuery: number, limit: number) {
  const list = await dmSweep(queries, perQuery);
  const dramas = list.filter(isDramaLike);
  // Platform-tagged titles (ReelShort, DramaBox, FlexTV, …) get priority so every
  // platform section stays stocked, then the rest fill the generic catalog.
  const tagged = dramas.filter((v) => detectPlatform(`${v.title} ${v.tags.join(" ")} ${v.owner}`) !== "other");
  const generic = dramas.filter((v) => detectPlatform(`${v.title} ${v.tags.join(" ")} ${v.owner}`) === "other");
  const cap = Math.max(60, limit * 3);
  const sorted = [...tagged, ...generic].sort((a, b) => b.views - a.views).slice(0, cap);
  const result = await ingestDmList(sorted, "auto");
  await mirrorVideos();
  return { ...result, platformTagged: tagged.length };
}

export async function ingestById(input: string) {
  const id = extractDmId(input);
  if (!id) return { ok: false as const, error: "Could not read a Dailymotion video id from that input." };
  const existing = await db.select().from(videos).where(eq(videos.dmId, id)).limit(1);
  if (existing[0]) return { ok: true as const, video: existing[0], existed: true };
  const v = await dmVideo(id);
  if (!v) return { ok: false as const, error: "Dailymotion returned no video for that id." };
  const category = classify(v);
  const platform = detectPlatform(`${v.title} ${v.tags.join(" ")} ${v.owner}`);
  const [row] = await db
    .insert(videos)
    .values({
      dmId: v.dmId,
      title: v.title,
      description: v.description,
      thumbnail: v.thumbnail,
      url: v.url,
      duration: v.duration,
      owner: v.owner,
      category,
      platform,
      tags: v.tags,
      language: v.language,
      views: v.views,
      trendingScore: Math.round(v.views / 100),
    })
    .returning();
  await mirrorVideos();
  warmCaptions(row.id);
  return { ok: true as const, video: row, existed: false };
}

/** Inserts a video straight from search-result data (works even if the /video endpoint 404s). */
export async function ingestFromSearch(item: {
  dmId: string;
  title: string;
  thumbnail?: string;
  duration?: number;
  owner?: string;
  views?: number;
  category?: string;
  description?: string;
}) {
  const existing = await db.select().from(videos).where(eq(videos.dmId, item.dmId)).limit(1);
  if (existing[0]) return { ok: true as const, video: existing[0], existed: true };
  const category = item.category || classify({ title: item.title, tags: [], description: item.description ?? "" });
  const platform = detectPlatform(`${item.title} ${item.owner ?? ""}`);
  const [row] = await db
    .insert(videos)
    .values({
      dmId: item.dmId,
      title: item.title,
      description: item.description ?? "",
      thumbnail: item.thumbnail ?? "",
      url: `https://www.dailymotion.com/video/${item.dmId}`,
      duration: item.duration ?? 0,
      owner: item.owner ?? "Dailymotion",
      category,
      platform,
      tags: [],
      language: "en",
      views: item.views ?? 0,
      trendingScore: Math.round((item.views ?? 0) / 100),
    })
    .returning();
  await mirrorVideos();
  warmCaptions(row.id);
  return { ok: true as const, video: row, existed: false };
}

export async function ingestByTitle(title: string, max = 8) {
  const { dmSearch } = await import("./dailymotion");
  const { videos: found } = await dmSearch(title, max, "relevance");
  const dramas = found.filter(isDramaLike);
  const list = (dramas.length ? dramas : found).slice(0, max);
  if (!list.length) return { added: 0, found: 0 };
  const result = await ingestDmList(list, "search-add");
  await mirrorVideos();
  return result;
}

/**
 * Hides catalog entries that Dailymotion no longer serves so viewers never hit
 * a dead player. Runs on a rolling window (oldest first) with every cron tick.
 */
export async function pruneDeadVideos(limit = 20) {
  const oldest = await db
    .select({ id: videos.id, dmId: videos.dmId })
    .from(videos)
    .where(eq(videos.hidden, false))
    .orderBy(videos.createdAt)
    .limit(limit);
  if (!oldest.length) return { checked: 0, hidden: 0 };

  const { dmExists } = await import("./dailymotion");
  const results = await Promise.all(oldest.map(async (v) => ({ ...v, alive: await dmExists(v.dmId) })));
  const dead = results.filter((r) => !r.alive);
  for (const d of dead) {
    await db.update(videos).set({ hidden: true }).where(eq(videos.id, d.id));
  }
  return { checked: results.length, hidden: dead.length };
}

export async function listVideos(opts: { category?: string; search?: string; limit?: number; featured?: boolean } = {}) {
  const limit = opts.limit ?? 60;
  const base = db.select().from(videos);
  const conditions = [eq(videos.hidden, false)];
  if (opts.category && opts.category !== "All") conditions.push(eq(videos.category, opts.category));
  if (opts.featured) conditions.push(eq(videos.featured, true));
  if (opts.search) conditions.push(sql`${videos.title} ILIKE ${"%" + opts.search + "%"}`);
  const rows = await base
    .where(sql.join(conditions, sql` AND `))
    .orderBy(desc(videos.trendingScore), desc(videos.createdAt))
    .limit(limit);
  return rows as VideoRow[];
}

export async function videoById(id: number): Promise<VideoRow | null> {
  const rows = await db.select().from(videos).where(eq(videos.id, id)).limit(1);
  return rows[0] ?? null;
}

export async function videoByDmId(dmId: string): Promise<VideoRow | null> {
  const rows = await db.select().from(videos).where(eq(videos.dmId, dmId)).limit(1);
  return rows[0] ?? null;
}

/** Generates English captions for a freshly added title in the background. */
async function warmCaptions(videoId: number) {
  try {
    const { warmTranscript } = await import("./captions");
    void warmTranscript(videoId, 120);
  } catch {
    /* never block ingest */
  }
}

export async function mirrorVideos() {
  const rows = await db.select().from(videos).orderBy(desc(videos.trendingScore)).limit(200);
  const payload = rows.map((v) => ({
    id: v.id,
    title: v.title,
    thumbnail: v.thumbnail,
    category: v.category,
    duration: v.duration,
    views: v.views,
  }));
  await firebaseSet("catalog/videos", payload);
}
