/**
 * Every micro-drama / short-drama platform the catalog tracks. Each one gets its
 * own section on the home page and its own set of auto-fetch queries, so a
 * viewer looking for ReelShort titles sees nothing but ReelShort titles.
 */
export type PlatformDef = {
  key: string;
  label: string;
  icon: string;
  tagline: string;
  patterns: RegExp[];
  queries: string[];
};

export const PLATFORMS: PlatformDef[] = [
  {
    key: "reelshort",
    label: "ReelShort",
    icon: "⚡",
    tagline: "Trending ReelShort originals",
    patterns: [/reel\s?short/i],
    queries: ["reelshort drama full episode english", "reelshort full movie hd", "reelshort new release drama"],
  },
  {
    key: "dramabox",
    label: "DramaBox",
    icon: "📦",
    tagline: "Full-length DramaBox movies",
    patterns: [/drama\s?box/i],
    queries: ["dramabox full movie english", "dramabox drama complete", "dramabox new drama 2026"],
  },
  {
    key: "flextv",
    label: "FlexTV",
    icon: "📺",
    tagline: "FlexTV vertical series",
    patterns: [/flex\s?tv/i],
    queries: ["flextv drama full episode", "flex tv short drama"],
  },
  {
    key: "goodshort",
    label: "GoodShort",
    icon: "✨",
    tagline: "GoodShort romance & revenge",
    patterns: [/good\s?short/i],
    queries: ["goodshort short drama", "good short drama full episode"],
  },
  {
    key: "rigtv",
    label: "RigTV",
    icon: "🎯",
    tagline: "RigTV trending micro dramas",
    patterns: [/rig\s?tv/i],
    queries: ["rig tv short drama", "rigtv drama episode"],
  },
  {
    key: "jowo",
    label: "Jowo",
    icon: "💎",
    tagline: "Jowo hit series",
    patterns: [/\bjowo\b/i],
    queries: ["jowo short drama", "jowo drama full"],
  },
  {
    key: "starshort",
    label: "StarShort",
    icon: "⭐",
    tagline: "StarShort exclusives",
    patterns: [/star\s?short/i],
    queries: ["star short drama full", "starshort drama"],
  },
  {
    key: "flickreels",
    label: "Flick Reels",
    icon: "🎞️",
    tagline: "Flick Reels originals",
    patterns: [/flick\s?reels?/i],
    queries: ["flick reels short drama", "flickreels drama"],
  },
  {
    key: "moboreels",
    label: "MoboReels",
    icon: "📱",
    tagline: "MoboReels vertical hits",
    patterns: [/mobo\s?reels?/i],
    queries: ["moboreels drama", "mobo reels short drama"],
  },
  {
    key: "shortmax",
    label: "ShortMax",
    icon: "🚀",
    tagline: "ShortMax billionaire romances",
    patterns: [/short\s?max/i],
    queries: ["shortmax drama full episode", "short max short drama"],
  },
  {
    key: "kalostv",
    label: "KalosTV",
    icon: "🌸",
    tagline: "KalosTV sweet romance",
    patterns: [/kalos\s?tv/i],
    queries: ["kalostv drama", "kalos tv short drama"],
  },
  {
    key: "drama-verse",
    label: "Drama Verse",
    icon: "🌐",
    tagline: "DramaVerse & 91Short hits",
    patterns: [/drama\s?verse/i, /91\s?short/i],
    queries: ["dramaverse short drama", "91short drama full"],
  },
];

export const platformByKey = (key: string) => PLATFORMS.find((p) => p.key === key);

/** Detects the originating platform from a title, owner name or tag list. */
export function detectPlatform(haystack: string): string {
  for (const platform of PLATFORMS) {
    if (platform.patterns.some((pattern) => pattern.test(haystack))) return platform.key;
  }
  return "other";
}

/** Auto-fetch queries that keep every platform section stocked. */
export function platformQueries(): string[] {
  return PLATFORMS.flatMap((p) => p.queries.slice(0, 2));
}
