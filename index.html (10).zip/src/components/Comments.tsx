"use client";

import { useEffect, useState } from "react";
import type { AccessInfo } from "@/lib/types";
import { Spinner, cx, inputCls } from "./ui";

type CommentDto = { id: number; author: string; body: string; createdAt: string; likes: number };

export function Comments({ videoId, initial }: { videoId: number; initial: CommentDto[] }) {
  const [items, setItems] = useState<CommentDto[]>(initial);
  const [author, setAuthor] = useState("");
  const [body, setBody] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => setItems(initial), [initial]);

  const submit = async () => {
    if (body.trim().length < 2) {
      setError("Write something first.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      const res = await fetch(`/api/videos/${videoId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ author: author || "Guest", body }),
      });
      const json = (await res.json()) as { ok: boolean; comment?: CommentDto; error?: string };
      if (!json.ok || !json.comment) {
        setError(json.error ?? "Could not post the comment.");
      } else {
        setItems([json.comment, ...items]);
        setBody("");
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="card space-y-4 rounded-3xl p-5">
      <div className="flex items-center justify-between">
        <h3 className="text-base font-bold text-white">💬 Comments <span className="text-white/35">({items.length})</span></h3>
        <span className="text-[11px] text-white/30">Live via Firebase RTDB</span>
      </div>

      <div className="space-y-2">
        <div className="flex flex-col gap-2 sm:flex-row">
          <input value={author} onChange={(e) => setAuthor(e.target.value)} placeholder="Your name (optional)" className={cx(inputCls, "sm:max-w-[220px]")} />
          <input
            value={body}
            onChange={(e) => setBody(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && submit()}
            placeholder="Share your thoughts about this drama — no spoilers!"
            className={inputCls}
          />
          <button onClick={submit} disabled={busy} className="btn-brand flex items-center justify-center gap-2 rounded-xl px-5 py-2.5 text-sm font-bold disabled:opacity-60">
            {busy ? <Spinner size={14} /> : null} Post
          </button>
        </div>
        {error ? <p className="text-[12px] text-red-300">{error}</p> : null}
      </div>

      <div className="max-h-[420px] space-y-3 overflow-y-auto pr-1">
        {items.length === 0 ? (
          <p className="py-6 text-center text-sm text-white/35">Be the first to comment.</p>
        ) : (
          items.map((c, i) => (
            <div key={c.id} className="anim-fade-up flex gap-3 rounded-2xl bg-white/[0.03] p-3" style={{ animationDelay: `${Math.min(i, 10) * 40}ms` }}>
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-gradient-to-br from-[var(--accent)] to-violet-600 text-sm font-bold">
                {c.author.slice(0, 1).toUpperCase()}
              </span>
              <div className="min-w-0 flex-1">
                <p className="flex items-baseline gap-2">
                  <span className="truncate text-[13px] font-bold text-white">{c.author}</span>
                  <span className="shrink-0 text-[11px] text-white/30">{new Date(c.createdAt).toLocaleDateString()}</span>
                </p>
                <p className="mt-0.5 break-words text-[13px] leading-relaxed text-white/65">{c.body}</p>
              </div>
            </div>
          ))
        )}
      </div>
    </section>
  );
}

export function AccessStrip({ access }: { access: AccessInfo | null }) {
  const premium = access?.level === "day" || access?.level === "month";
  if (premium) {
    return (
      <div className="flex flex-wrap items-center gap-2 rounded-2xl border border-emerald-400/25 bg-emerald-500/10 px-4 py-3 text-[13px] text-emerald-100">
        <span className="font-bold">✓ {access?.label}</span>
        {access?.expiresAt ? <span className="text-emerald-200/60">active until {new Date(access.expiresAt).toLocaleString()}</span> : null}
      </div>
    );
  }
  return null;
}
