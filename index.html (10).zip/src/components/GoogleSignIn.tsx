"use client";

import { getAuth, GoogleAuthProvider, signInWithPopup, signOut } from "firebase/auth";
import { useState } from "react";
import { getFirebaseApp } from "@/lib/firebase";
import { Spinner, cx, inputCls } from "./ui";

export type SessionUserDto = {
  id: number;
  provider: string;
  name: string;
  email: string;
  picture: string;
};

/** Official Google "G" mark — the professional way to present Google sign-in. */
export function GoogleMark({ size = 18 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" aria-hidden="true">
      <path
        fill="#EA4335"
        d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
      />
      <path
        fill="#4285F4"
        d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
      />
      <path
        fill="#FBBC05"
        d="M10.53 28.59A14.5 14.5 0 0 1 9.77 24c0-1.6.27-3.15.76-4.59l-7.98-6.19A23.94 23.94 0 0 0 0 24c0 3.87.92 7.52 2.56 10.78l7.97-6.19z"
      />
      <path
        fill="#34A853"
        d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.31-8.16 2.31-6.26 0-11.57-4.22-13.46-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
      />
    </svg>
  );
}

type Props = {
  onSignedIn?: (user: SessionUserDto) => void;
  compact?: boolean;
  label?: string;
};

export function GoogleSignIn({ onSignedIn, compact = false, label }: Props) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [showFallback, setShowFallback] = useState(false);
  const [form, setForm] = useState({ name: "", email: "" });

  const post = async (payload: Record<string, unknown>) => {
    const res = await fetch("/api/auth", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const json = (await res.json()) as { ok: boolean; user?: SessionUserDto; error?: string };
    if (!json.ok || !json.user) throw new Error(json.error ?? "Sign in failed");
    onSignedIn?.(json.user);
    window.dispatchEvent(new CustomEvent("steam:auth"));
  };

  const signIn = async () => {
    setBusy(true);
    setError("");
    try {
      const auth = getAuth(getFirebaseApp());
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: "select_account" });
      const cred = await signInWithPopup(auth, provider);
      const u = cred.user;
      await post({
        provider: "google",
        uid: u.uid,
        email: u.email ?? "",
        name: u.displayName ?? "",
        picture: u.photoURL ?? "",
      });
    } catch (e) {
      const message = e instanceof Error ? e.message : "Google sign-in failed";
      if (/popup|cancelled|closed|auth\/unauthorized-domain|configuration-not-found|operation-not-allowed/i.test(message)) {
        setShowFallback(true);
        setError("");
      } else {
        setError("Google sign-in is unavailable on this domain. Use email below.");
        setShowFallback(true);
      }
    } finally {
      setBusy(false);
    }
  };

  const signInEmail = async () => {
    setBusy(true);
    setError("");
    try {
      await post({ provider: "email", email: form.email, name: form.name });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not create the account");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-3">
      <button
        onClick={signIn}
        disabled={busy}
        className={cx(
          "flex w-full items-center justify-center gap-3 rounded-full bg-white px-5 py-3 text-[14px] font-semibold text-[#1f1f1f] shadow-[0_10px_30px_-14px_rgba(255,255,255,0.6)] transition hover:bg-white/90 active:scale-[0.99] disabled:opacity-60",
          compact && "py-2.5 text-[13px]",
        )}
      >
        {busy ? <Spinner size={16} /> : <GoogleMark size={compact ? 16 : 18} />}
        {label ?? "Continue with Google"}
      </button>

      {showFallback ? (
        <div className="anim-fade-in space-y-2 rounded-2xl border border-white/10 bg-black/40 p-4">
          <p className="text-[12px] text-white/50">
            Google sign-in needs this domain authorised in Firebase. Meanwhile, create your account with email — your subscription and premium
            features stay attached to it.
          </p>
          <div className="grid gap-2 sm:grid-cols-2">
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Full name" className={inputCls} />
            <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="you@email.com" className={inputCls} />
          </div>
          <button onClick={signInEmail} disabled={busy} className="btn-brand w-full rounded-full py-2.5 text-[13px] font-bold disabled:opacity-60">
            {busy ? <Spinner size={14} /> : null} Create account
          </button>
        </div>
      ) : null}

      {error && !showFallback ? <p className="text-[12px] text-red-300">{error}</p> : null}
    </div>
  );
}

export async function logOut() {
  try {
    await signOut(getAuth(getFirebaseApp()));
  } catch {
    /* not signed in to firebase */
  }
  await fetch("/api/auth", { method: "DELETE" });
  window.dispatchEvent(new CustomEvent("steam:auth"));
}
