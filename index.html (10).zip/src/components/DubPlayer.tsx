"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { AccessInfo, ApiVideo, DubCueDto, PublicSettings } from "@/lib/types";
import { DUB_LANGUAGES, VOICE_PRESETS, languageByCode } from "@/lib/languages";
import { assignCharacters, buildSegments, type DubSegment } from "@/lib/dub";
import { Badge, Spinner, cx } from "./ui";

/* ----------------------------- Dailymotion SDK ---------------------------- */

type DmPlayer = {
  play?: () => void;
  pause?: () => void;
  seek?: (t: number) => void;
  setVolume?: (v: number) => void;
  setMuted?: (m: boolean) => void;
  load?: (id: string) => void;
  addEventListener?: (ev: string, cb: (e: unknown) => void) => void;
};

type DmNamespace = { player: (el: HTMLElement | null, opts: Record<string, unknown>) => DmPlayer };

declare global {
  interface Window {
    DM?: DmNamespace;
  }
}

let sdkPromise: Promise<DmNamespace> | null = null;
function loadDmSdk(): Promise<DmNamespace> {
  if (typeof window === "undefined") return Promise.reject(new Error("no window"));
  if (window.DM) return Promise.resolve(window.DM);
  if (sdkPromise) return sdkPromise;
  sdkPromise = new Promise<DmNamespace>((resolve, reject) => {
    const existing = document.querySelector<HTMLScriptElement>("script[data-dm-sdk]");
    const script = existing ?? document.createElement("script");
    script.dataset.dmSdk = "1";
    script.src = "https://geo.dailymotion.com/player.js";
    script.async = true;
    script.onerror = () => reject(new Error("sdk failed"));
    document.head.appendChild(script);
    let tries = 0;
    const t = setInterval(() => {
      tries++;
      if (window.DM) {
        clearInterval(t);
        resolve(window.DM);
      } else if (tries > 80) {
        clearInterval(t);
        reject(new Error("sdk timeout"));
      }
    }, 100);
  });
  return sdkPromise;
}

const readEvent = (e: unknown): Record<string, unknown> => {
  if (!e || typeof e !== "object") return {};
  const rec = e as Record<string, unknown>;
  const detail = rec.detail as Record<string, unknown> | undefined;
  const data = rec.data as Record<string, unknown> | undefined;
  return { ...rec, ...(detail ?? {}), ...(data ?? {}) };
};

/* --------------------------- speech segment model ------------------------- */

/** Length-weighted karaoke word timings for a caption window. */
function timeWordsLocal(text: string, start: number, end: number): { w: string; t: number; d: number }[] {
  const words = text.split(/\s+/).filter(Boolean);
  if (!words.length) return [];
  const span = Math.max(0.4, end - start);
  const weights = words.map((w) => Math.max(2, w.replace(/[^\p{L}\p{N}]/gu, "").length) + 1);
  const total = weights.reduce((a, b) => a + b, 0);
  let cursor = start;
  return words.map((w, i) => {
    const d = (weights[i] / total) * span;
    const item = { w, t: Number(cursor.toFixed(3)), d: Number(d.toFixed(3)) };
    cursor += d;
    return item;
  });
}

/* -------------------------------- component ------------------------------- */

type Props = {
  video: ApiVideo;
  access: AccessInfo | null;
  settings: PublicSettings | null;
};

export function DubPlayer({ video, access, settings }: Props) {
  const premium = access?.level === "day" || access?.level === "month";
  const previewLimit = settings?.freePreviewSeconds ?? 120;

  const [lang, setLang] = useState("en");
  const [dubOn, setDubOn] = useState(false);
  const [captionsOn, setCaptionsOn] = useState(true);
  const [dualCaptions, setDualCaptions] = useState(true);
  const [preset, setPreset] = useState("studio");
  const [voiceURI, setVoiceURI] = useState("");
  const [duckVolume, setDuckVolume] = useState(0.12);
  const [captionSize, setCaptionSize] = useState(1);
  const [showTranscript, setShowTranscript] = useState(false);
  const [captionSourceLabel, setCaptionSourceLabel] = useState("Auto-generated from the original audio");

  const [cues, setCues] = useState<DubCueDto[]>([]);
  const [trackSource, setTrackSource] = useState("");
  const [engine, setEngine] = useState<{ provider: string; model: string; voice: string; voices: string[]; ready: boolean }>({
    provider: "browser",
    model: "",
    voice: "alloy",
    voices: [],
    ready: false,
  });
  /** Neural dub track from the Linly-Dubbing worker (Whisper ASR + Edge TTS). */
  const [dubTrack, setDubTrack] = useState<{
    engine: string;
    engineLabel?: string;
    from: number;
    total: number;
    clips: { index: number; start: number; end: number; audio: string | null; duration: number; speed: number; speaker?: string }[];
  } | null>(null);
  const [trackLoading, setTrackLoading] = useState(false);
  const [trackBusy, setTrackBusy] = useState(true);
  const [trackError, setTrackError] = useState("");
  const [premiumRequired, setPremiumRequired] = useState(false);

  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(video.duration || 0);
  const [previewLocked, setPreviewLocked] = useState(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [panelOpen, setPanelOpen] = useState(true);
  const [studioNote, setStudioNote] = useState("");
  const [mode, setMode] = useState<"loading" | "sdk" | "iframe">("loading");
  const [failed, setFailed] = useState(false);
  const [ready, setReady] = useState(false);

  /* -------------------------------- zoom ---------------------------------- */
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [dragging, setDragging] = useState(false);
  const [showZoomHint, setShowZoomHint] = useState(false);
  const stageRef = useRef<HTMLDivElement>(null);
  const dragStart = useRef<{ x: number; y: number; px: number; py: number } | null>(null);

  const clampPan = useCallback((next: { x: number; y: number }, z: number) => {
    const el = stageRef.current;
    const maxX = ((z - 1) * (el?.clientWidth ?? 0)) / 2;
    const maxY = ((z - 1) * (el?.clientHeight ?? 0)) / 2;
    return {
      x: Math.max(-maxX, Math.min(maxX, next.x)),
      y: Math.max(-maxY, Math.min(maxY, next.y)),
    };
  }, []);

  const applyZoom = useCallback(
    (next: number) => {
      const z = Math.max(1, Math.min(3, Number(next.toFixed(2))));
      setZoom(z);
      setPan((p) => clampPan(p, z));
      if (z === 1) setPan({ x: 0, y: 0 });
    },
    [clampPan],
  );

  /** Zoom-to-fill: crops the letterboxing so vertical dramas fill the player. */
  const fill = useCallback(() => {
    const el = stageRef.current;
    const box = el && el.clientHeight ? el.clientWidth / el.clientHeight : 16 / 9;
    // Most Dailymotion micro dramas are letterboxed 16:9 inside a wide frame.
    const z = Math.max(1, Math.min(3, 16 / 9 / box));
    setZoom(Number(z.toFixed(2)));
    setPan({ x: 0, y: 0 });
    setShowZoomHint(true);
    setTimeout(() => setShowZoomHint(false), 2600);
  }, []);

  const resetZoom = useCallback(() => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  }, []);

  // Keyboard zoom shortcuts
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (e.key === "+" || e.key === "=") applyZoom(zoom + 0.25);
      if (e.key === "-" || e.key === "_") applyZoom(zoom - 0.25);
      if (e.key === "0") resetZoom();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [applyZoom, resetZoom, zoom]);

  const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (zoom <= 1) return;
    dragStart.current = { x: e.clientX, y: e.clientY, px: pan.x, py: pan.y };
    setDragging(true);
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
  };
  const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const start = dragStart.current;
    if (!start || zoom <= 1) return;
    setPan(clampPan({ x: start.px + (e.clientX - start.x), y: start.py + (e.clientY - start.y) }, zoom));
  };
  const onPointerUp = () => {
    dragStart.current = null;
    setDragging(false);
  };
  const onDoubleClick = () => {
    if (zoom > 1) resetZoom();
    else {
      applyZoom(2);
      setShowZoomHint(true);
      setTimeout(() => setShowZoomHint(false), 2600);
    }
  };

  const containerRef = useRef<HTMLDivElement>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const playerRef = useRef<DmPlayer | null>(null);
  const readyRef = useRef(false);
  const timeRef = useRef(0);
  const stampRef = useRef(0);
  const playingRef = useRef(false);
  const queueRef = useRef(0);
  const langRef = useRef(lang);
  const dubRef = useRef(dubOn);
  const duckRef = useRef(duckVolume);
  const presetRef = useRef(preset);
  const voiceRef = useRef(voiceURI);
  const segmentsRef = useRef<DubSegment[]>([]);
  const captionRef = useRef<DubSegment[]>([]);
  /** Neural audio clips cached per phrase index (OpenAI dub). */
  const clipsRef = useRef<Map<number, HTMLAudioElement>>(new Map());
  const dubTrackRef = useRef(dubTrack);
  const engineRef = useRef(engine);
  const resetRef = useRef(0);

  useEffect(() => {
    engineRef.current = engine;
  }, [engine]);
  useEffect(() => {
    dubTrackRef.current = dubTrack;
  }, [dubTrack]);

  /* ----------------------- Linly-Dubbing neural track ---------------------- */
  useEffect(() => {
    fetch("/api/dub/render", { cache: "no-store" })
      .then((r) => r.json())
      .then((json: { engine?: string; engineLabel?: string }) => {
        if (json.engine) setEngine((e) => ({ ...e, provider: json.engine!, model: json.engineLabel ?? e.model, ready: json.engine === "linly-dubbing" }));
      })
      .catch(() => undefined);
  }, [premium]);

  const loadDubWindow = useCallback(
    async (from: number, count = 8) => {
      if (!premium || lang === "en" || !dubOn) return;
      setTrackLoading(true);
      try {
        const res = await fetch("/api/dub/render", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ videoId: video.id, lang, from, count }),
        });
        if (!res.ok) return;
        const json = (await res.json()) as NonNullable<typeof dubTrack>;
        setDubTrack(json);
        (json.clips ?? []).forEach((clip) => {
          if (!clip.audio || clipsRef.current.has(clip.index)) return;
          const audio = new Audio(clip.audio);
          audio.preload = "auto";
          audio.volume = 1;
          clipsRef.current.set(clip.index, audio);
        });
      } finally {
        setTrackLoading(false);
      }
    },
    [dubOn, lang, premium, video.id],
  );

  useEffect(() => {
    clipsRef.current.clear();
    setDubTrack(null);
    if (premium && lang !== "en" && dubOn) void loadDubWindow(0, 8);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lang, premium, dubOn, video.id]);

  useEffect(() => {
    langRef.current = lang;
    dubRef.current = dubOn;
    duckRef.current = duckVolume;
    presetRef.current = preset;
    voiceRef.current = voiceURI;
  }, [lang, dubOn, duckVolume, preset, voiceURI]);

  /** Phrases actually spoken by the dub engine. */
  const segments = useMemo(() => buildSegments(cues), [cues]);
  useEffect(() => {
    segmentsRef.current = segments;
    queueRef.current = 0;
    window.speechSynthesis?.cancel();
  }, [segments]);

  /* ------------------------------ player setup ----------------------------- */
  useEffect(() => {
    let disposed = false;
    readyRef.current = false;
    setReady(false);
    setFailed(false);
    setMode("loading");
    timeRef.current = 0;
    setTime(0);
    queueRef.current = 0;

    const fallback = setTimeout(() => {
      if (!disposed && !readyRef.current) {
        setMode("iframe");
        setStudioNote("Synced player unavailable — using the standard Dailymotion player. Press play, then tap Start captions.");
      }
    }, 6500);

    loadDmSdk()
      .then((DM) => {
        if (disposed || !containerRef.current || typeof DM.player !== "function") throw new Error("sdk shape");
        const player = DM.player(containerRef.current, {
          video: video.dmId,
          width: "100%",
          height: "100%",
          params: { autoplay: false, mute: false, "ui-highlight": "e11d48" },
        });
        playerRef.current = player;

        const markReady = () => {
          if (disposed || readyRef.current) return;
          readyRef.current = true;
          setReady(true);
          setMode("sdk");
        };
        player.addEventListener?.("apiready", markReady);
        player.addEventListener?.("video_start", markReady);
        player.addEventListener?.("start", markReady);
        player.addEventListener?.("playing", markReady);
        player.addEventListener?.("durationchange", (e) => {
          const d = Number(readEvent(e).duration);
          if (d > 0) setDuration(d);
        });
        player.addEventListener?.("timeupdate", (e) => {
          const rec = readEvent(e);
          const t = Number(rec.time ?? rec.currentTime ?? 0);
          if (Number.isFinite(t) && t > 0) {
            timeRef.current = t;
            stampRef.current = performance.now();
          }
        });
        player.addEventListener?.("playing", () => {
          playingRef.current = true;
          setPlaying(true);
          stampRef.current = performance.now();
        });
        player.addEventListener?.("paused", () => {
          playingRef.current = false;
          setPlaying(false);
          window.speechSynthesis?.cancel();
        });
        player.addEventListener?.("ended", () => {
          playingRef.current = false;
          setPlaying(false);
        });
        player.addEventListener?.("error", () => {
          if (!disposed) setFailed(true);
        });
      })
      .catch(() => {
        if (!disposed) {
          setMode("iframe");
          setStudioNote("Synced player unavailable — using the standard Dailymotion player. Press play, then tap Start captions.");
        }
      });

    return () => {
      disposed = true;
      clearTimeout(fallback);
      window.speechSynthesis?.cancel();
      if (containerRef.current) containerRef.current.innerHTML = "";
      playerRef.current = null;
    };
  }, [video.dmId]);

  /* --------------------- plain-embed fallback event sync ------------------- */
  useEffect(() => {
    if (mode !== "iframe") return;
    const onMessage = (event: MessageEvent) => {
      if (typeof event.data !== "string") return;
      try {
        const parsed = JSON.parse(event.data) as Record<string, unknown>;
        const nested = (parsed.data ?? parsed.detail ?? {}) as Record<string, unknown>;
        const t = Number(parsed.time ?? parsed.currentTime ?? nested.time ?? NaN);
        if (Number.isFinite(t) && t >= 0) {
          timeRef.current = t;
          stampRef.current = performance.now();
        }
        const ev = String(parsed.event ?? parsed.name ?? "");
        if (ev === "playing" || ev === "play" || ev === "video_start") {
          playingRef.current = true;
          setPlaying(true);
          stampRef.current = performance.now();
        }
        if (ev === "paused" || ev === "pause" || ev === "ended" || ev === "end") {
          playingRef.current = false;
          setPlaying(false);
          window.speechSynthesis?.cancel();
        }
      } catch {
        /* not a player message */
      }
    };
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, [mode]);

  /* -------------------------------- voices -------------------------------- */
  useEffect(() => {
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    const load = () => setVoices(window.speechSynthesis.getVoices());
    load();
    window.speechSynthesis.onvoiceschanged = load;
    const t = setTimeout(load, 900);
    return () => clearTimeout(t);
  }, []);

  const langVoices = useMemo(() => {
    const target = languageByCode(lang)?.speech ?? "en-US";
    const prefix = target.split("-")[0].toLowerCase();
    const matches = voices.filter((v) => v.lang.replace("_", "-").toLowerCase().startsWith(prefix));
    const score = (v: SpeechSynthesisVoice) =>
      (/natural|neural|online|premium|enhanced/i.test(v.name) ? -40 : 0) + (/google|microsoft|samsung|apple/i.test(v.name) ? -12 : 0) + (v.localService ? 2 : -4);
    return [...matches].sort((a, b) => score(a) - score(b));
  }, [voices, lang]);

  useEffect(() => {
    if (langVoices.length && !langVoices.some((v) => v.voiceURI === voiceURI)) setVoiceURI(langVoices[0].voiceURI);
  }, [langVoices, voiceURI]);

  /* --------------------------- neural dub engine --------------------------- */
  useEffect(() => {
    fetch("/api/dub/tts", { cache: "no-store" })
      .then((r) => r.json())
      .then((json: typeof engine) => setEngine(json))
      .catch(() => undefined);
  }, []);

  /** Fetches one neural clip; returns null when the API is unavailable. */
  const fetchClip = useCallback(
    async (index: number, segment: DubSegment) => {
      if (clipsRef.current.has(index)) return;
      try {
        const res = await fetch("/api/dub/tts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ videoId: video.id, lang, text: segment.text, voice: engine.voice }),
        });
        if (!res.ok) {
          if (res.status === 502 || res.status === 503) setEngine((e) => ({ ...e, ready: false, provider: "browser" }));
          return;
        }
        const json = (await res.json()) as { audio?: string };
        if (!json.audio) return;
        const audio = new Audio(json.audio);
        audio.preload = "auto";
        audio.volume = 1;
        clipsRef.current.set(index, audio);
      } catch {
        setEngine((e) => ({ ...e, ready: false, provider: "browser" }));
      }
    },
    [engine.voice, lang, video.id],
  );

  // Pre-roll the next two phrases so the dub never stalls.
  useEffect(() => {
    if (!engine.ready || !dubOn || !segments.length) return;
    const next = segments.findIndex((sg, i) => sg.start > time && i >= 0);
    const from = next === -1 ? segments.length - 2 : Math.max(0, next - 1);
    for (let i = from; i < Math.min(segments.length, from + 3); i++) void fetchClip(i, segments[i]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [engine.ready, dubOn, segments, Math.floor(time / 4)]);

  const loadDubWindowRef = useRef(loadDubWindow);
  useEffect(() => {
    loadDubWindowRef.current = loadDubWindow;
  }, [loadDubWindow]);

  /** Plays a neural clip, time-stretched to fit its window. */
  const playClip = useCallback((index: number, segment: DubSegment) => {
    const clip = clipsRef.current.get(index);
    if (!clip) return false;
    clip.currentTime = 0;
    clip.volume = 1;
    const span = Math.max(1.2, segment.end - segment.start);
    const natural = Number.isFinite(clip.duration) && clip.duration > 0 ? clip.duration : span * 0.8;
    clip.playbackRate = Math.min(2, Math.max(0.75, natural / span));
    void clip.play().catch(() => undefined);
    return true;
  }, []);

  /* ------------------------------ dubbing track ---------------------------- */
  useEffect(() => {
    let cancelled = false;
    setTrackBusy(true);
    setTrackError("");
    setPremiumRequired(false);
    queueRef.current = 0;

    const load = async (target: string): Promise<{ cues?: DubCueDto[]; source?: string } | null> => {
      const res = await fetch(`/api/dub/track?videoId=${video.id}&lang=${encodeURIComponent(target)}`);
      if (res.status === 402) {
        setPremiumRequired(true);
        return target === "en" ? null : load("en");
      }
      if (!res.ok) throw new Error("Could not build the dub track");
      return (await res.json()) as { cues?: DubCueDto[]; source?: string };
    };

    load(lang)
      .then((json: { cues?: DubCueDto[]; source?: string } | null) => {
        if (cancelled || !json) return;
        setCues(json.cues ?? []);
        setTrackSource(String(json.source ?? ""));
        setCaptionSourceLabel(
          String(json.source ?? "").includes("linly")
            ? "Auto-generated (Whisper) from the original audio"
            : String(json.source ?? "").includes("dailymotion")
              ? "Official subtitle track"
              : "Auto captions",
        );
      })
      .catch((e: Error) => !cancelled && setTrackError(e.message))
      .finally(() => !cancelled && setTrackBusy(false));
    return () => {
      cancelled = true;
    };
  }, [video.id, lang, premium]);

  /* --------------------------- dub audio scheduler ------------------------- */
  /** Speaks one whole phrase. Rate is fitted so the phrase fits its window. */
  const speak = useCallback((segment: DubSegment) => {
    const synth = typeof window === "undefined" ? undefined : window.speechSynthesis;
    if (!synth || !segment.text) return;
    const cfg = VOICE_PRESETS.find((p) => p.key === presetRef.current) ?? VOICE_PRESETS[0];
    const span = Math.max(1.2, segment.end - segment.start);
    // Natural delivery: ~2.6 words/sec, ~15 chars/sec — whichever is slower.
    const words = segment.text.split(/\s+/).length;
    const natural = Math.max(words / 2.7, segment.text.length / 15.5);
    // Target ~82% of the window so phrases keep a natural breathing pause.
    const rate = Math.min(1.4, Math.max(0.85, (natural / (span * 0.82)) * cfg.rate));

    const utterance = new SpeechSynthesisUtterance(segment.text);
    const pool = langVoices.length ? langVoices : voices;
    const chosen = pool.find((v) => v.voiceURI === voiceRef.current) ?? pool[0];
    if (chosen) {
      utterance.voice = chosen;
      utterance.lang = chosen.lang;
    }
    // Distinct register per speaking turn — the "cast" of the dub.
    const seed = segment.speaker.split("").reduce((a, c) => a + c.charCodeAt(0), 0) + segment.start;
    utterance.pitch = Math.min(1.9, Math.max(0.55, cfg.pitch * (0.9 + ((seed % 9) / 9) * 0.22)));
    utterance.rate = rate;
    utterance.volume = 1;
    // Never cancel here — cutting an utterance mid-sentence is what makes a dub
    // sound broken. Phrases queue back to back like a real audio track.
    synth.speak(utterance);
  }, [langVoices, voices]);

  /** Stops every neural clip that might still be playing. */
  const stopClips = useCallback(() => {
    clipsRef.current.forEach((clip) => {
      clip.pause();
      clip.currentTime = 0;
    });
  }, []);

  const resetDub = useCallback(() => {
    queueRef.current = 0;
    window.speechSynthesis?.cancel();
    stopClips();
    resetRef.current++;
  }, [stopClips]);

  useEffect(() => {
    let raf = 0;
    let lastUi = 0;
    let lastTick = 0;

    const loop = () => {
      raf = requestAnimationFrame(loop);
      if (playingRef.current) {
        const now = performance.now();
        timeRef.current += (now - stampRef.current) / 1000;
        stampRef.current = now;
      }
      const t = timeRef.current;

      // Free preview window
      if (!premium && t >= previewLimit && t > 2 && !previewLocked) {
        setPreviewLocked(true);
        playingRef.current = false;
        setPlaying(false);
        playerRef.current?.pause?.();
        window.speechSynthesis?.cancel();
      }

      if (t - lastUi > 0.09) {
        lastUi = t;
        setTime(t);
      }

      // Schedule dub phrases roughly on their cue time, at most one ahead.
      if (t - lastTick > 0.12) {
        lastTick = t;
        const synth = window.speechSynthesis;
        const segs = segmentsRef.current;
        if (dubRef.current && playingRef.current && synth && segs.length) {
          while (queueRef.current < segs.length) {
            const seg = segs[queueRef.current];
            const spoken = captionRef.current[queueRef.current] ?? seg;
            if (spoken.end < t - 0.35) {
              queueRef.current++; // we are past it — skip instead of falling behind
              continue;
            }
            if (spoken.start > t + 0.3) break; // not due yet
            if (synth.speaking || synth.pending) break; // let the current phrase finish
            const idx = queueRef.current;
            const track = dubTrackRef.current;
            // stream the next window of the neural dub track
            if (track && idx >= track.from + Math.max(1, track.clips.length - 3) && track.from + track.clips.length < track.total) {
              void loadDubWindowRef.current(track.from + track.clips.length, 6);
            }
            if (engineRef.current.ready && clipsRef.current.has(idx)) {
              stopClips();
              if (!playClip(idx, seg)) speak(seg);
            } else {
              stopClips();
              speak(seg);
            }
            queueRef.current++;
            break;
          }
        }
      }
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [premium, previewLimit, previewLocked, speak]);

  // Re-arm the dub track when it is switched on/off or the language changes.
  useEffect(() => {
    if (!dubOn) {
      window.speechSynthesis?.cancel();
      stopClips();
    } else queueRef.current = 0;
  }, [dubOn, lang, stopClips]);

  // Premium granted mid-session → lift the preview lock immediately.
  useEffect(() => {
    if (premium) setPreviewLocked(false);
  }, [premium]);

  /* --------------------------- original audio duck ------------------------- */
  useEffect(() => {
    const p = playerRef.current;
    if (!p) return;
    if (dubOn && lang !== "en") {
      p.setMuted?.(duckVolume <= 0.01);
      p.setVolume?.(duckVolume);
    } else {
      p.setMuted?.(false);
      p.setVolume?.(1);
    }
  }, [dubOn, lang, duckVolume, playing, ready]);

  /* ---------------- captions locked to the real dub audio ------------------ */
  /**
   * Each neural clip is time-stretched by `speed`, so it is audible for
   * `duration / speed` seconds from its cue start. Re-timing the caption words
   * over that exact window is what keeps the highlighted word in step with the
   * voice instead of crawling across the whole slot.
   */
  const clipByIndex = useMemo(() => {
    const map = new Map<number, NonNullable<typeof dubTrack>["clips"][number]>();
    dubTrack?.clips?.forEach((clip) => map.set(clip.index, clip));
    return map;
  }, [dubTrack]);

  const castSegments = useMemo(() => assignCharacters(segments, "male-female"), [segments]);

  const captionSegments = useMemo<DubSegment[]>(() => {
    if (!segments.length) return segments;
    return segments.map((segment, index) => {
      const clip = clipByIndex.get(index);
      if (!clip?.audio || !clip.duration) return segment;
      const audible = Math.min(segment.end - segment.start, clip.duration / Math.max(0.5, clip.speed || 1));
      if (audible <= 0.3) return segment;
      const words = timeWordsLocal(segment.text, segment.start, segment.start + audible);
      return { ...segment, end: segment.start + audible, words };
    });
  }, [segments, clipByIndex]);

  useEffect(() => {
    captionRef.current = captionSegments;
  }, [captionSegments]);

  const activeSegment = useMemo(() => {
    if (!captionSegments.length) return null;
    return captionSegments.find((s) => time >= s.start && time < s.end) ?? null;
  }, [captionSegments, time]);

  const activeWordIndex = useMemo(() => {
    const words = activeSegment?.words;
    if (!words?.length) return -1;
    for (let i = 0; i < words.length; i++) {
      if (time >= words[i].t && time < words[i].t + words[i].d) return i;
    }
    return time >= words[words.length - 1].t + words[words.length - 1].d ? words.length - 1 : -1;
  }, [activeSegment, time]);

  const onScrub = (value: number) => {
    timeRef.current = value;
    stampRef.current = performance.now();
    setTime(value);
    resetDub();
    playerRef.current?.seek?.(value);
  };

  const togglePlay = () => {
    if (playing) {
      playingRef.current = false;
      setPlaying(false);
      playerRef.current?.pause?.();
      window.speechSynthesis?.cancel();
      return;
    }
    if (previewLocked && !premium) return;
    playingRef.current = true;
    setPlaying(true);
    stampRef.current = performance.now();
    queueRef.current = 0;
    playerRef.current?.play?.();
  };

  const currentLang = languageByCode(lang);
  const availableLangs = useMemo(() => {
    const allowed = settings?.dubLanguages ?? DUB_LANGUAGES.map((l) => l.code);
    return DUB_LANGUAGES.filter((l) => allowed.includes(l.code));
  }, [settings?.dubLanguages]);

  const currentVoice = langVoices.find((v) => v.voiceURI === voiceURI);

  return (
    <div className="space-y-4">
      {/* -------------------------------- stage -------------------------------- */}
      <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-black shadow-[0_30px_80px_-40px_rgba(0,0,0,1)]">
        <div
          ref={stageRef}
          className={cx("relative aspect-video w-full overflow-hidden bg-[#0b0b12]", zoom > 1 && !dragging ? "cursor-grab" : "", dragging ? "cursor-grabbing" : "")}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={onPointerUp}
          onPointerLeave={onPointerUp}
          onDoubleClick={onDoubleClick}
        >
          {/* zoomable video layer — captions stay crisp above it */}
          <div
            className="absolute inset-0"
            style={{
              transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
              transformOrigin: "center center",
              transition: dragging ? "none" : "transform 320ms cubic-bezier(0.22, 1, 0.36, 1)",
              willChange: "transform",
            }}
          >
          <div ref={containerRef} className={cx("absolute inset-0 h-full w-full", mode === "iframe" && "hidden")} />
          {mode === "iframe" ? (
            <iframe
              ref={iframeRef}
              src={`https://www.dailymotion.com/embed/video/${video.dmId}?autoplay=0&mute=0&api=1`}
              title={video.title}
              className="absolute inset-0 h-full w-full border-0"
              allow="autoplay; fullscreen; encrypted-media; picture-in-picture"
              allowFullScreen
            />
          ) : null}
          {mode === "loading" ? (
            <div className="absolute inset-0 grid place-items-center bg-[#0b0b12]">
              <div className="flex flex-col items-center gap-3">
                <span className="anim-pulse-ring grid h-14 w-14 place-items-center rounded-full bg-[var(--accent)]/15 text-2xl">▶</span>
                <p className="text-[12px] font-semibold uppercase tracking-widest text-white/40">Loading player…</p>
              </div>
            </div>
          ) : null}
          </div>

          {failed ? (
            <div className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-3 bg-black/90 px-6 text-center">
              <span className="text-3xl">😕</span>
              <h3 className="text-lg font-black text-white">This title is no longer available</h3>
              <p className="max-w-sm text-[13px] text-white/50">The uploader removed it from Dailymotion. Pick another drama — the catalog refreshes hourly.</p>
              <Link href="/" className="btn-brand rounded-full px-6 py-2.5 text-sm font-bold">
                Browse more dramas
              </Link>
            </div>
          ) : null}

          {/* active audio-track badge */}
          {playing ? (
            <div className="pointer-events-none absolute left-4 top-4 flex items-center gap-2 rounded-full border border-white/15 bg-black/70 px-3 py-1.5 backdrop-blur">
              {dubOn && lang !== "en" ? (
                <>
                  <span className="flex h-3 items-end gap-[2px]">
                    {[0, 1, 2].map((i) => (
                      <span key={i} className="eq-bar w-[3px] rounded-full bg-[var(--accent)]" style={{ animationDelay: `${i * 140}ms` }} />
                    ))}
                  </span>
                  <span className="text-[11px] font-bold uppercase tracking-widest text-white/80">
                    {currentLang?.flag} {currentLang?.nativeLabel} audio
                  </span>
                </>
              ) : (
                <span className="text-[11px] font-bold uppercase tracking-widest text-white/70">🔈 Original audio</span>
              )}
            </div>
          ) : null}

          {previewLocked && !premium ? (
            <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-4 bg-black/85 px-6 text-center backdrop-blur-sm">
              <Badge tone="brand">Free preview finished</Badge>
              <h3 className="max-w-md text-2xl font-black text-white">Keep watching — unlock everything</h3>
              <p className="max-w-md text-sm text-white/55">
                Unlock all episodes, every dubbing language and word-by-word captions. Use today&apos;s 4-digit code for a day, or go premium for a month.
              </p>
              <div className="flex flex-wrap justify-center gap-3">
                <Link href="/access" className="btn-brand rounded-full px-6 py-2.5 text-sm font-bold">
                  Enter day code
                </Link>
                <Link href="/subscribe" className="btn-ghost rounded-full px-6 py-2.5 text-sm font-bold">
                  Get premium
                </Link>
              </div>
            </div>
          ) : null}

          {trackBusy ? (
            <div className="absolute right-4 top-4 z-10 flex items-center gap-2 rounded-full bg-black/70 px-3 py-1.5 text-[11px] font-semibold text-white/70 backdrop-blur">
              <Spinner size={12} /> Building audio track…
            </div>
          ) : null}

          {/* zoom indicator + hint */}
          {zoom > 1 ? (
            <div className="pointer-events-none absolute right-4 bottom-4 z-10 flex items-center gap-2 rounded-full border border-white/15 bg-black/75 px-3 py-1.5 backdrop-blur">
              <span className="text-[11px] font-bold tabular-nums text-white/85">🔍 {Math.round(zoom * 100)}%</span>
              {pan.x || pan.y ? <span className="text-[10px] text-white/45">panned</span> : null}
            </div>
          ) : null}
          {showZoomHint ? (
            <div className="anim-fade-in pointer-events-none absolute left-1/2 top-4 z-10 -translate-x-1/2 rounded-full bg-black/75 px-4 py-1.5 text-[11px] font-semibold text-white/80 backdrop-blur">
              Drag to move the frame · double-click to reset
            </div>
          ) : null}
        </div>

      {/* ------------------------------ caption box ------------------------------ */}
      {captionsOn ? (
        <div className="border-t border-white/8 bg-[#0a0a12]">
          <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2">
            <div className="flex items-center gap-2">
              <span className="grid h-7 w-7 place-items-center rounded-lg bg-[var(--accent)]/15 text-[13px]">💬</span>
              <div>
                <p className="text-[12.5px] font-bold leading-none text-white">
                  Captions · {lang === "en" ? "English" : (currentLang?.nativeLabel ?? "English")}
                </p>
                <p className="mt-0.5 text-[10.5px] text-white/35">{captionSourceLabel}</p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-1.5">
              <button
                onClick={() => setDualCaptions((v) => !v)}
                className={cx(
                  "rounded-full border px-2.5 py-1 text-[10.5px] font-bold uppercase tracking-wider transition",
                  dualCaptions ? "border-transparent bg-[var(--accent)] text-white" : "border-white/10 bg-white/5 text-white/55 hover:text-white",
                )}
              >
                Dual
              </button>
              <button
                onClick={() => setCaptionSize((v) => Math.max(0.7, Number((v - 0.15).toFixed(2))))}
                className="btn-ghost h-7 w-7 rounded-full text-[12px] font-bold"
                aria-label="Smaller captions"
              >
                A−
              </button>
              <button
                onClick={() => setCaptionSize((v) => Math.min(1.9, Number((v + 0.15).toFixed(2))))}
                className="btn-ghost h-7 w-7 rounded-full text-[12px] font-bold"
                aria-label="Larger captions"
              >
                A+
              </button>
              <button
                onClick={() => setShowTranscript((v) => !v)}
                className="btn-ghost rounded-full px-2.5 py-1 text-[10.5px] font-bold uppercase tracking-wider"
              >
                {showTranscript ? "Hide transcript" : "Transcript"}
              </button>
            </div>
          </div>

          <div className="flex min-h-[92px] flex-col items-center justify-center gap-1.5 px-5 py-3.5 text-center">
            {trackBusy ? (
              <div className="flex items-center gap-2 text-[13px] font-semibold text-white/50">
                <Spinner size={14} /> Generating English captions from the original audio…
              </div>
            ) : activeSegment ? (
              <>
                <p
                  className="max-w-4xl font-extrabold leading-snug tracking-tight"
                  style={{ fontSize: `${captionSize * 1.3}rem` }}
                  dir={currentLang?.rtl ? "rtl" : "ltr"}
                >
                  {activeSegment.words.map((w, i) => (
                    <span key={`${w.w}-${i}`} className={cx("mx-[0.14em] inline-block", i <= activeWordIndex ? "word-active" : "text-white/40")}>
                      {w.w}
                    </span>
                  ))}
                </p>
                {dualCaptions && lang !== "en" ? (
                  <p className="max-w-3xl text-[13px] font-medium leading-relaxed text-white/50" dir="ltr">
                    {activeSegment.original}
                  </p>
                ) : null}
                <span className="flex items-center gap-2">
                  <span className="rounded-full bg-white/5 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-widest text-white/45">
                    {fmt(activeSegment.start)}
                  </span>
                  {(() => {
                    const idx = captionSegments.indexOf(activeSegment);
                    const character = castSegments[idx]?.character;
                    if (!character) return null;
                    const female = character.gender === "female";
                    return (
                      <span
                        className={cx(
                          "flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-widest",
                          female ? "bg-pink-500/15 text-pink-200" : "bg-sky-500/15 text-sky-200",
                        )}
                      >
                        {female ? "♀" : "♂"} {character.label}
                      </span>
                    );
                  })()}
                </span>
              </>
            ) : (
              <p className="text-[13px] text-white/35">{playing ? "…" : "Press play to start the dubbed captions"}</p>
            )}
          </div>

          {showTranscript ? (
            <div className="max-h-[220px] overflow-y-auto border-t border-white/5 bg-black/40">
              {captionSegments.map((segment, index) => {
                const active = segment === activeSegment;
                const i = index;
                return (
                  <button
                    key={`${segment.start}-${i}`}
                    onClick={() => onScrub(segment.start)}
                    className={cx(
                      "flex w-full gap-3 px-4 py-2 text-left transition",
                      active ? "bg-[var(--accent)]/12" : "hover:bg-white/[0.04]",
                    )}
                  >
                    <span className={cx("shrink-0 pt-0.5 font-mono text-[11px] tabular-nums", active ? "text-[var(--accent-soft)]" : "text-white/30")}>
                      {fmt(segment.start)}
                    </span>
                    <span className="min-w-0">
                      <span className={cx("block text-[13px] leading-snug", active ? "font-semibold text-white" : "text-white/60")}>
                        {segment.text}
                      </span>
                      {castSegments[i]?.character ? (
                        <span
                          className={cx(
                            "mt-0.5 inline-block rounded-full px-2 py-0.5 text-[9.5px] font-bold uppercase tracking-wider",
                            castSegments[i].character.gender === "female" ? "bg-pink-500/10 text-pink-200/80" : "bg-sky-500/10 text-sky-200/80",
                          )}
                        >
                          {castSegments[i].character.gender === "female" ? "♀" : "♂"} {castSegments[i].character.label}
                        </span>
                      ) : null}
                      {dualCaptions && lang !== "en" && segment.original && segment.original !== segment.text ? (
                        <span className="block text-[11.5px] leading-snug text-white/35">{segment.original}</span>
                      ) : null}
                    </span>
                  </button>
                );
              })}
            </div>
          ) : null}
        </div>
      ) : null}

        {/* ------------------------------ controls ----------------------------- */}
        <div className="space-y-3 border-t border-white/5 bg-[#08080e] px-4 py-3">
          <input
            type="range"
            min={0}
            max={Math.max(1, duration)}
            step={0.5}
            value={Math.min(time, duration)}
            onChange={(e) => onScrub(Number(e.target.value))}
            className="h-1.5 w-full cursor-pointer appearance-none rounded-full accent-[var(--accent)]"
            style={{
              background: `linear-gradient(90deg, var(--accent) ${(time / Math.max(1, duration)) * 100}%, rgba(255,255,255,0.15) ${(time / Math.max(1, duration)) * 100}%)`,
            }}
          />
          <div className="flex flex-wrap items-center gap-2">
            {mode === "iframe" ? (
              <>
                <button onClick={togglePlay} className="btn-brand rounded-full px-4 py-2 text-[12px] font-bold">
                  {playing ? "❚❚ Pause dubbing" : "▶ Start dubbing"}
                </button>
                <button onClick={() => onScrub(Math.max(0, time - 1))} className="btn-ghost h-9 rounded-full px-3 text-xs font-bold">
                  −1s
                </button>
                <button onClick={() => onScrub(time + 1)} className="btn-ghost h-9 rounded-full px-3 text-xs font-bold">
                  +1s
                </button>
                <span className="rounded-full bg-amber-400/10 px-3 py-1 text-[11px] font-semibold text-amber-200/80">
                  Sync mode · press play in the player, then tap Start dubbing
                </span>
              </>
            ) : (
              <>
                <button onClick={togglePlay} disabled={!ready} className="btn-brand grid h-10 w-10 place-items-center rounded-full text-sm font-bold disabled:opacity-40">
                  {playing ? "❚❚" : "▶"}
                </button>
                <button onClick={() => onScrub(Math.max(0, time - 10))} className="btn-ghost h-9 rounded-full px-3 text-xs font-bold">
                  −10s
                </button>
                <button onClick={() => onScrub(time + 10)} className="btn-ghost h-9 rounded-full px-3 text-xs font-bold">
                  +10s
                </button>
              </>
            )}
            <span className="ml-1 font-mono text-[12px] tabular-nums text-white/50">
              {fmt(time)} / {fmt(duration || video.duration)}
            </span>

            <div className="ml-auto flex flex-wrap items-center gap-2">
              <button
                onClick={() => setDubOn((v) => !v)}
                className={cx(
                  "rounded-full border px-3 py-1.5 text-[11px] font-bold uppercase tracking-wider transition",
                  dubOn && lang !== "en" ? "border-transparent bg-[var(--accent)] text-white" : "border-white/15 bg-white/5 text-white/55",
                )}
              >
                🎙️ {dubOn && lang !== "en" ? `${currentLang?.nativeLabel} audio` : "Original audio"}
              </button>
              <button
                onClick={() => setCaptionsOn((v) => !v)}
                aria-label="Toggle subtitles"
                className={cx(
                  "rounded-full border px-3 py-1.5 text-[11px] font-bold uppercase tracking-wider transition",
                  captionsOn ? "border-transparent bg-white/90 text-black" : "border-white/15 bg-white/5 text-white/55",
                )}
              >
                CC
              </button>
              <button
                onClick={() => setPanelOpen((v) => !v)}
                className="hidden rounded-full border border-white/15 bg-white/5 px-3 py-1.5 text-[11px] font-bold uppercase tracking-wider text-white/70 transition hover:text-white sm:block"
              >
                {dubOn && lang !== "en" ? `${currentLang?.flag ?? ""} ${currentLang?.nativeLabel ?? "Dub"}` : "Original"}
              </button>
              <div className="flex items-center gap-1 rounded-full border border-white/15 bg-white/5 px-1 py-0.5">
                <button onClick={() => applyZoom(zoom - 0.25)} aria-label="Zoom out" className="h-7 w-7 rounded-full text-[13px] font-bold text-white/70 transition hover:bg-white/10 hover:text-white">
                  −
                </button>
                <button
                  onClick={fill}
                  className="h-7 rounded-full px-2 text-[10.5px] font-bold uppercase tracking-wider text-white/70 transition hover:bg-white/10 hover:text-white"
                  title="Zoom to fill the player (crops the black bars)"
                >
                  Fill
                </button>
                <span className="min-w-[38px] text-center text-[10.5px] font-bold tabular-nums text-white/60">{Math.round(zoom * 100)}%</span>
                <button onClick={() => applyZoom(zoom + 0.25)} aria-label="Zoom in" className="h-7 w-7 rounded-full text-[13px] font-bold text-white/70 transition hover:bg-white/10 hover:text-white">
                  +
                </button>
                {zoom > 1 ? (
                  <button onClick={resetZoom} className="h-7 rounded-full px-2 text-[10.5px] font-bold uppercase tracking-wider text-white/70 transition hover:bg-white/10 hover:text-white">
                    Reset
                  </button>
                ) : null}
              </div>
              <button
                onClick={() => setPanelOpen((v) => !v)}
                className="btn-ghost rounded-full px-3 py-1.5 text-[11px] font-bold uppercase tracking-wider"
              >
                ⚙️ Audio &amp; subtitles
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* --------------------------- audio track panel -------------------------- */}
      {panelOpen ? (
        <div className="anim-fade-in card space-y-5 rounded-3xl p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="flex items-center gap-2 text-base font-bold text-white">🎧 Audio track</h3>
              <p className="text-[12px] text-white/40">
                Switch the voice track just like YouTube&apos;s multi-audio — the original score stays underneath and captions follow the dub.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Badge tone={engine.ready ? "brand" : "default"}>
                {engine.ready ? `🎙️ ${engine.model || "Open dubbing · Edge"}` : "device voices"}
              </Badge>
              {dubTrack ? <Badge>{dubTrack.clips.length}/{dubTrack.total} phrases ready</Badge> : null}
              {trackLoading ? <Badge tone="gold">rendering…</Badge> : null}
              {trackSource ? <Badge tone="gold">{trackSource.replace(/-/g, " ")}</Badge> : null}
              {segments.length ? <Badge>{segments.length} phrases</Badge> : null}
              {currentVoice ? <Badge>{currentVoice.name}</Badge> : null}
            </div>
          </div>

          {premiumRequired ? (
            <div className="rounded-2xl border border-[var(--accent)]/40 bg-[var(--accent)]/10 p-4 text-sm text-white/80">
              Dubbing into every language is a premium feature.{" "}
              <Link href="/subscribe" className="font-bold text-[var(--accent-soft)] underline">
                Unlock premium →
              </Link>
            </div>
          ) : null}
          {trackError ? <p className="text-sm text-red-300">{trackError}</p> : null}

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <p className="text-[11px] font-bold uppercase tracking-widest text-white/40">Audio track</p>
              <span className="text-[11px] text-white/30">{engine.provider === "linly-dubbing" ? "Linly-Dubbing · free" : "Neural dub"}</span>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => {
                  setLang("en");
                  setDubOn(false);
                }}
                className={cx(
                  "rounded-2xl border px-3.5 py-2 text-[12px] font-bold transition",
                  !dubOn && lang === "en"
                    ? "border-transparent bg-[var(--accent)] text-white shadow-lg"
                    : "border-white/10 bg-white/5 text-white/65 hover:border-white/25 hover:text-white",
                )}
              >
                🎬 Original (English)
              </button>
              {availableLangs.map((l) => {
                const locked = !premium && l.code !== "en";
                return (
                  <button
                    key={l.code}
                    onClick={() => {
                      setLang(l.code);
                      setDubOn(true);
                      resetDub();
                    }}
                    className={cx(
                      "rounded-2xl border px-3.5 py-2 text-[12px] font-bold transition",
                      dubOn && lang === l.code
                        ? "border-transparent bg-[var(--accent)] text-white shadow-lg"
                        : "border-white/10 bg-white/5 text-white/65 hover:border-white/25 hover:text-white",
                    )}
                  >
                    <span className="mr-1.5">{l.flag}</span>
                    {l.nativeLabel}
                    {locked ? <span className="ml-1.5 text-[10px] opacity-60">🔒</span> : null}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            <label className="space-y-1.5">
              <span className="text-[11px] font-bold uppercase tracking-widest text-white/40">Voice</span>
              <select value={voiceURI} onChange={(e) => setVoiceURI(e.target.value)} className="w-full rounded-xl border border-white/10 bg-black/50 px-3 py-2.5 text-sm text-white">
                {langVoices.length ? (
                  langVoices.map((v) => (
                    <option key={v.voiceURI} value={v.voiceURI}>
                      {v.name} {/natural|neural|online/i.test(v.name) ? "· Neural" : ""}
                    </option>
                  ))
                ) : (
                  <option value="">No voice for this language on this device</option>
                )}
              </select>
            </label>

            <label className="space-y-1.5">
              <span className="text-[11px] font-bold uppercase tracking-widest text-white/40">Dub preset</span>
              <select value={preset} onChange={(e) => setPreset(e.target.value)} className="w-full rounded-xl border border-white/10 bg-black/50 px-3 py-2.5 text-sm text-white">
                {VOICE_PRESETS.map((p) => (
                  <option key={p.key} value={p.key}>
                    {p.label}
                  </option>
                ))}
              </select>
            </label>

            <label className="space-y-1.5">
              <span className="text-[11px] font-bold uppercase tracking-widest text-white/40">Original audio level</span>
              <input
                type="range"
                min={0}
                max={100}
                value={Math.round(duckVolume * 100)}
                onChange={(e) => setDuckVolume(Number(e.target.value) / 100)}
                className="mt-3 h-1.5 w-full cursor-pointer appearance-none rounded-full bg-white/15 accent-[var(--accent)]"
              />
              <span className="text-[11px] text-white/35">{Math.round(duckVolume * 100)}% — keep the score audible under the dub.</span>
            </label>
          </div>

          <div className="space-y-3 border-t border-white/5 pt-4">
            <div className="flex flex-wrap items-center gap-2">
              <p className="text-[11px] font-bold uppercase tracking-widest text-white/40">Subtitles</p>
              <div className="flex flex-wrap gap-1.5">
                {[
                  { key: "off", label: "Off" },
                  { key: "on", label: currentLang?.nativeLabel ?? "On" },
                  { key: "dual", label: "Dual" },
                ].map((option) => {
                  const active = option.key === "off" ? !captionsOn : option.key === "on" ? captionsOn && !dualCaptions : captionsOn && dualCaptions;
                  return (
                    <button
                      key={option.key}
                      onClick={() => {
                        if (option.key === "off") setCaptionsOn(false);
                        else {
                          setCaptionsOn(true);
                          setDualCaptions(option.key === "dual");
                        }
                      }}
                      className={cx(
                        "rounded-full border px-3 py-1.5 text-[11px] font-bold transition",
                        active ? "border-transparent bg-[var(--accent)] text-white" : "border-white/10 bg-white/5 text-white/55 hover:text-white",
                      )}
                    >
                      {option.label}
                    </button>
                  );
                })}
              </div>
            </div>
            <label className="flex items-center gap-2 text-[12px] text-white/60">
              <input type="checkbox" checked={dualCaptions} onChange={(e) => setDualCaptions(e.target.checked)} className="accent-[var(--accent)]" />
              Dual subtitles (dub + original)
            </label>
            <label className="flex items-center gap-2 text-[12px] text-white/60">
              <span>Caption size</span>
              <input type="range" min={0.7} max={1.8} step={0.05} value={captionSize} onChange={(e) => setCaptionSize(Number(e.target.value))} className="h-1.5 w-28 cursor-pointer rounded-full bg-white/15 accent-[var(--accent)]" />
            </label>
            <p className="text-[11px] text-white/35">
              {engine.provider === "linly-dubbing"
                ? "Powered by Linly-Dubbing — faster-whisper transcribes the real audio with word timestamps, then Edge neural voices speak each phrase inside its original time window. No API key, no quota."
                : engine.provider === "openai"
                  ? `Studio neural dub via OpenAI (${engine.model}, voice: ${engine.voice}).`
                  : studioNote || "Using your device's neural voices. Phrases are spoken continuously with the original audio ducked underneath."}
            </p>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function fmt(s: number) {
  const total = Math.max(0, Math.floor(s));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const sec = total % 60;
  return h ? `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}` : `${m}:${String(sec).padStart(2, "0")}`;
}
