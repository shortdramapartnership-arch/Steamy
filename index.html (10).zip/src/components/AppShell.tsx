"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import type { AccessInfo, ApiChannel, ApiVideo, CatalogResponse, PublicSettings, SearchItem, SessionUser } from "@/lib/types";
import { GoogleMark, logOut } from "./GoogleSignIn";
import { useAnalytics } from "@/lib/analytics";
import { DUB_LANGUAGES } from "@/lib/languages";
import { Badge, PosterCard, Spinner, cx, inputCls } from "./ui";

type Ctx = {
  settings: PublicSettings | null;
  access: AccessInfo | null;
  user: SessionUser | null;
  reloadUser: () => void;
  hardRefresh: () => Promise<void>;
  videos: ApiVideo[];
  channels: ApiChannel[];
  loading: boolean;
  refresh: () => Promise<void>;
  openSearch: () => void;
};

const CatalogContext = createContext<Ctx>({
  settings: null,
  access: null,
  user: null,
  reloadUser: () => {},
  hardRefresh: async () => {},
  videos: [],
  channels: [],
  loading: true,
  refresh: async () => {},
  openSearch: () => {},
});

export const useCatalog = () => useContext(CatalogContext);

export function AppShell({ children }: { children: ReactNode }) {
  const [data, setData] = useState<CatalogResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchOpen, setSearchOpen] = useState(false);
  const [flash, setFlash] = useState<string | null>(null);
  useAnalytics();
  const [liveAccess, setLiveAccess] = useState<AccessInfo | null>(null);
  const pathname = usePathname();
  const router = useRouter();

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/catalog", { cache: "no-store" });
      if (res.ok) {
        const json = (await res.json()) as CatalogResponse;
        setData(json);
        setLiveAccess(json.access ?? null);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const loadUser = useCallback(async () => {
    try {
      const res = await fetch("/api/auth", { cache: "no-store" });
      if (!res.ok) return;
      const json = (await res.json()) as CatalogResponse;
      setData((cur) => (cur ? { ...cur, user: json.user ?? null, access: json.access ?? cur.access } : cur));
      setLiveAccess(json.access ?? null);
    } catch {
      /* ignore */
    }
  }, []);

  /**
   * Live access polling. When the developer approves a payment, premium turns on
   * for the viewer without a page reload — usually within a few seconds.
   */
  const prevLevel = useRef<AccessInfo["level"] | null>(null);
  useEffect(() => {
    let stop = false;
    const tick = async () => {
      try {
        const res = await fetch("/api/access", { cache: "no-store" });
        if (!res.ok || stop) return;
        const json = (await res.json()) as { access: AccessInfo };
        setData((cur) => (cur && json.access ? { ...cur, access: json.access } : cur));
        const level = json.access?.level;
        if (prevLevel.current && prevLevel.current !== "month" && prevLevel.current !== "day" && (level === "month" || level === "day")) {
          window.dispatchEvent(new CustomEvent("steam:unlocked", { detail: level }));
        }
        prevLevel.current = level ?? null;
      } catch {
        /* ignore */
      }
    };
    tick();
    const id = setInterval(tick, 15_000);
    const onVisible = () => document.visibilityState === "visible" && tick();
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      stop = true;
      clearInterval(id);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, []);

  useEffect(() => {
    const onAuth = () => loadUser();
    window.addEventListener("steam:auth", onAuth);
    return () => window.removeEventListener("steam:auth", onAuth);
  }, []);

  useEffect(() => {
    const onUnlocked = () => {
      setFlash("🎉 Premium activated — all dubbing languages unlocked.");
      refresh();
      loadUser();
      setTimeout(() => setFlash(null), 6000);
    };
    window.addEventListener("steam:unlocked", onUnlocked);
    return () => window.removeEventListener("steam:unlocked", onUnlocked);
  }, [refresh]);

  // Keep the trending catalog warm. The cron is fired and forgotten — waiting on
  // it would stall the first paint on hosts with short function timeouts.
  useEffect(() => {
    let cancelled = false;
    const tick = () => {
      void fetch("/api/cron/autofetch", { method: "POST" }).catch(() => undefined);
    };
    const initial = setTimeout(tick, 4000);
    const interval = setInterval(tick, 60 * 60 * 1000);
    return () => {
      cancelled = true;
      clearTimeout(initial);
      clearInterval(interval);
    };
  }, []);

  const videos = data?.videos ?? [];

  // While the catalog is being seeded for the first time, poll until it lands.
  useEffect(() => {
    if (!loading && videos.length > 0) return;
    let attempts = 0;
    const id = setInterval(() => {
      attempts += 1;
      if (attempts > 20) {
        clearInterval(id);
        return;
      }
      refresh();
    }, 4000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading, videos.length]);

  const settings = data?.settings ?? null;

  useEffect(() => {
    if (settings?.accent) {
      document.documentElement.style.setProperty("--accent", settings.accent);
      document.documentElement.style.setProperty("--accent-soft", settings.accent);
    }
  }, [settings?.accent]);

  useEffect(() => {
    if (searchOpen) {
      const onKey = (e: KeyboardEvent) => e.key === "Escape" && setSearchOpen(false);
      window.addEventListener("keydown", onKey);
      return () => window.removeEventListener("keydown", onKey);
    }
  }, [searchOpen]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const value = useMemo<Ctx>(
    () => ({
      settings,
      access: data?.access ?? null,
      user: data?.user ?? null,
      reloadUser: loadUser,
      hardRefresh: refresh,
      videos,
      channels: data?.channels ?? [],
      loading,
      refresh,
      openSearch: () => setSearchOpen(true),
    }),
    [settings, data, loading, refresh, loadUser, videos],
  );

  const name = settings?.platformName ?? "Steamy";
  const isDev = pathname.startsWith("/dev");

  return (
    <CatalogContext.Provider value={value}>
      <div className="flex min-h-screen flex-col">
        {!isDev ? <Navbar name={name} logo={settings?.logoUrl} access={value.access} user={value.user} onSearch={() => setSearchOpen(true)} /> : null}
        <main className={cx("flex-1", !isDev && "pb-10")}>{children}</main>
        {!isDev ? (
          <Footer
            settings={settings}
            name={name}
            videos={value.videos.length}
            onEagle={() => router.push("/dev")}
          />
        ) : null}
        {searchOpen ? <SearchOverlay onClose={() => setSearchOpen(false)} /> : null}
        {flash ? (
          <div className="anim-scale-in fixed bottom-6 left-1/2 z-[95] -translate-x-1/2 rounded-2xl border border-emerald-400/30 bg-emerald-500/20 px-6 py-3.5 text-sm font-bold text-emerald-50 shadow-2xl backdrop-blur-xl">
            {flash}
          </div>
        ) : null}
      </div>
    </CatalogContext.Provider>
  );
}

/* ---------------------------- access countdown ---------------------------- */

function useCountdown(expiresAt: string | null) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 15_000);
    return () => clearInterval(id);
  }, []);
  if (!expiresAt) return null;
  const ms = new Date(expiresAt).getTime() - now;
  if (ms <= 0) return null;
  const totalMinutes = Math.floor(ms / 60_000);
  const days = Math.floor(totalMinutes / 1440);
  const hours = Math.floor((totalMinutes % 1440) / 60);
  const minutes = totalMinutes % 60;
  const parts: string[] = [];
  if (days) parts.push(`${days}d`);
  if (hours) parts.push(`${hours}h`);
  parts.push(`${minutes}m`);
  return {
    label: parts.join(" "),
    pct: Math.max(4, Math.min(100, (ms / (30 * 24 * 3_600_000)) * 100)),
  };
}

export function AccessTimer({ access, inline = false }: { access: AccessInfo | null; inline?: boolean }) {
  const premium = access?.level === "day" || access?.level === "month";
  const left = useCountdown(access?.expiresAt ?? null);
  if (!premium) return null;
  const isDay = access?.level === "day";
  return (
    <div
      className={cx(
        "flex-col leading-tight",
        inline ? "flex items-center gap-2" : "hidden items-end sm:flex",
      )}
      title={access?.expiresAt ? `Valid until ${new Date(access.expiresAt).toLocaleString()}` : ""}
    >
      <span className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-white/45">
        <span className={cx("h-1.5 w-1.5 rounded-full", isDay ? "bg-amber-400" : "bg-emerald-400")} />
        {isDay ? "Day pass" : "Premium"}
      </span>
      <span className="font-mono text-[15px] font-black tabular-nums text-white">
        {left?.label ?? "expiring"}
      </span>
      <span className={cx("mt-0.5 h-[3px] overflow-hidden rounded-full bg-white/10", inline ? "w-24" : "w-16")}>
        <span
          className={cx("block h-full rounded-full transition-all duration-700", isDay ? "bg-amber-400" : "bg-emerald-400")}
          style={{ width: `${isDay ? 100 : (left?.pct ?? 100)}%` }}
        />
      </span>
    </div>
  );
}

/* --------------------------------- navbar --------------------------------- */

function Navbar({
  name,
  logo,
  access,
  user,
  onSearch,
}: {
  name: string;
  logo?: string;
  access: AccessInfo | null;
  user: SessionUser | null;
  onSearch: () => void;
}) {
  const [accountOpen, setAccountOpen] = useState(false);
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [menu, setMenu] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const premium = access?.level === "day" || access?.level === "month";
  const links = [
    { href: "/", label: "Home" },
    { href: "/access", label: "Unlock" },
    { href: "/subscribe", label: "Pricing" },
    { href: "/apps", label: "Apps" },
  ];

  return (
    <header
      className={cx(
        "sticky top-0 z-50 transition-all duration-500",
        scrolled ? "glass shadow-[0_10px_40px_-20px_rgba(0,0,0,0.9)]" : "bg-gradient-to-b from-black/70 to-transparent",
      )}
    >
      <div className="mx-auto flex h-16 max-w-[1500px] items-center gap-3 px-4 sm:px-6">
        <Link href="/" className="group flex shrink-0 items-center gap-2.5">
          {logo ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={logo} alt={name} className="h-9 w-9 rounded-xl object-cover ring-1 ring-white/15" />
          ) : (
            <span className="relative grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-[var(--accent)] to-violet-600 text-base font-black text-white shadow-lg transition group-hover:scale-105">
              S
            </span>
          )}
          <span className="text-[19px] font-black tracking-tight text-white">{name}</span>
        </Link>

        <nav className="ml-3 hidden items-center gap-1 md:flex">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className={cx(
                "rounded-full px-3.5 py-1.5 text-[13px] font-semibold transition",
                pathname === l.href ? "bg-white/10 text-white" : "text-white/55 hover:bg-white/5 hover:text-white",
              )}
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-2">
          <button
            onClick={onSearch}
            className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-[13px] text-white/50 transition hover:border-white/25 hover:text-white/80"
          >
            <span>🔍</span>
            <span className="hidden sm:inline">Search dramas</span>
            <kbd className="hidden rounded bg-white/10 px-1.5 py-0.5 text-[10px] text-white/40 lg:inline">⌘K</kbd>
          </button>

          {premium ? <AccessTimer access={access} /> : null}
          {premium ? (
            <Badge tone="brand">{access?.level === "month" ? "Premium · 30d" : "Day Pass"}</Badge>
          ) : (
            <Link href="/subscribe" className="btn-brand rounded-full px-4 py-1.5 text-[13px] font-bold text-white">
              Go Premium
            </Link>
          )}

          {user ? (
            <div className="relative">
              <button onClick={() => setAccountOpen((v) => !v)} className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 py-1 pl-1 pr-3 transition hover:border-white/25">
                {user.picture ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={user.picture} alt="" className="h-7 w-7 rounded-full object-cover" />
                ) : (
                  <span className="grid h-7 w-7 place-items-center rounded-full bg-gradient-to-br from-[var(--accent)] to-violet-600 text-[11px] font-bold">
                    {user.name.slice(0, 1).toUpperCase()}
                  </span>
                )}
                <span className="hidden max-w-[90px] truncate text-[12px] font-semibold text-white/80 sm:inline">{user.name.split(" ")[0]}</span>
              </button>
              {accountOpen ? (
                <div className="anim-scale-in glass absolute right-0 top-11 z-50 w-60 rounded-2xl p-3">
                  <p className="truncate text-[13px] font-bold text-white">{user.name}</p>
                  <p className="truncate text-[11px] text-white/40">{user.email}</p>
                  <p className="mt-2 text-[11px] text-white/50">{access?.label}</p>
                  <Link href="/subscribe" onClick={() => setAccountOpen(false)} className="btn-ghost mt-3 block rounded-full px-3 py-2 text-center text-[12px] font-bold">
                    Manage subscription
                  </Link>
                  <button
                    onClick={async () => {
                      await logOut();
                      setAccountOpen(false);
                    }}
                    className="mt-2 block w-full rounded-full bg-red-500/15 px-3 py-2 text-[12px] font-bold text-red-200"
                  >
                    Sign out
                  </button>
                </div>
              ) : null}
            </div>
          ) : (
            <Link href="/subscribe" className="btn-ghost flex items-center gap-2 rounded-full px-3 py-1.5 text-[13px] font-semibold text-white/75">
              <GoogleMark size={15} />
              <span className="hidden sm:inline">Sign in</span>
            </Link>
          )}

          <button onClick={() => setMenu((v) => !v)} className="btn-ghost grid h-9 w-9 place-items-center rounded-full md:hidden" aria-label="Menu">
            ☰
          </button>
        </div>
      </div>

      {menu ? (
        <div className="anim-fade-in glass border-t border-white/5 px-4 pb-4 pt-2 md:hidden">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              onClick={() => setMenu(false)}
              className="block rounded-xl px-3 py-2.5 text-sm font-semibold text-white/70 hover:bg-white/5 hover:text-white"
            >
              {l.label}
            </Link>
          ))}
        </div>
      ) : null}
    </header>
  );
}

/* --------------------------------- search --------------------------------- */

function SearchOverlay({ onClose }: { onClose: () => void }) {
  const [q, setQ] = useState("");
  const [items, setItems] = useState<SearchItem[]>([]);
  const [busy, setBusy] = useState(false);
  const [opening, setOpening] = useState<string | null>(null);
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  useEffect(() => {
    if (q.trim().length < 2) {
      setItems([]);
      return;
    }
    setBusy(true);
    const t = setTimeout(async () => {
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(q.trim())}`);
        const json = (await res.json()) as { results: SearchItem[] };
        setItems(json.results ?? []);
      } finally {
        setBusy(false);
      }
    }, 380);
    return () => clearTimeout(t);
  }, [q]);

  const open = async (item: SearchItem) => {
    setOpening(item.dmId);
    try {
      if (item.id) {
        router.push(`/watch/${item.id}`);
        return;
      }
      const res = await fetch("/api/watch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          input: item.dmId,
          item: {
            dmId: item.dmId,
            title: item.title,
            thumbnail: item.thumbnail,
            duration: item.duration,
            owner: item.owner,
            views: item.views,
            category: item.category,
          },
        }),
      });
      const json = (await res.json()) as { ok: boolean; id?: number };
      if (json.ok && json.id) router.push(`/watch/${json.id}`);
    } finally {
      setOpening(null);
    }
  };

  return (
    <div className="fixed inset-0 z-[80] flex items-start justify-center bg-black/80 px-4 pt-[8vh] backdrop-blur-sm" onClick={onClose}>
      <div className="anim-scale-in w-full max-w-4xl overflow-hidden rounded-3xl border border-white/10 bg-[#0b0b13] shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-3 border-b border-white/5 px-5 py-4">
          <span className="text-lg">🔍</span>
          <input
            ref={inputRef}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search any drama, movie or series — we pull results live from Dailymotion"
            className="w-full bg-transparent text-[15px] text-white placeholder-white/25 focus:outline-none"
          />
          {busy ? <Spinner size={16} /> : null}
          <button onClick={onClose} className="btn-ghost rounded-full px-3 py-1 text-xs text-white/60">
            ESC
          </button>
        </div>

        <div className="max-h-[62vh] overflow-y-auto p-5">
          {q.trim().length < 2 ? (
            <div className="space-y-3 text-center">
              <p className="text-sm text-white/40">Search the entire Dailymotion drama library — every result is instantly watchable.</p>
              <div className="flex flex-wrap justify-center gap-2">
                {["CEO billionaire", "ReelShort", "Korean short drama", "Turkish dizi", "Revenge", "DramaBox"].map((s) => (
                  <button key={s} onClick={() => setQ(s)} className="btn-ghost rounded-full px-3 py-1.5 text-xs text-white/70">
                    {s}
                  </button>
                ))}
              </div>
            </div>
          ) : items.length === 0 && !busy ? (
            <p className="py-8 text-center text-sm text-white/40">No results yet. Try another title.</p>
          ) : (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
              {items.map((item, i) => (
                <button key={item.dmId} onClick={() => open(item)} className="text-left">
                  <div className="card card-hover relative overflow-hidden rounded-2xl">
                    <div className="relative aspect-[2/3] bg-[#14141e]">
                      {item.thumbnail ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={item.thumbnail} alt={item.title} loading="lazy" className="h-full w-full object-cover" />
                      ) : null}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/90 to-transparent" />
                      {opening === item.dmId ? (
                        <div className="absolute inset-0 grid place-items-center bg-black/60">
                          <Spinner size={20} />
                        </div>
                      ) : null}
                      {!item.inCatalog ? (
                        <span className="absolute right-1.5 top-1.5 rounded-full bg-[var(--accent)] px-2 py-0.5 text-[9px] font-bold uppercase text-white">
                          Live
                        </span>
                      ) : null}
                    </div>
                    <div className="p-2.5">
                      <p className="line-clamp-2 text-[12px] font-semibold leading-snug text-white/90">{item.title}</p>
                      <p className="mt-1 text-[10px] text-white/40">{item.category}</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* --------------------------------- footer --------------------------------- */

function Footer({
  settings,
  name,
  videos,
  onEagle,
}: {
  settings: PublicSettings | null;
  name: string;
  videos: number;
  onEagle: () => void;
}) {
  const langs = (settings?.dubLanguages ?? []).slice(0, 10);
  return (
    <footer className="relative mt-16 border-t border-white/5 bg-black/40">
      <div className="mx-auto max-w-[1500px] px-4 py-12 sm:px-6">
        <div className="grid gap-10 md:grid-cols-4">
          <div className="space-y-3">
            <div className="flex items-center gap-2.5">
              {settings?.logoUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={settings.logoUrl} alt={name} className="h-8 w-8 rounded-lg object-cover" />
              ) : (
                <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-[var(--accent)] to-violet-600 text-sm font-black">S</span>
              )}
              <span className="font-black tracking-tight">{name}</span>
            </div>
            <p className="text-xs leading-relaxed text-white/40">{settings?.tagline ?? "Micro dramas, dubbed in your language."}</p>
            <p className="text-[11px] text-white/30">{videos}+ titles · auto-refreshed hourly</p>
          </div>

          <div className="space-y-2.5">
            <h4 className="text-[11px] font-bold uppercase tracking-widest text-white/35">Browse</h4>
            {(settings?.categories ?? []).slice(0, 6).map((c) => (
              <Link key={c} href={`/?c=${encodeURIComponent(c)}`} className="block text-[13px] text-white/55 transition hover:text-white">
                {c}
              </Link>
            ))}
          </div>

          <div className="space-y-2.5">
            <h4 className="text-[11px] font-bold uppercase tracking-widest text-white/35">Dubbing studio</h4>
            <div className="flex flex-wrap gap-1.5">
              {langs.map((code) => (
                <span key={code} className="rounded-full bg-white/5 px-2 py-0.5 text-[11px] text-white/55">
                  {DUB_LANGUAGES.find((l) => l.code === code)?.nativeLabel ?? code}
                </span>
              ))}
            </div>
            <p className="text-[11px] text-white/30">Word-by-word captions included.</p>
          </div>

          <div className="space-y-2.5">
            <h4 className="text-[11px] font-bold uppercase tracking-widest text-white/35">Get the app</h4>
            {(settings?.appLinks ?? []).map((l) => (
              <a key={l.label} href={l.url} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-[13px] text-white/55 transition hover:text-white">
                <span>{l.icon}</span>
                {l.label}
              </a>
            ))}
          </div>
        </div>

        <div className="mt-10 flex flex-col items-center gap-3 border-t border-white/5 pt-6 sm:flex-row sm:justify-between">
          <p className="text-[11px] text-white/30">
            © {new Date().getFullYear()} {name}. All dramas are streamed from Dailymotion via their public API.
          </p>
          <p className="text-[11px] text-white/30">Made for drama lovers worldwide 🌍</p>
        </div>

        <div className="mt-6 flex items-end justify-end">
          <button
            onClick={onEagle}
            title="."
            aria-label="."
            className="select-none text-[11px] leading-none opacity-[0.13] transition hover:opacity-60"
          >
            🦅
          </button>
        </div>
      </div>
    </footer>
  );
}
