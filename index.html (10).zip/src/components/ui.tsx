"use client";

import Link from "next/link";
import { useEffect, useRef, useState, type ReactNode } from "react";

export const cx = (...c: (string | false | null | undefined)[]) => c.filter(Boolean).join(" ");

export function formatDuration(s: number) {
  const sec = Math.max(0, Math.floor(s || 0));
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const r = sec % 60;
  return h ? `${h}:${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}` : `${m}:${String(r).padStart(2, "0")}`;
}

export function formatViews(n: number) {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return String(n ?? 0);
}

export function Badge({ children, tone = "default" }: { children: ReactNode; tone?: "default" | "brand" | "gold" | "live" }) {
  const tones = {
    default: "bg-white/8 text-white/70 border-white/10",
    brand: "bg-[color-mix(in_srgb,var(--accent)_22%,transparent)] text-white border-[color-mix(in_srgb,var(--accent)_55%,transparent)]",
    gold: "bg-amber-400/15 text-amber-200 border-amber-300/30",
    live: "bg-red-500/20 text-red-200 border-red-400/40",
  };
  return (
    <span className={cx("inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider", tones[tone])}>
      {children}
    </span>
  );
}

export function Spinner({ size = 18 }: { size?: number }) {
  return (
    <span
      className="inline-block animate-spin rounded-full border-2 border-white/20 border-t-white"
      style={{ width: size, height: size }}
    />
  );
}

export function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <label className="block space-y-1.5">
      <span className="text-[11px] font-semibold uppercase tracking-wider text-white/45">{label}</span>
      {children}
      {hint ? <span className="block text-[11px] text-white/35">{hint}</span> : null}
    </label>
  );
}

export const inputCls =
  "w-full rounded-xl border border-white/10 bg-black/40 px-3.5 py-2.5 text-sm text-white placeholder-white/25 transition";

export function Toast({ message, tone = "ok", onDone }: { message: string; tone?: "ok" | "err"; onDone: () => void }) {
  useEffect(() => {
    const t = setTimeout(onDone, 4200);
    return () => clearTimeout(t);
  }, [onDone]);
  return (
    <div
      className={cx(
        "anim-scale-in fixed bottom-6 left-1/2 z-[90] -translate-x-1/2 rounded-2xl border px-5 py-3 text-sm font-medium shadow-2xl backdrop-blur-xl",
        tone === "ok" ? "border-emerald-400/30 bg-emerald-500/15 text-emerald-100" : "border-red-400/30 bg-red-500/15 text-red-100",
      )}
    >
      {message}
    </div>
  );
}

/* --------------------------------- cards ---------------------------------- */

export type PosterItem = {
  id: number;
  dmId: string;
  title: string;
  thumbnail: string;
  duration?: number;
  category?: string;
  views?: number;
  owner?: string;
};

export function PosterCard({ item, href, index = 0 }: { item: PosterItem; href: string; index?: number }) {
  return (
    <Link
      href={href}
      className="card card-hover group anim-fade-up relative block overflow-hidden rounded-2xl"
      style={{ animationDelay: `${Math.min(index, 12) * 45}ms` }}
    >
      <div className="relative aspect-[2/3] w-full overflow-hidden bg-[#14141e]">
        {item.thumbnail ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={item.thumbnail}
            alt={item.title}
            loading="lazy"
            className="h-full w-full object-cover transition duration-700 group-hover:scale-[1.07]"
          />
        ) : (
          <div className="flex h-full items-center justify-center text-3xl opacity-30">🎬</div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/15 to-transparent opacity-80 transition group-hover:opacity-95" />
        {item.duration ? (
          <span className="absolute bottom-2 right-2 rounded-md bg-black/70 px-1.5 py-0.5 text-[10px] font-semibold tabular-nums text-white/90">
            {formatDuration(item.duration)}
          </span>
        ) : null}
        <span className="absolute left-2 top-2 flex h-9 w-9 translate-y-2 items-center justify-center rounded-full bg-[var(--accent)] text-white opacity-0 shadow-lg transition duration-300 group-hover:translate-y-0 group-hover:opacity-100">
          ▶
        </span>
        {item.category ? (
          <span className="absolute bottom-2 left-2 max-w-[75%] truncate rounded-md bg-[var(--accent)]/85 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-white">
            {item.category}
          </span>
        ) : null}
      </div>
      <div className="space-y-1 p-3">
        <h3 className="line-clamp-2 text-[13px] font-semibold leading-snug text-white/90 transition group-hover:text-white">{item.title}</h3>
        <p className="flex items-center gap-2 text-[11px] text-white/40">
          {item.owner ? <span className="truncate">{item.owner}</span> : null}
          {item.views ? <span>· {formatViews(item.views)} views</span> : null}
        </p>
      </div>
    </Link>
  );
}

export function Rail({
  title,
  subtitle,
  children,
  action,
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
  action?: ReactNode;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const scroll = (dir: number) => {
    ref.current?.scrollBy({ left: dir * (ref.current.clientWidth * 0.8), behavior: "smooth" });
  };
  return (
    <section className="space-y-3">
      <div className="flex items-end justify-between gap-4 px-1">
        <div>
          <h2 className="text-lg font-bold tracking-tight text-white sm:text-xl">{title}</h2>
          {subtitle ? <p className="text-xs text-white/40">{subtitle}</p> : null}
        </div>
        <div className="flex items-center gap-2">
          {action}
          <div className="hidden gap-1.5 sm:flex">
            <button onClick={() => scroll(-1)} aria-label="Scroll left" className="btn-ghost h-8 w-8 rounded-full text-xs">‹</button>
            <button onClick={() => scroll(1)} aria-label="Scroll right" className="btn-ghost h-8 w-8 rounded-full text-xs">›</button>
          </div>
        </div>
      </div>
      <div ref={ref} className="no-scrollbar -mx-1 flex snap-x snap-mandatory gap-3 overflow-x-auto scroll-smooth px-1 pb-2">
        {children}
      </div>
    </section>
  );
}

export function SectionTitle({ eyebrow, title, desc }: { eyebrow?: string; title: string; desc?: string }) {
  return (
    <div className="space-y-2 text-center">
      {eyebrow ? <p className="text-[11px] font-bold uppercase tracking-[0.22em] text-[var(--accent-soft)]">{eyebrow}</p> : null}
      <h2 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">{title}</h2>
      {desc ? <p className="mx-auto max-w-2xl text-sm text-white/45">{desc}</p> : null}
    </div>
  );
}

export function useToast() {
  const [toast, setToast] = useState<{ message: string; tone: "ok" | "err" } | null>(null);
  const node = toast ? <Toast message={toast.message} tone={toast.tone} onDone={() => setToast(null)} /> : null;
  return {
    node,
    ok: (message: string) => setToast({ message, tone: "ok" }),
    err: (message: string) => setToast({ message, tone: "err" }),
  };
}
