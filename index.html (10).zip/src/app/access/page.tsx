"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { useCatalog } from "@/components/AppShell";
import { Badge, Field, SectionTitle, Spinner, cx, inputCls, useToast } from "@/components/ui";
import type { AccessInfo } from "@/lib/types";

export default function AccessPage() {
  const { settings, channels, refresh } = useCatalog();
  const [digits, setDigits] = useState(["", "", "", ""]);
  const [busy, setBusy] = useState(false);
  const [proofs, setProofs] = useState<string[]>([]);
  const [mode, setMode] = useState<"code" | "steps">("code");
  const [access, setAccess] = useState<AccessInfo | null>(null);
  const [unlocked, setUnlocked] = useState<string | null>(null);
  const refs = useRef<(HTMLInputElement | null)[]>([]);
  const router = useRouter();
  const toast = useToast();

  useEffect(() => {
    fetch("/api/access", { cache: "no-store" })
      .then((r) => r.json())
      .then((j: { access: AccessInfo }) => setAccess(j.access));
    refs.current[0]?.focus();
  }, []);

  useEffect(() => {
    if (settings?.freeAccessSteps.length) setProofs(new Array(settings.freeAccessSteps.length).fill(""));
  }, [settings?.freeAccessSteps]);

  const premium = access?.level === "day" || access?.level === "month";

  const submitCode = async () => {
    const code = digits.join("");
    if (code.length < 4) return toast.err("Enter all 4 digits.");
    setBusy(true);
    try {
      const res = await fetch("/api/access", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode: "code", code }),
      });
      const json = (await res.json()) as { ok: boolean; access?: AccessInfo; error?: string; message?: string };
      if (!json.ok || !json.access) {
        toast.err(json.error ?? "That code is not valid today.");
      } else {
        setAccess(json.access);
        setUnlocked(json.message ?? "Full access unlocked!");
        window.dispatchEvent(new CustomEvent("steam:unlocked", { detail: json.access.level }));
        await refresh();
        setTimeout(() => router.push("/"), 1600);
      }
    } finally {
      setBusy(false);
    }
  };

  const submitSteps = async () => {
    setBusy(true);
    try {
      const res = await fetch("/api/access", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode: "steps", steps: proofs.map((p) => ({ proof: p })) }),
      });
      const json = (await res.json()) as { ok: boolean; access?: AccessInfo; error?: string; message?: string };
      if (!json.ok || !json.access) {
        toast.err(json.error ?? "Could not verify the steps.");
      } else {
        setAccess(json.access);
        setUnlocked(json.message ?? "Free access unlocked!");
        window.dispatchEvent(new CustomEvent("steam:unlocked", { detail: json.access.level }));
        await refresh();
        setTimeout(() => router.push("/"), 1600);
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-[900px] space-y-8 px-4 py-12 sm:px-6">
      {toast.node}
      <SectionTitle
        eyebrow="Unlock"
        title="Get full access to the platform"
        desc="Enter today's 4-digit code for a full day of premium streaming, or complete the 3 free steps below."
      />

      {premium ? (
        <div className="rounded-3xl border border-emerald-400/25 bg-emerald-500/10 p-6 text-center">
          <p className="text-lg font-black text-emerald-100">✓ {access?.label} active</p>
          {access?.expiresAt ? <p className="mt-1 text-[13px] text-emerald-200/70">Valid until {new Date(access.expiresAt).toLocaleString()}</p> : null}
        </div>
      ) : null}

      {unlocked && premium ? (
        <div className="anim-scale-in fixed inset-0 z-[95] flex flex-col items-center justify-center gap-4 bg-black/90 px-6 text-center backdrop-blur-md">
          <span className="grid h-20 w-20 place-items-center rounded-full bg-emerald-500/20 text-4xl">✓</span>
          <h2 className="text-3xl font-black tracking-tight text-white">Full access is active</h2>
          <p className="max-w-md text-sm text-white/60">{unlocked}</p>
          <ul className="grid gap-1.5 text-left text-[13px] text-white/70">
            <li>✓ Every episode and movie, no preview limit</li>
            <li>✓ All {settings?.dubLanguages.length ?? 14} dubbing languages</li>
            <li>✓ Word-by-word captions and dual subtitles</li>
            <li>✓ Zoom, fill-screen and ad-free playback</li>
          </ul>
          <p className="text-[12px] text-white/40">
            {access?.expiresAt ? `Valid until ${new Date(access.expiresAt).toLocaleString()}` : ""}
          </p>
          <Link href="/" className="btn-brand rounded-full px-7 py-3 text-sm font-bold">
            Start watching →
          </Link>
        </div>
      ) : null}

      <div className="flex justify-center gap-2">
        {(["code", "steps"] as const).map((m) => (
          <button
            key={m}
            onClick={() => setMode(m)}
            className={cx(
              "rounded-full px-5 py-2 text-[13px] font-bold transition",
              mode === m ? "bg-[var(--accent)] text-white" : "bg-white/5 text-white/50 hover:text-white",
            )}
          >
            {m === "code" ? "🎟️ Day code" : "🎁 Free in 3 steps"}
          </button>
        ))}
      </div>

      {mode === "code" ? (
        <div className="card anim-fade-up space-y-5 rounded-3xl p-6 sm:p-8">
          <div className="text-center">
            <h3 className="text-xl font-black text-white">Enter today&apos;s 4-digit code</h3>
            <p className="mt-1 text-[13px] text-white/45">
              {settings?.dailyCodeActive === false ? "The daily code is paused right now." : "The code changes every day — grab it from our channel or support."}
            </p>
          </div>
          <div className="flex justify-center gap-3" dir="ltr">
            {digits.map((d, i) => (
              <input
                key={i}
                ref={(el) => {
                  refs.current[i] = el;
                }}
                value={d}
                inputMode="numeric"
                maxLength={1}
                onChange={(e) => {
                  const v = e.target.value.replace(/\D/g, "").slice(-1);
                  const next = [...digits];
                  next[i] = v;
                  setDigits(next);
                  if (v && i < 3) refs.current[i + 1]?.focus();
                }}
                onKeyDown={(e) => {
                  if (e.key === "Backspace" && !digits[i] && i > 0) refs.current[i - 1]?.focus();
                  if (e.key === "Enter") submitCode();
                }}
                className="h-16 w-14 rounded-2xl border border-white/12 bg-black/50 text-center text-2xl font-black text-white transition focus:border-[var(--accent)]"
              />
            ))}
          </div>
          <button onClick={submitCode} disabled={busy} className="btn-brand flex w-full items-center justify-center gap-2 rounded-full py-3.5 text-sm font-bold disabled:opacity-60">
            {busy ? <Spinner size={16} /> : null} Unlock for today
          </button>
          <p className="text-center text-[11px] text-white/30">Day access includes every episode, all dubbing languages and word-by-word captions.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {(settings?.freeAccessSteps ?? []).map((step, i) => {
            const channel = channels[i];
            return (
              <div key={i} className="card anim-fade-up space-y-3 rounded-3xl p-6">
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <Badge tone="brand">Step {i + 1}</Badge>
                    <h3 className="text-base font-bold text-white">{channel?.title ?? step.title}</h3>
                    <p className="text-[13px] leading-relaxed text-white/50">{step.body}</p>
                  </div>
                  {channel?.url ? (
                    <a href={channel.url} target="_blank" rel="noreferrer" className="btn-brand shrink-0 rounded-full px-4 py-2 text-[12px] font-bold">
                      {step.ctaLabel || "Open"} ↗
                    </a>
                  ) : null}
                </div>
                <Field label={step.proofLabel || "Your proof"}>
                  <input
                    value={proofs[i] ?? ""}
                    onChange={(e) => {
                      const next = [...proofs];
                      next[i] = e.target.value;
                      setProofs(next);
                    }}
                    placeholder="Type your answer here…"
                    className={inputCls}
                  />
                </Field>
              </div>
            );
          })}
          <button onClick={submitSteps} disabled={busy} className="btn-brand flex w-full items-center justify-center gap-2 rounded-full py-3.5 text-sm font-bold disabled:opacity-60">
            {busy ? <Spinner size={16} /> : null} Verify &amp; unlock free access
          </button>
        </div>
      )}

      <div className="text-center">
        <p className="text-[13px] text-white/40">
          Want the full month instead?{" "}
          <Link href="/subscribe" className="font-bold text-[var(--accent-soft)]">
            See pricing →
          </Link>
        </p>
      </div>
    </div>
  );
}
