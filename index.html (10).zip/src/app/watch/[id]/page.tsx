"use client";

import Link from "next/link";
import { use, useEffect, useState } from "react";
import { DubPlayer } from "@/components/DubPlayer";
import { Comments, AccessStrip } from "@/components/Comments";
import { useCatalog } from "@/components/AppShell";
import { Badge, PosterCard, Spinner, cx, formatDuration, formatViews } from "@/components/ui";
import { AccessTimer } from "@/components/AppShell";
import type { AccessInfo, ApiVideo, DubCueDto, PublicSettings } from "@/lib/types";

type WatchResponse = {
  video: ApiVideo;
  related: ApiVideo[];
  comments: { id: number; author: string; body: string; createdAt: string; likes: number }[];
  access: AccessInfo;
  settings: PublicSettings;
};

export default function WatchPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { access: liveAccess } = useCatalog();
  const accessLevel = liveAccess?.level ?? "none";
  const [data, setData] = useState<WatchResponse | null>(null);
  const [error, setError] = useState("");
  const [tab, setTab] = useState<"about" | "episodes">("about");

  // Re-read the video + access whenever the viewer's plan changes (day code,
  // approved payment) so nothing on this page stays stale.
  useEffect(() => {
    fetch(`/api/videos/${id}`, { cache: "no-store" })
      .then(async (r) => {
        if (!r.ok) throw new Error("This drama is no longer available.");
        return r.json();
      })
      .then((json: WatchResponse) => setData(json))
      .catch(() => undefined);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, accessLevel]);

  useEffect(() => {
    setData(null);
    fetch(`/api/videos/${id}`, { cache: "no-store" })
      .then(async (r) => {
        if (!r.ok) throw new Error("This drama is no longer available.");
        return r.json();
      })
      .then((json: WatchResponse) => setData(json))
      .catch((e: Error) => setError(e.message));
  }, [id]);

  if (error) {
    return (
      <div className="mx-auto max-w-3xl px-6 py-24 text-center">
        <h1 className="text-2xl font-bold text-white">{error}</h1>
        <Link href="/" className="btn-brand mt-6 inline-flex rounded-full px-6 py-3 text-sm font-bold">
          Back to home
        </Link>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="mx-auto max-w-[1500px] space-y-4 px-4 py-10 sm:px-6">
        <div className="skeleton aspect-video w-full rounded-3xl" />
        <div className="skeleton h-6 w-2/3 rounded-full" />
        <div className="skeleton h-4 w-1/3 rounded-full" />
      </div>
    );
  }

  const { video, related, comments, settings } = data;
  // Prefer the live polled access so an approved payment unlocks instantly.
  const access = liveAccess?.deviceId && liveAccess.deviceId !== "anonymous" ? liveAccess : data.access;
  const premium = access.level === "day" || access.level === "month";

  return (
    <div className="mx-auto max-w-[1500px] space-y-6 px-4 py-6 sm:px-6">
      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_330px]">
        <div className="space-y-5">
          <DubPlayer video={video} access={access} settings={settings} />

          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone="brand">{video.category}</Badge>
              <Badge>{formatDuration(video.duration)}</Badge>
              <Badge>{formatViews(video.views)} views</Badge>
              {premium ? <Badge tone="gold">Premium · all languages</Badge> : <Badge tone="live">Free preview</Badge>}
            </div>
            <h1 className="text-2xl font-black leading-tight tracking-tight text-white sm:text-3xl">{video.title}</h1>
            <p className="text-[13px] text-white/40">
              {video.owner} · streamed via the Dailymotion API · added {new Date(video.createdAt).toLocaleDateString()}
            </p>
            <AccessStrip access={access} />
            {premium ? (
              <div className="flex flex-wrap items-center gap-3 rounded-2xl border border-emerald-400/25 bg-emerald-500/10 px-4 py-3">
                <AccessTimer access={access} inline />
                <span className="text-[12.5px] font-semibold text-emerald-100">
                  All features unlocked · every episode, all {settings.dubLanguages.length} dubbing languages and word-by-word captions
                </span>
              </div>
            ) : null}
          </div>

          <div className="flex gap-2">
            {(["about", "episodes"] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={cx(
                  "rounded-full px-4 py-1.5 text-[12px] font-bold uppercase tracking-wider transition",
                  tab === t ? "bg-[var(--accent)] text-white" : "bg-white/5 text-white/50 hover:text-white",
                )}
              >
                {t === "about" ? "About" : `More like this (${related.length})`}
              </button>
            ))}
          </div>

          {tab === "about" ? (
            <div className="card space-y-4 rounded-3xl p-5">
              <div>
                <h3 className="mb-1.5 text-sm font-bold uppercase tracking-wider text-white/45">Story</h3>
                <p className="whitespace-pre-line text-[14px] leading-relaxed text-white/65">
                  {video.description || "A brand new micro drama — now streaming with AI dubbing and word-by-word captions."}
                </p>
              </div>
              {video.tags?.length ? (
                <div>
                  <h3 className="mb-2 text-sm font-bold uppercase tracking-wider text-white/45">Tags</h3>
                  <div className="flex flex-wrap gap-1.5">
                    {video.tags.slice(0, 14).map((t) => (
                      <span key={t} className="rounded-full bg-white/5 px-2.5 py-1 text-[11px] text-white/50">
                        #{t}
                      </span>
                    ))}
                  </div>
                </div>
              ) : null}
              <div className="rounded-2xl border border-[var(--accent)]/25 bg-[var(--accent)]/8 p-4">
                <h4 className="text-sm font-bold text-white">🎙️ Dubbing &amp; captions</h4>
                <p className="mt-1 text-[13px] leading-relaxed text-white/55">
                  Open <strong>Dub Studio</strong> under the player to switch the audio into any of {settings.dubLanguages.length} languages, choose a neural voice,
                  pick a dub preset and enable dual captions. Captions highlight every word as it is spoken.
                </p>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {related.map((v, i) => (
                <PosterCard key={v.id} item={v} href={`/watch/${v.id}`} index={i} />
              ))}
            </div>
          )}

          <Comments videoId={video.id} initial={comments} />
        </div>

        {/* ------------------------------- sidebar ------------------------------ */}
        <aside className="space-y-4">
          {!premium ? (
            <div className="card space-y-3 rounded-3xl p-5">
              <Badge tone="brand">Unlock everything</Badge>
              <h3 className="text-lg font-black leading-tight text-white">Watch it all — dubbed in your language</h3>
              <ul className="space-y-1.5 text-[13px] text-white/55">
                <li>✓ Unlimited episodes &amp; movies</li>
                <li>✓ All {settings.dubLanguages.length} dubbing languages</li>
                <li>✓ Word-by-word captions</li>
                <li>✓ Zero ads, priority servers</li>
              </ul>
              <div className="flex flex-col gap-2 pt-1">
                <Link href="/subscribe" className="btn-brand rounded-full px-5 py-2.5 text-center text-sm font-bold">
                  Premium · {settings.monthlyCurrency} {settings.monthlyPrice}/mo
                </Link>
                {settings.dailyCodeActive ? (
                  <Link href="/access" className="btn-ghost rounded-full px-5 py-2.5 text-center text-sm font-bold">
                    I have a day code
                  </Link>
                ) : null}
              </div>
            </div>
          ) : null}

          <div className="card space-y-3 rounded-3xl p-5">
            <h3 className="text-sm font-bold uppercase tracking-wider text-white/45">Up next</h3>
            <div className="space-y-3">
              {related.slice(0, 8).map((v) => (
                <Link key={v.id} href={`/watch/${v.id}`} className="group flex gap-3">
                  <div className="relative h-[68px] w-[52px] shrink-0 overflow-hidden rounded-lg bg-white/5">
                    {v.thumbnail ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={v.thumbnail} alt="" loading="lazy" className="h-full w-full object-cover transition group-hover:scale-110" />
                    ) : null}
                  </div>
                  <div className="min-w-0">
                    <p className="line-clamp-2 text-[12.5px] font-semibold leading-snug text-white/85 group-hover:text-white">{v.title}</p>
                    <p className="mt-0.5 text-[11px] text-white/35">
                      {v.category} · {formatDuration(v.duration)}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
