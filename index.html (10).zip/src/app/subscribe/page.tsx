"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import type { AccessInfo } from "@/lib/types";
import type { CountryDef, MethodDef } from "@/lib/countries";
import { Badge, Field, SectionTitle, Spinner, cx, inputCls, useToast } from "@/components/ui";
import { GoogleSignIn, type SessionUserDto } from "@/components/GoogleSignIn";

type MethodRow = {
  id: number;
  countryCode: string;
  methodKey: string;
  label: string;
  icon: string;
  address: string;
  accountName: string;
  details?: { label: string; value: string }[];
  instructions: string;
  amount: string;
  currency: string;
};

type SubData = {
  access: AccessInfo;
  countries: CountryDef[];
  methodCatalog: MethodDef[];
  defaultPrice: number;
  defaultCurrency: string;
  methodsByCountry: Record<string, MethodRow[]>;
  user?: SessionUserDto | null;
};

async function compressImage(file: File): Promise<string> {
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(String(fr.result));
    fr.onerror = () => reject(new Error("Could not read the file"));
    fr.readAsDataURL(file);
  });
  return new Promise<string>((resolve) => {
    const img = new Image();
    img.onload = () => {
      const max = 1400;
      const scale = Math.min(1, max / Math.max(img.width, img.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);
      const ctx = canvas.getContext("2d");
      if (!ctx) return resolve(dataUrl);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      resolve(canvas.toDataURL("image/jpeg", 0.72));
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}

export default function SubscribePage() {
  const [data, setData] = useState<SubData | null>(null);
  const [countryCode, setCountryCode] = useState("");
  const [query, setQuery] = useState("");
  const [methodKey, setMethodKey] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [txn, setTxn] = useState("");
  const [proof, setProof] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<string>("");
  const [user, setUser] = useState<SessionUserDto | null>(null);
  const toast = useToast();

  const load = () =>
    fetch("/api/subscribe", { cache: "no-store" })
      .then((r) => r.json())
      .then((json: SubData) => {
        setData(json);
        setUser((u) => json.user ?? u);
        const guess = (json.countries.find((c) => c.code === countryCode) ? countryCode : "") || "";
        if (!guess && typeof navigator !== "undefined") {
          const tz = Intl.DateTimeFormat().resolvedOptions().timeZone ?? "";
          const map: Record<string, string> = {
            Karachi: "PK", Kolkata: "IN", Dhaka: "BD", Jakarta: "ID", Kuala: "MY", Manila: "PH", Bangkok: "TH",
            Shanghai: "CN", Tokyo: "JP", Seoul: "KR", Istanbul: "TR", Dubai: "AE", Riyadh: "SA", Cairo: "EG",
            Lagos: "NG", Nairobi: "KE", London: "GB", "New_York": "US", "Los_Angeles": "US", Sao_Paulo: "BR",
            "Mexico_City": "MX", Amsterdam: "NL", Berlin: "DE", Paris: "FR", Madrid: "ES", Rome: "IT",
            Warsaw: "PL", Moscow: "RU", Sydney: "AU", Singapore: "SG", Taipei: "TW",
          };
          const hit = Object.entries(map).find(([k]) => tz.includes(k));
          setCountryCode(hit ? hit[1] : "US");
        }
      });
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /** Poll while a payment is pending so approval activates instantly. */
  useEffect(() => {
    if (!data?.access.pendingPayment) return;
    const id = setInterval(load, 12_000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data?.access.pendingPayment?.id]);

  useEffect(() => {
    const onUnlocked = () => load();
    window.addEventListener("steam:unlocked", onUnlocked);
    return () => window.removeEventListener("steam:unlocked", onUnlocked);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const country = useMemo(() => data?.countries.find((c) => c.code === countryCode), [data, countryCode]);
  const methods = useMemo(() => data?.methodsByCountry[countryCode] ?? [], [data, countryCode]);
  const method = methods.find((m) => m.methodKey === methodKey) ?? methods[0];

  useEffect(() => {
    if (methods.length && !methods.some((m) => m.methodKey === methodKey)) setMethodKey(methods[0].methodKey);
  }, [methods, methodKey]);

  const filteredCountries = useMemo(() => {
    if (!data) return [];
    const q = query.trim().toLowerCase();
    return q ? data.countries.filter((c) => c.name.toLowerCase().includes(q) || c.code.toLowerCase() === q) : data.countries;
  }, [data, query]);

  const price = method && Number(method.amount) > 0 ? Number(method.amount) : data?.defaultPrice ?? 0;
  const currency = method?.currency || country?.currency || data?.defaultCurrency || "USD";
  const symbol = country?.symbol ?? "";

  const submit = async () => {
    if (!countryCode) return toast.err("Select your country first.");
    if (!methodKey) return toast.err("Select a payment method.");
    if (name.trim().length < 2) return toast.err("Enter the name you paid with.");
    if (!proof) return toast.err("Upload the payment screenshot.");
    setBusy(true);
    try {
      const res = await fetch("/api/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          countryCode,
          methodKey,
          payerName: name,
          payerEmail: email,
          transactionId: txn,
          proofImage: proof,
        }),
      });
      const json = (await res.json()) as { ok: boolean; message?: string; error?: string; paymentId?: number };
      if (!json.ok) {
        toast.err(json.error ?? "Submission failed.");
      } else {
        setDone(`Payment #${json.paymentId} submitted for verification.`);
        setProof("");
        setTxn("");
        toast.ok(json.message ?? "Submitted!");
        load();
      }
    } finally {
      setBusy(false);
    }
  };

  const premium = data?.access.level === "day" || data?.access.level === "month";
  const pending = data?.access.pendingPayment;

  return (
    <div className="mx-auto max-w-[1100px] space-y-8 px-4 py-10 sm:px-6">
      {toast.node}
      <SectionTitle
        eyebrow="Premium"
        title="Choose your country & payment method"
        desc="We support local wallets, bank transfers and crypto in 190+ countries. Pay, upload the receipt, and your account is activated after verification."
      />

      {premium ? (
        <div className="rounded-3xl border border-emerald-400/25 bg-emerald-500/10 p-5 text-sm text-emerald-100">
          ✓ <strong>{data?.access.label}</strong> is active{data?.access.expiresAt ? ` until ${new Date(data.access.expiresAt).toLocaleString()}` : ""}.
        </div>
      ) : null}

      {pending ? (
        <div className="rounded-3xl border border-amber-400/25 bg-amber-500/10 p-5 text-sm text-amber-100">
          ⏳ Payment <strong>#{pending.id}</strong> for {pending.amount} {pending.currency} is awaiting verification. You will get access as soon as it is approved.
        </div>
      ) : null}

      {done ? (
        <div className="rounded-3xl border border-[var(--accent)]/30 bg-[var(--accent)]/10 p-5 text-sm text-white/80">
          {done} <button onClick={() => setDone("")} className="ml-2 font-bold text-[var(--accent-soft)]">Dismiss</button>
        </div>
      ) : null}

      {/* -------------------------------- step 0 ------------------------------- */}
      <div className="card space-y-4 rounded-3xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="grid h-8 w-8 place-items-center rounded-full bg-[var(--accent)] text-sm font-bold">0</span>
            <div>
              <h3 className="text-base font-bold text-white">Create your account</h3>
              <p className="text-[12px] text-white/45">
                {user ? "Your subscription is linked to this account and stays active on every device you sign in on." : "Sign in so your subscription stays active even if you change browser or device."}
              </p>
            </div>
          </div>
          {user ? <Badge tone="brand">✓ Signed in</Badge> : null}
        </div>
        {user ? (
          <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-black/30 p-3">
            {user.picture ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={user.picture} alt="" className="h-10 w-10 rounded-full object-cover" />
            ) : (
              <span className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-[var(--accent)] to-violet-600 text-sm font-bold">
                {user.name.slice(0, 1).toUpperCase()}
              </span>
            )}
            <div className="min-w-0">
              <p className="truncate text-[13px] font-bold text-white">{user.name}</p>
              <p className="truncate text-[11px] text-white/40">{user.email}</p>
            </div>
            <span className="ml-auto rounded-full bg-white/5 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-white/45">
              {user.provider === "google" ? "Google" : "Email"}
            </span>
          </div>
        ) : (
          <div className="max-w-sm">
            <GoogleSignIn onSignedIn={(u) => setUser(u)} label="Sign up with Google to buy premium" />
          </div>
        )}
      </div>

      {/* -------------------------------- step 1 ------------------------------- */}
      <div className="card space-y-4 rounded-3xl p-5">
        <div className="flex items-center gap-3">
          <span className="grid h-8 w-8 place-items-center rounded-full bg-[var(--accent)] text-sm font-bold">1</span>
          <h3 className="text-base font-bold text-white">Select your country</h3>
          {country ? <Badge tone="brand">{country.flag} {country.name}</Badge> : null}
        </div>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search country…"
          className={inputCls}
        />
        <div className="no-scrollbar grid max-h-[260px] grid-cols-2 gap-2 overflow-y-auto sm:grid-cols-3 lg:grid-cols-4">
          {filteredCountries.map((c) => (
            <button
              key={c.code}
              onClick={() => setCountryCode(c.code)}
              className={cx(
                "flex items-center gap-2 rounded-xl border px-3 py-2.5 text-left text-[12.5px] font-semibold transition",
                countryCode === c.code
                  ? "border-transparent bg-[var(--accent)] text-white"
                  : "border-white/10 bg-white/5 text-white/65 hover:border-white/25 hover:text-white",
              )}
            >
              <span className="text-base">{c.flag}</span>
              <span className="truncate">{c.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* -------------------------------- step 2 ------------------------------- */}
      {country ? (
        <div className="card anim-fade-up space-y-4 rounded-3xl p-5">
          <div className="flex items-center gap-3">
            <span className="grid h-8 w-8 place-items-center rounded-full bg-[var(--accent)] text-sm font-bold">2</span>
            <h3 className="text-base font-bold text-white">Choose how you want to pay</h3>
          </div>

          {methods.length === 0 ? (
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-[13px] text-white/55">
              No local payment rails are enabled for {country.name} yet. Meanwhile you can pay with any crypto wallet —
              contact support for the address.
            </div>
          ) : (
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {methods.map((m) => (
                <button
                  key={m.id}
                  onClick={() => setMethodKey(m.methodKey)}
                  className={cx(
                    "rounded-2xl border p-3.5 text-left transition",
                    methodKey === m.methodKey
                      ? "border-[var(--accent)] bg-[var(--accent)]/12"
                      : "border-white/10 bg-white/5 hover:border-white/25",
                  )}
                >
                  <p className="flex items-center gap-2 text-[13px] font-bold text-white">
                    <span className="text-base">{m.icon}</span> {m.label}
                  </p>
                  <p className="mt-1 text-[11px] text-white/45">
                    {Number(m.amount) > 0 ? `${m.currency} ${m.amount}` : `${m.currency} — local price`} / month
                  </p>
                </button>
              ))}
            </div>
          )}

          {method ? (
            <div className="space-y-3 rounded-2xl border border-white/10 bg-black/40 p-4">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <h4 className="text-sm font-bold text-white">{method.icon} {method.label}</h4>
                <p className="text-lg font-black text-white">
                  {symbol} {price} <span className="text-xs font-semibold text-white/40">/ month · {method.currency}</span>
                </p>
              </div>

              {(method.details ?? []).filter((d) => d.value).length ? (
                <div className="space-y-2">
                  <p className="text-[11px] font-bold uppercase tracking-widest text-white/40">Where to pay</p>
                  <div className="space-y-1.5">
                    {(method.details ?? [])
                      .filter((d) => d.value)
                      .map((d, i) => (
                        <div key={`${d.label}-${i}`} className="flex items-center gap-3 rounded-xl bg-black/60 px-3 py-2.5">
                          <div className="min-w-0 flex-1">
                            <p className="text-[10.5px] font-bold uppercase tracking-wider text-white/35">{d.label}</p>
                            <p className="break-all font-mono text-[13px] text-emerald-200">{d.value}</p>
                          </div>
                          <button
                            onClick={() => {
                              navigator.clipboard?.writeText(d.value);
                              toast.ok(`${d.label} copied`);
                            }}
                            className="btn-ghost shrink-0 rounded-full px-3 py-1.5 text-[10.5px] font-bold"
                          >
                            Copy
                          </button>
                        </div>
                      ))}
                  </div>
                </div>
              ) : (
                <div className="rounded-xl border border-amber-400/25 bg-amber-500/10 px-3 py-2.5 text-[12px] text-amber-100/80">
                  The account details for this method have not been published yet. Please contact support before paying.
                </div>
              )}

              {method.instructions ? <p className="text-[12px] leading-relaxed text-white/45">{method.instructions}</p> : null}
            </div>
          ) : null}
        </div>
      ) : null}

      {/* -------------------------------- step 3 ------------------------------- */}
      {country ? (
        <div className="card anim-fade-up space-y-4 rounded-3xl p-5">
          <div className="flex items-center gap-3">
            <span className="grid h-8 w-8 place-items-center rounded-full bg-[var(--accent)] text-sm font-bold">3</span>
            <h3 className="text-base font-bold text-white">Submit your payment proof</h3>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Full name used for payment">
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Ali Raza" className={inputCls} />
            </Field>
            <Field label="Email / Telegram (optional)">
              <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="So we can reach you" className={inputCls} />
            </Field>
            <Field label="Transaction ID / reference">
              <input value={txn} onChange={(e) => setTxn(e.target.value)} placeholder="From your wallet or bank app" className={inputCls} />
            </Field>
            <Field label="Payment screenshot" hint="JPG or PNG · auto-compressed before upload">
              <input
                type="file"
                accept="image/*"
                onChange={async (e) => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  setProof(await compressImage(f));
                }}
                className="w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-[12px] text-white/60 file:mr-3 file:rounded-lg file:border-0 file:bg-[var(--accent)] file:px-3 file:py-1.5 file:text-[11px] file:font-bold file:text-white"
              />
            </Field>
          </div>

          {proof ? (
            <div className="overflow-hidden rounded-2xl border border-white/10">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={proof} alt="Payment proof preview" className="max-h-64 w-full object-contain bg-black/60" />
            </div>
          ) : null}

          <button onClick={submit} disabled={busy} className="btn-brand flex items-center gap-2 rounded-full px-6 py-3 text-sm font-bold disabled:opacity-60">
            {busy ? <Spinner size={16} /> : null} Submit for verification
          </button>
          <p className="text-[11px] text-white/35">
            Verification is manual and usually takes a few minutes. Once approved, premium is active for 30 days. Prefer a quick trial?{" "}
            <Link href="/access" className="font-bold text-[var(--accent-soft)]">Use today&apos;s code →</Link>
          </p>
        </div>
      ) : null}

      {!data ? (
        <div className="flex justify-center py-10">
          <Spinner />
        </div>
      ) : null}
    </div>
  );
}
