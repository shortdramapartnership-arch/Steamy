import { NextResponse, type NextRequest } from "next/server";
import { db } from "@/db";
import {
  accessGrants,
  channels,
  dubTracks,
  fetchRuns,
  paymentMethods,
  payments,
  users,
  videos,
} from "@/db/schema";
import { and, desc, eq, sql } from "drizzle-orm";
import { getSettings, saveSettings, type SettingsData } from "@/lib/settings";
import { autoFetch, ingestById, ingestByTitle, mirrorVideos } from "@/lib/ingest";
import { linlyTranscribe, probeLinly, probeWorker } from "@/lib/dubWorker";
import { dmSearch } from "@/lib/dailymotion";
import { COUNTRIES, METHODS, countryByCode, methodByKey } from "@/lib/countries";
import { firebaseSet, firebasePushLog } from "@/lib/firebase";
import { grantAccess } from "@/lib/access";

export const dynamic = "force-dynamic";

async function panelData() {
  const [cfg, vids, chans, rawPays, methods, runs, grantRows, accounts] = await Promise.all([
    getSettings(),
    db.select().from(videos).orderBy(desc(videos.createdAt)).limit(400),
    db.select().from(channels).orderBy(channels.stepOrder),
    db.select().from(payments).orderBy(desc(payments.createdAt)).limit(200),
    db.select().from(paymentMethods).orderBy(paymentMethods.countryCode, paymentMethods.sortOrder),
    db.select().from(fetchRuns).orderBy(desc(fetchRuns.createdAt)).limit(20),
    db.select().from(accessGrants).where(sql`${accessGrants.expiresAt} > now()`),
    db.select().from(users).orderBy(desc(users.lastSeenAt)).limit(200),
  ]);
  // Attach the signed-in Google/email account to each payment so the developer
  // can verify the person who actually bought the subscription.
  const accountById = new Map(accounts.map((a) => [a.id, a]));
  const pays = rawPays.map((p) => {
    const account = p.userId ? accountById.get(p.userId) : undefined;
    return {
      ...p,
      accountName: account?.name ?? "",
      accountEmail: account?.email ?? "",
      accountPicture: account?.picture ?? "",
      accountProvider: account?.provider ?? "",
      accountDeviceId: account?.lastDeviceId ?? "",
    };
  });
  const trackCount = await db.select({ n: sql<number>`count(*)::int` }).from(dubTracks);
  const platformCounts = await db
    .select({ platform: videos.platform, n: sql<number>`count(*)::int` })
    .from(videos)
    .where(eq(videos.hidden, false))
    .groupBy(videos.platform);
  return {
    platformCounts,
    settings: cfg,
    videos: vids,
    channels: chans,
    payments: pays,
    signups: accounts.slice(0, 12).map((a) => ({
      id: a.id,
      provider: a.provider,
      name: a.name,
      email: a.email,
      picture: a.picture,
      createdAt: a.createdAt,
      lastSeenAt: a.lastSeenAt,
    })),
    accounts: accounts.map((a) => ({
      id: a.id,
      provider: a.provider,
      name: a.name,
      email: a.email,
      picture: a.picture,
      lastDeviceId: a.lastDeviceId,
      createdAt: a.createdAt,
      lastSeenAt: a.lastSeenAt,
    })),
    methods,
    fetchRuns: runs,
    activeGrants: grantRows.length,
    dubTracks: trackCount[0]?.n ?? 0,
    countries: COUNTRIES,
    methodCatalog: METHODS,
  };
}

export async function GET() {
  return NextResponse.json(await panelData());
}

type Payload = Record<string, unknown>;

const str = (v: unknown, fallback = "") => (typeof v === "string" ? v : fallback);
const num = (v: unknown, fallback = 0) => (typeof v === "number" && Number.isFinite(v) ? v : Number(v) || fallback);
const bool = (v: unknown, fallback = false) => (typeof v === "boolean" ? v : fallback);

export async function POST(request: NextRequest) {
  let body: { action: string; payload?: Payload };
  try {
    body = (await request.json()) as { action: string; payload?: Payload };
  } catch {
    return NextResponse.json({ ok: false, error: "Bad request" }, { status: 400 });
  }
  const p = body.payload ?? {};
  const action = body.action;

  try {
    switch (action) {
      /* ------------------------------ branding ----------------------------- */
      case "save_branding": {
        const patch: Partial<SettingsData> = {
          platformName: str(p.platformName, "Steamy").slice(0, 40) || "Steamy",
          logoUrl: str(p.logoUrl).slice(0, 2_500_000),
          tagline: str(p.tagline).slice(0, 160),
          heroHeadline: str(p.heroHeadline).slice(0, 160),
          heroSubline: str(p.heroSubline).slice(0, 400),
          accent: str(p.accent, "#e11d48").slice(0, 20),
          categories: Array.isArray(p.categories) ? (p.categories as string[]).map((c) => String(c).slice(0, 40)).filter(Boolean) : [],
        };
        await saveSettings(patch);
        await firebasePushLog("branding_updated", { name: patch.platformName });
        break;
      }
      case "save_code": {
        await saveSettings({
          dailyCode: str(p.dailyCode).replace(/\D/g, "").slice(0, 4),
          dailyCodeActive: bool(p.dailyCodeActive, true),
        });
        break;
      }
      case "save_plan": {
        await saveSettings({
          monthlyPrice: num(p.monthlyPrice, 4.99),
          monthlyCurrency: str(p.monthlyCurrency, "USD").slice(0, 6).toUpperCase(),
          freePreviewSeconds: Math.max(0, Math.min(600, num(p.freePreviewSeconds, 120))),
        });
        break;
      }
      case "save_steps": {
        const steps = Array.isArray(p.freeAccessSteps)
          ? (p.freeAccessSteps as SettingsData["freeAccessSteps"]).map((s: SettingsData["freeAccessSteps"][number]) => ({
              title: String(s.title ?? "").slice(0, 120),
              body: String(s.body ?? "").slice(0, 600),
              ctaLabel: String(s.ctaLabel ?? "").slice(0, 60),
              ctaUrl: String(s.ctaUrl ?? "").slice(0, 300),
              proofLabel: String(s.proofLabel ?? "").slice(0, 80),
            }))
          : [];
        await saveSettings({ freeAccessSteps: steps });
        break;
      }
      case "save_apps": {
        const links = Array.isArray(p.appLinks)
          ? (p.appLinks as SettingsData["appLinks"]).map((l: SettingsData["appLinks"][number]) => ({
              label: String(l.label ?? "").slice(0, 40),
              url: String(l.url ?? "").slice(0, 300),
              icon: String(l.icon ?? "").slice(0, 8),
            }))
          : [];
        await saveSettings({ appLinks: links });
        break;
      }
      case "save_dub": {
        const langs = Array.isArray(p.dubLanguages) ? (p.dubLanguages as string[]).map(String) : [];
        const cast = ["male-female", "female-male", "male-only", "female-only"].includes(str(p.dubCast)) ? str(p.dubCast) : "male-female";
        await saveSettings({
          dubLanguages: langs.length ? langs : ["en"],
          dubCast: cast,
          ttsProvider: (str(p.ttsProvider, "browser") as SettingsData["ttsProvider"]) ?? "browser",
          ttsApiKey: str(p.ttsApiKey).slice(0, 200),
          ttsModel: str(p.ttsModel, "gpt-4o-mini-tts").slice(0, 60) || "gpt-4o-mini-tts",
          ttsVoice: str(p.ttsVoice).slice(0, 24),
        });
        break;
      }
      case "save_autofetch": {
        const queries = Array.isArray(p.autoFetchQueries)
          ? (p.autoFetchQueries as string[]).map((q) => String(q).slice(0, 90)).filter(Boolean)
          : [];
        await saveSettings({
          autoFetchEnabled: bool(p.autoFetchEnabled, true),
          autoFetchLimit: Math.max(30, Math.min(300, num(p.autoFetchLimit, 40))),
          autoFetchQueries: queries.length ? queries : ["short drama full episode"],
        });
        break;
      }

      /* -------------------------------- catalog ---------------------------- */
      case "run_autofetch": {
        const cfg = await getSettings();
        const res = await autoFetch(cfg.autoFetchQueries, Math.max(12, Math.ceil(cfg.autoFetchLimit / cfg.autoFetchQueries.length) + 5), cfg.autoFetchLimit);
        await firebasePushLog("auto_fetch", res);
        return NextResponse.json({ ok: true, result: res, data: await panelData() });
      }
      case "add_video": {
        const res = await ingestById(str(p.input));
        if (!res.ok) return NextResponse.json({ ok: false, error: res.error }, { status: 400 });
        return NextResponse.json({ ok: true, message: res.existed ? "Already in the catalog." : "Video added.", data: await panelData() });
      }
      case "add_video_title": {
        const res = await ingestByTitle(str(p.title), Math.max(1, Math.min(20, num(p.max, 6))));
        return NextResponse.json({ ok: true, result: res, data: await panelData() });
      }
      case "search_dailymotion": {
        const { videos: found } = await dmSearch(str(p.query), Math.max(1, Math.min(24, num(p.limit, 12))));
        return NextResponse.json({ ok: true, results: found });
      }
      case "update_video": {
        const id = num(p.id);
        if (!id) return NextResponse.json({ ok: false, error: "id required" }, { status: 400 });
        const patch: Record<string, unknown> = {};
        if (p.featured !== undefined) patch.featured = bool(p.featured);
        if (p.hidden !== undefined) patch.hidden = bool(p.hidden);
        if (p.category !== undefined) patch.category = str(p.category).slice(0, 40);
        if (p.title !== undefined) patch.title = str(p.title).slice(0, 300);
        if (Object.keys(patch).length) await db.update(videos).set(patch).where(eq(videos.id, id));
        await mirrorVideos();
        break;
      }
      case "delete_video": {
        const id = num(p.id);
        if (id) {
          await db.delete(videos).where(eq(videos.id, id));
          await db.delete(dubTracks).where(eq(dubTracks.videoId, id));
        }
        await mirrorVideos();
        break;
      }
      case "rebuild_dub": {
        const id = num(p.videoId);
        if (id) await db.delete(dubTracks).where(eq(dubTracks.videoId, id));
        break;
      }

      /* ------------- Linly-Dubbing: transcribe the real audio ------------- */
      case "linly_status": {
        const [probe, asr] = await Promise.all([probeWorker(), probeLinly()]);
        const real = await db
          .select({ n: sql<number>`count(*)::int` })
          .from(dubTracks)
          .where(eq(dubTracks.source, "linly-asr"));
        return NextResponse.json({
          ok: true,
          status: {
            tts: probe,
            asr,
            realTranscripts: real[0]?.n ?? 0,
          },
        });
      }
      case "build_transcript": {
        const id = num(p.videoId);
        if (!id) return NextResponse.json({ ok: false, error: "videoId required" }, { status: 400 });
        const [video] = await db.select().from(videos).where(eq(videos.id, id)).limit(1);
        if (!video) return NextResponse.json({ ok: false, error: "video not found" }, { status: 404 });
        const seconds = Math.max(60, Math.min(3600, num(p.seconds, 300)));
        const result = await linlyTranscribe({ dmId: video.dmId, seconds, model: str(p.model, "base") });
        if (!result.ok || !result.utterances?.length) {
          return NextResponse.json({ ok: false, error: (result as { error?: string }).error ?? "no speech detected" }, { status: 422 });
        }
        const cues = result.utterances.map((u) => ({
          start: u.start,
          end: u.end,
          speaker: u.speaker,
          text: u.text,
          words: u.words,
        }));
        await db.delete(dubTracks).where(eq(dubTracks.videoId, id));
        await db.insert(dubTracks).values({ videoId: id, lang: "src", source: "linly-asr", cues });
        return NextResponse.json({
          ok: true,
          message: `Real transcript built: ${cues.length} lines, ${result.wordCount} words from ${result.audioSeconds}s of audio (${result.language}).`,
          result: { language: result.language, lines: cues.length, words: result.wordCount, seconds: result.audioSeconds },
          data: await panelData(),
        });
      }

      /* -------------------------------- channels --------------------------- */
      case "add_channel": {
        const url = str(p.url);
        if (!url.startsWith("http")) return NextResponse.json({ ok: false, error: "Enter the full channel URL." }, { status: 400 });
        await db.insert(channels).values({
          platform: "youtube",
          title: str(p.title, "YouTube channel").slice(0, 120) || "YouTube channel",
          url,
          handle: str(p.handle).slice(0, 80),
          thumbnail: str(p.thumbnail).slice(0, 400),
          description: str(p.description).slice(0, 600),
          stepOrder: num(p.stepOrder, 0),
          active: true,
        });
        break;
      }
      case "update_channel": {
        const id = num(p.id);
        if (id) await db.update(channels).set({ active: bool(p.active, true) }).where(eq(channels.id, id));
        break;
      }
      case "delete_channel": {
        const id = num(p.id);
        if (id) await db.delete(channels).where(eq(channels.id, id));
        break;
      }

      /* ---------------------------- payments admin ------------------------- */
      case "save_methods": {
        const countryCode = str(p.countryCode);
        const country = countryByCode(countryCode);
        if (!country) return NextResponse.json({ ok: false, error: "Unknown country" }, { status: 400 });
        const list = Array.isArray(p.methods) ? (p.methods as Record<string, unknown>[]) : [];
        await db.delete(paymentMethods).where(eq(paymentMethods.countryCode, countryCode));
        let order = 0;
        for (const m of list) {
          const key = str(m.methodKey);
          const def = methodByKey(key);
          if (!def) continue;
          const rawAmount = num(m.amount, 0);
          const price = rawAmount > 0 ? rawAmount : num(p.defaultAmount, 0);
          // Structured "where to pay" rows, always aligned with the rail's fields.
          const incoming = Array.isArray(m.details) ? (m.details as Record<string, unknown>[]) : [];
          const details = def.fields.map((label, i) => ({
            label: label.slice(0, 70),
            value: str(incoming[i]?.value).slice(0, 200),
          }));
          await db.insert(paymentMethods).values({
            countryCode,
            methodKey: key,
            label: str(m.label, def.label).slice(0, 80) || def.label,
            icon: def.icon,
            address: details[0]?.value ?? "",
            accountName: details[1]?.value ?? "",
            details,
            instructions: str(m.instructions).slice(0, 900),
            amount: String(price > 0 ? price : 0),
            currency: str(m.currency, country.currency).slice(0, 6).toUpperCase() || country.currency,
            active: m.active === undefined ? true : bool(m.active, true),
            sortOrder: order++,
          });
        }
        await firebasePushLog("payment_methods_saved", { country: countryCode, count: list.length });
        break;
      }
      case "review_payment": {
        const id = num(p.id);
        const status = str(p.status) === "approved" ? "approved" : str(p.status) === "rejected" ? "rejected" : "pending";
        if (!id) return NextResponse.json({ ok: false, error: "id required" }, { status: 400 });
        const [row] = await db.select().from(payments).where(eq(payments.id, id)).limit(1);
        if (!row) return NextResponse.json({ ok: false, error: "Payment not found" }, { status: 404 });
        await db
          .update(payments)
          .set({ status, reviewNote: str(p.note).slice(0, 400), reviewedAt: new Date() })
          .where(eq(payments.id, id));
        if (status === "approved") {
          // Grant the device and the signed-in account, so premium follows the login.
          await grantAccess(row.deviceId, "subscription", 30 * 24, `${row.countryName} · ${row.methodLabel}`, row.userId ?? null);
          if (row.userId) {
            const { users } = await import("@/db/schema");
            const linked = await db.select().from(users).where(eq(users.id, row.userId)).limit(1);
            const target = linked[0]?.lastDeviceId;
            if (target && target !== row.deviceId) {
              await grantAccess(target, "subscription", 30 * 24, `${row.countryName} · ${row.methodLabel}`, row.userId);
            }
          }
        }
        await firebasePushLog("payment_reviewed", { id, status });
        break;
      }
      case "grant_manual": {
        const deviceId = str(p.deviceId).trim();
        const days = Math.max(1, Math.min(365, num(p.days, 30)));
        if (deviceId.length < 6) return NextResponse.json({ ok: false, error: "Enter a device id." }, { status: 400 });
        await grantAccess(deviceId, str(p.kind, "subscription") || "subscription", days * 24, "Manual grant");
        break;
      }
      default:
        return NextResponse.json({ ok: false, error: `Unknown action: ${action}` }, { status: 400 });
    }

    await firebaseSet("catalog/lastAdminUpdate", Date.now());
    return NextResponse.json({ ok: true, data: await panelData() });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: error instanceof Error ? error.message : "Action failed" },
      { status: 500 },
    );
  }
}
