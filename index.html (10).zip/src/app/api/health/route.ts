import { NextResponse } from "next/server";
import { sql } from "drizzle-orm";
import { db, hasDatabase } from "@/db";

export const dynamic = "force-dynamic";

/** Deployment healthcheck: reports process, database and dubbing-engine state. */
export async function GET() {
  let database: "ok" | "unconfigured" | "unreachable" = "unconfigured";
  let detail = "DATABASE_URL is not set";
  if (hasDatabase()) {
    try {
      await db.execute(sql`select 1`);
      database = "ok";
      detail = "connected";
    } catch (error) {
      database = "unreachable";
      detail = error instanceof Error ? error.message.slice(0, 180) : "connection failed";
    }
  }
  return NextResponse.json(
    {
      ok: database === "ok",
      database,
      detail,
      python: Boolean(process.env.DUB_PYTHON),
    },
    { status: 200 },
  );
}
