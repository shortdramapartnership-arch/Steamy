import { NextResponse, type NextRequest } from "next/server";
import { db } from "@/db";
import { videos } from "@/db/schema";
import { desc, eq, ne, sql } from "drizzle-orm";
import { classify, dmSearch, isDramaLike } from "@/lib/dailymotion";
import { ingestDmList } from "@/lib/ingest";
import type { SearchItem } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const q = (request.nextUrl.searchParams.get("q") ?? "").trim();
  const addToCatalog = request.nextUrl.searchParams.get("add") === "1";
  if (!q) return NextResponse.json({ results: [], local: [], message: "" });

  const localRows = await db
    .select()
    .from(videos)
    .where(sql`${videos.title} ILIKE ${"%" + q + "%"} AND ${videos.hidden} = false`)
    .orderBy(desc(videos.trendingScore))
    .limit(24);

  const { videos: remote } = await dmSearch(q, 24, "relevance");
  const remoteDramas = remote.filter(isDramaLike);
  const list = (remoteDramas.length >= 4 ? remoteDramas : remote).slice(0, 24);

  if (addToCatalog && list.length) {
    await ingestDmList(list.slice(0, 10), "user-search");
  }

  const localMap = new Map(localRows.map((r) => [r.dmId, r]));
  const seen = new Set<string>();
  const merged: SearchItem[] = [];
  for (const row of localRows) {
    seen.add(row.dmId);
    merged.push({
      id: row.id,
      dmId: row.dmId,
      title: row.title,
      thumbnail: row.thumbnail,
      duration: row.duration,
      owner: row.owner,
      category: row.category,
      views: row.views,
      inCatalog: true,
    });
  }
  for (const v of list) {
    if (seen.has(v.dmId)) continue;
    seen.add(v.dmId);
    merged.push({
      id: 0,
      dmId: v.dmId,
      title: v.title,
      thumbnail: v.thumbnail,
      duration: v.duration,
      owner: v.owner,
      category: classify(v),
      views: v.views,
      inCatalog: !!localMap.get(v.dmId),
    });
  }

  return NextResponse.json({ query: q, results: merged.slice(0, 30) });
}

export async function POST(request: NextRequest) {
  const body = (await request.json()) as { id?: number };
  if (!body.id) return NextResponse.json({ ok: false }, { status: 400 });
  await db.update(videos).set({ views: sql`${videos.views} + 1` }).where(eq(videos.id, body.id));
  const related = await db
    .select()
    .from(videos)
    .where(ne(videos.id, body.id))
    .orderBy(desc(videos.trendingScore))
    .limit(12);
  return NextResponse.json({ ok: true, related });
}
