import { NextResponse } from "next/server";
import { db } from "@/db";
import { comments, videos } from "@/db/schema";
import { and, desc, eq, ne, or, sql } from "drizzle-orm";
import { videoById } from "@/lib/ingest";
import { getAccess } from "@/lib/access";
import { getSettings } from "@/lib/settings";
import { firebaseSet } from "@/lib/firebase";

export const dynamic = "force-dynamic";

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const video = await videoById(Number(id));
  if (!video) return NextResponse.json({ error: "not_found" }, { status: 404 });

  await db.update(videos).set({ views: sql`${videos.views} + 1` }).where(eq(videos.id, video.id));

  const related = await db
    .select()
    .from(videos)
    .where(and(ne(videos.id, video.id), eq(videos.hidden, false), or(eq(videos.category, video.category), sql`true`)))
    .orderBy(desc(videos.trendingScore))
    .limit(14);

  const commentRows = await db
    .select()
    .from(comments)
    .where(eq(comments.videoId, video.id))
    .orderBy(desc(comments.createdAt))
    .limit(80);

  const [access, cfg] = await Promise.all([getAccess(), getSettings()]);

  return NextResponse.json({
    video: { ...video, views: video.views + 1 },
    related,
    comments: commentRows,
    access,
    settings: {
      platformName: cfg.platformName,
      freePreviewSeconds: cfg.freePreviewSeconds,
      dubLanguages: cfg.dubLanguages,
      dailyCodeActive: cfg.dailyCodeActive,
      monthlyPrice: cfg.monthlyPrice,
      monthlyCurrency: cfg.monthlyCurrency,
    },
  });
}

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = (await request.json()) as { author?: string; body?: string };
  const author = (body.author ?? "").trim().slice(0, 40) || "Guest";
  const text = (body.body ?? "").trim().slice(0, 900);
  if (!text) return NextResponse.json({ ok: false, error: "Comment is empty" }, { status: 400 });
  const [row] = await db
    .insert(comments)
    .values({ videoId: Number(id), author, body: text })
    .returning();
  await firebaseSet(`live/comments/${id}/${row.id}`, { author, body: text, at: Date.now() });
  return NextResponse.json({ ok: true, comment: row });
}
