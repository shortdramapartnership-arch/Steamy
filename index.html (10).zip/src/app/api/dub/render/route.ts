import { NextResponse, type NextRequest } from "next/server";
import { db } from "@/db";
import { dubTracks, type DubCue } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { videoById } from "@/lib/ingest";
import { getAccess, isPremium } from "@/lib/access";
import { getSettings } from "@/lib/settings";
import { EDGE_VOICES, assignCharacters, buildSegments } from "@/lib/dub";
import { linlyTranscribe, probeLinly, probeWorker, renderUtterances, type RenderClip } from "@/lib/dubWorker";
import { languageByCode } from "@/lib/languages";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

/** Engine + voice availability for the Dub Studio. */
export async function GET() {
  const [probe, asr, cfg] = await Promise.all([probeWorker(), probeLinly(), getSettings()]);
  const free = probe.edge_tts;
  const openai = Boolean(cfg.ttsApiKey.trim() || process.env.OPENAI_API_KEY);
  const engine = free ? "linly-dubbing" : openai && cfg.ttsProvider === "openai" ? "openai" : "browser";
  return NextResponse.json({
    engine,
    engineLabel:
      engine === "linly-dubbing"
        ? "Linly-Dubbing · Whisper ASR + Edge neural voices"
        : engine === "openai"
          ? "OpenAI neural TTS"
          : "Device neural voices",
    probe,
    asr,
    pipeline: {
      asr: asr.faster_whisper ? "faster-whisper (word timestamps)" : "unavailable",
      translation: "Google / MyMemory",
      tts: probe.edge_tts ? "Edge neural TTS (free)" : "device voices",
      vocalSeparation: "requires GPU — skipped",
      voiceCloning: "requires GPU — skipped",
    },
    openai,
    languages: Object.keys(EDGE_VOICES),
  });
}

/**
 * Renders a window of the neural dub track. The client asks for the next few
 * phrases as playback advances, exactly like an adaptive audio track.
 */
export async function POST(request: NextRequest) {
  const body = (await request.json()) as { videoId?: number; lang?: string; from?: number; count?: number; preferFemale?: boolean };
  const videoId = Number(body.videoId);
  const lang = (body.lang ?? "en").slice(0, 10);
  const from = Math.max(0, Number(body.from ?? 0));
  const count = Math.min(14, Math.max(1, Number(body.count ?? 8)));

  if (!videoId) return NextResponse.json({ error: "videoId required" }, { status: 400 });

  const access = await getAccess();
  if (!isPremium(access)) return NextResponse.json({ error: "premium_required" }, { status: 402 });

  const video = await videoById(videoId);
  if (!video) return NextResponse.json({ error: "not_found" }, { status: 404 });

  // Load (or build) the timed cue list, then group it into speech phrases.
  let cues: DubCue[] = [];
  const src = await db
    .select()
    .from(dubTracks)
    .where(and(eq(dubTracks.videoId, videoId), eq(dubTracks.lang, "src")))
    .limit(1);
  if (src[0]?.cues?.length) {
    cues = src[0].cues;
  } else {
    const { dmSubtitleText } = await import("@/lib/dailymotion");
    const { buildAutoScript, parseScript } = await import("@/lib/dub");
    const sub = await dmSubtitleText(video.dmId);
    cues = sub?.includes("-->")
      ? parseScript(sub, video.duration, video.title)
      : buildAutoScript(video.dmId, video.duration, video.title, video.category);
    await db.insert(dubTracks).values({ videoId, lang: "src", source: sub ? "dailymotion-subtitles" : "ai-dub-script", cues }).onConflictDoNothing();
  }

  const cfgSettings = await getSettings();
  const target = lang === "en" ? cues : await translateCues(videoId, lang, cues);
  const castSegments = assignCharacters(buildSegments(target), cfgSettings.dubCast);
  const segments = castSegments;
  const window = segments.slice(from, from + count);

  if (!window.length) return NextResponse.json({ engine: "linly-dubbing", clips: [], from, total: segments.length });

  const result = await renderUtterances({
    videoId,
    lang,
    utterances: window.map((segment, i) => {
      const gender = segment.character.gender;
      const voice = EDGE_VOICES[lang]?.[gender] ?? "";
      return {
        index: from + i,
        start: segment.start,
        end: segment.end,
        speaker: segment.character.label,
        gender,
        voice,
        text: segment.text,
      };
    }),
    voices: EDGE_VOICES,
    preferFemale: Boolean(body.preferFemale),
  });
  // One retry pass for any phrase Edge throttled.
  if (result.rendered < result.requested) {
    const retry = await renderUtterances({
      videoId,
      lang,
      utterances: window
        .map((segment, i) => ({ segment, i }))
        .filter(({ i }) => !result.clips[i]?.audio)
        .map(({ segment, i }) => ({
          index: from + i,
          start: segment.start,
          end: segment.end,
          speaker: segment.character.label,
          gender: segment.character.gender,
          voice: EDGE_VOICES[lang]?.[segment.character.gender] ?? "",
          text: segment.text,
        })),
      voices: EDGE_VOICES,
      preferFemale: Boolean(body.preferFemale),
    });
    const merged = [...result.clips];
    retry.clips.forEach((clip) => {
      if (clip.audio) merged[clip.index - from] = clip;
    });
    result.clips = merged;
    result.rendered = merged.filter((c) => c.audio).length;
  }

  const language = languageByCode(lang);
  return NextResponse.json({
    engine: "linly-dubbing",
    engineDetail: result.engine_detail,
    lang,
    languageLabel: language?.nativeLabel ?? lang,
    castKey: cfgSettings.dubCast,
    from,
    total: segments.length,
    clips: result.clips as RenderClip[],
    rendered: result.rendered,
    requested: result.requested,
  });
}

async function translateCues(videoId: number, lang: string, cues: DubCue[]): Promise<DubCue[]> {
  const cached = await db
    .select()
    .from(dubTracks)
    .where(and(eq(dubTracks.videoId, videoId), eq(dubTracks.lang, lang)))
    .limit(1);
  if (cached[0]?.cues?.length) return cached[0].cues;

  const { translateLines, timeWords } = await import("@/lib/dub");
  const translated = await translateLines(cues.map((c) => c.text), lang, "en");
  const next = cues.map((c, i) => ({
    ...c,
    translated: translated[i] ?? c.text,
    words: timeWords(translated[i] ?? c.text, c.start, c.end),
  }));
  await db.insert(dubTracks).values({ videoId, lang, source: "linly-dubbing", cues: next }).onConflictDoNothing();
  return next;
}
