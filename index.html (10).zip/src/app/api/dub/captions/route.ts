import { NextResponse, type NextRequest } from "next/server";
import { getAccess, isPremium } from "@/lib/access";
import { describeCaptionSource, ensureEnglishTranscript, type CaptionsState } from "@/lib/captions";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/** Reports whether a title has auto-generated English captions yet. */
export async function GET(request: NextRequest) {
  const videoId = Number(request.nextUrl.searchParams.get("videoId"));
  if (!videoId) return NextResponse.json({ error: "videoId required" }, { status: 400 });
  const state = await ensureEnglishTranscript(videoId, 1);
  // A one second probe only checks the cache; do not transcribe on GET.
  const ready = state.status === "ready";
  return NextResponse.json({
    status: ready ? "ready" : "missing",
    source: ready ? describeCaptionSource(state.source) : null,
    cues: ready ? state.cues : [],
  });
}

/**
 * Generates the English captions for a title from its real audio. Every other
 * dubbing language is derived from this transcript, exactly like YouTube's
 * multi-audio workflow.
 */
export async function POST(request: NextRequest) {
  const body = (await request.json()) as { videoId?: number; seconds?: number };
  const videoId = Number(body.videoId);
  const seconds = Math.max(60, Math.min(600, Number(body.seconds ?? 120)));
  if (!videoId) return NextResponse.json({ error: "videoId required" }, { status: 400 });

  const access = await getAccess();
  if (!isPremium(access)) return NextResponse.json({ error: "premium_required" }, { status: 402 });

  const state: CaptionsState = await ensureEnglishTranscript(videoId, seconds);
  return NextResponse.json(
    {
      ...state,
      sourceLabel: describeCaptionSource(state.source),
    },
    { status: state.status === "failed" ? 422 : 200 },
  );
}
