import { NextResponse, type NextRequest } from "next/server";
import { db } from "@/db";
import { dubTracks, type DubCue } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { videoById } from "@/lib/ingest";
import { dmSubtitleText } from "@/lib/dailymotion";
import { buildAutoScript, parseScript, timeWords, translateLines } from "@/lib/dub";
import { getAccess, isPremium } from "@/lib/access";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

async function loadSourceCues(videoId: number): Promise<{ cues: DubCue[]; source: string; duration: number; title: string }> {
  const video = await videoById(videoId);
  if (!video) return { cues: [], source: "none", duration: 0, title: "" };

  const stored = await db
    .select()
    .from(dubTracks)
    .where(and(eq(dubTracks.videoId, videoId), eq(dubTracks.lang, "src")))
    .limit(1);
  if (stored[0]?.cues?.length) {
    return { cues: stored[0].cues, source: stored[0].source, duration: video.duration, title: video.title };
  }

  let cues: DubCue[] = [];
  let source = "auto";

  // 1) Real Dailymotion subtitle track, when the uploader provided one.
  const sub = await dmSubtitleText(video.dmId);
  if (sub && sub.includes("-->")) {
    cues = parseScript(sub, video.duration, video.title);
    source = "dailymotion-subtitles";
  }

  // 2) YouTube-style auto captions: transcribe the real audio with Whisper.
  if (!cues.length) {
    const { ensureEnglishTranscript } = await import("@/lib/captions");
    const state = await ensureEnglishTranscript(videoId, 120);
    if (state.status === "ready" && state.cues?.length) {
      cues = state.cues;
      source = "linly-asr";
    }
  }

  // 3) Manual script stored in the video description block.
  if (!cues.length && video.description.includes("::script::")) {
    const raw = video.description.split("::script::")[1] ?? "";
    cues = parseScript(raw, video.duration, video.title);
    source = "manual-script";
  }

  // 4) Timed fallback script so the dub studio still has something to speak.
  if (!cues.length) {
    cues = buildAutoScript(video.dmId, video.duration, video.title, video.category);
    source = "ai-dub-script";
  }

  cues = cues.map((c) => ({ ...c, words: c.words?.length ? c.words : timeWords(c.text, c.start, c.end) }));
  await db.insert(dubTracks).values({ videoId, lang: "src", source, cues }).onConflictDoNothing();
  return { cues, source, duration: video.duration, title: video.title };
}

export async function GET(request: NextRequest) {
  const videoId = Number(request.nextUrl.searchParams.get("videoId"));
  const lang = request.nextUrl.searchParams.get("lang") ?? "en";
  if (!videoId) return NextResponse.json({ error: "videoId required" }, { status: 400 });

  const access = await getAccess();
  const cfg = await getSettings();
  const allowed = isPremium(access) || lang === "en";
  if (!allowed) {
    return NextResponse.json(
      { error: "premium_required", message: "Dubbing into every language is a premium feature." },
      { status: 402 },
    );
  }

  const base = await loadSourceCues(videoId);
  if (!base.cues.length) return NextResponse.json({ error: "not_found" }, { status: 404 });

  if (lang === "en") {
    return NextResponse.json({ lang, source: base.source, cues: base.cues });
  }

  const cached = await db
    .select()
    .from(dubTracks)
    .where(and(eq(dubTracks.videoId, videoId), eq(dubTracks.lang, lang)))
    .limit(1);
  if (cached[0]?.cues?.length) {
    return NextResponse.json({ lang, source: base.source, cues: cached[0].cues });
  }

  const lines = base.cues.map((c) => c.text);
  const translated = await translateLines(lines, lang, "en");
  const cues: DubCue[] = base.cues.map((c, i) => ({
    ...c,
    translated: translated[i] ?? c.text,
    words: timeWords(translated[i] ?? c.text, c.start, c.end),
  }));

  await db.insert(dubTracks).values({ videoId, lang, source: base.source, cues }).onConflictDoNothing();
  return NextResponse.json({ lang, source: base.source, cues, provider: cfg.ttsProvider });
}
