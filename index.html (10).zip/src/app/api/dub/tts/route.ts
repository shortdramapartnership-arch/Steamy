import { NextResponse, type NextRequest } from "next/server";
import { createHash } from "node:crypto";
import { db } from "@/db";
import { ttsCache } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getAccess, isPremium, trimTtsCache } from "@/lib/access";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

/** Studio voices exposed by OpenAI — mapped to dub presets on the client. */
export const OPENAI_VOICES = ["alloy", "ash", "ballad", "coral", "echo", "fable", "nova", "onyx", "sage", "shimmer"];

function apiKey(cfg: { ttsApiKey: string }) {
  return cfg.ttsApiKey?.trim() || process.env.OPENAI_API_KEY || "";
}

/** Reports which dubbing engine the player should use. */
export async function GET() {
  const cfg = await getSettings();
  const key = apiKey(cfg);
  const provider = cfg.ttsProvider === "openai" && key ? "openai" : "browser";
  return NextResponse.json({
    provider,
    model: cfg.ttsModel || process.env.OPENAI_TTS_MODEL || "gpt-4o-mini-tts",
    voice: cfg.ttsVoice || "alloy",
    voices: OPENAI_VOICES,
    ready: provider === "openai",
  });
}

type Body = {
  videoId?: number;
  lang?: string;
  text?: string;
  voice?: string;
  instructions?: string;
};

/**
 * Generates one dubbed phrase with OpenAI's neural TTS and returns it as a
 * data URL. Cached in Postgres so a phrase is only ever synthesised once.
 */
export async function POST(request: NextRequest) {
  const body = (await request.json()) as Body;
  const text = (body.text ?? "").trim().slice(0, 900);
  if (!text) return NextResponse.json({ error: "text required" }, { status: 400 });

  const access = await getAccess();
  if (!isPremium(access)) {
    return NextResponse.json({ error: "premium_required" }, { status: 402 });
  }

  const cfg = await getSettings();
  const key = apiKey(cfg);
  if (!key) return NextResponse.json({ error: "no_api_key", fallback: "browser" }, { status: 503 });

  const lang = (body.lang ?? "en").slice(0, 10);
  const voice = (body.voice || cfg.ttsVoice || "alloy").slice(0, 24);
  const model = cfg.ttsModel || process.env.OPENAI_TTS_MODEL || "gpt-4o-mini-tts";
  const hash = createHash("sha1").update(`${model}|${voice}|${lang}|${text}`).digest("hex");

  const cached = await db.select().from(ttsCache).where(eq(ttsCache.hash, hash)).limit(1);
  if (cached[0]) {
    return NextResponse.json({ ok: true, cached: true, audio: cached[0].audio, voice, model });
  }

  try {
    const res = await fetch("https://api.openai.com/v1/audio/speech", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model,
        voice,
        input: text,
        response_format: "mp3",
        // Keep the delivery consistent with the drama's tone.
        instructions:
          (body.instructions ?? "").slice(0, 300) ||
          "Voice a line of dialogue in a modern romantic drama. Natural, warm, cinematic delivery. Do not rush.",
      }),
      signal: AbortSignal.timeout(30_000),
    });

    if (!res.ok) {
      const detail = await res.text().catch(() => "");
      return NextResponse.json(
        { error: "tts_failed", status: res.status, fallback: "browser", detail: detail.slice(0, 200) },
        { status: 502 },
      );
    }

    const buffer = Buffer.from(await res.arrayBuffer());
    const audio = `data:audio/mpeg;base64,${buffer.toString("base64")}`;
    if (buffer.byteLength > 0 && buffer.byteLength < 3_000_000) {
      await db
        .insert(ttsCache)
        .values({ hash, lang, voice, audio, bytes: buffer.byteLength })
        .onConflictDoNothing();
      trimTtsCache(400).catch(() => {});
    }
    return NextResponse.json({ ok: true, audio, voice, model, bytes: buffer.byteLength });
  } catch {
    return NextResponse.json({ error: "tts_failed", fallback: "browser" }, { status: 502 });
  }
}
