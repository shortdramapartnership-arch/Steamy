import { NextResponse, type NextRequest } from "next/server";
import { db } from "@/db";
import { paymentMethods, payments } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { COUNTRIES, METHODS, countryByCode } from "@/lib/countries";
import { getAccess, getSessionUser } from "@/lib/access";
import { getSettings } from "@/lib/settings";
import { firebaseSet } from "@/lib/firebase";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const code = request.nextUrl.searchParams.get("country") ?? "";
  const [cfg, access, user] = await Promise.all([getSettings(), getAccess(), getSessionUser()]);
  const rows = await db
    .select()
    .from(paymentMethods)
    .where(eq(paymentMethods.active, true))
    .orderBy(paymentMethods.sortOrder);

  type PublicMethod = Omit<(typeof rows)[number], "details"> & { details: { label: string; value: string }[] };
  const methods: PublicMethod[] = rows.map((m) => ({
    ...m,
    details: m.details?.length
      ? m.details
      : [
          { label: "Account / address", value: m.address },
          { label: "Account name", value: m.accountName },
        ].filter((d) => d.value),
  }));

  return NextResponse.json({
    access,
    user: user ? { id: user.id, name: user.name, email: user.email, picture: user.picture, provider: user.provider } : null,
    countries: COUNTRIES,
    methodCatalog: METHODS,
    defaultPrice: cfg.monthlyPrice,
    defaultCurrency: cfg.monthlyCurrency,
    /** Only the rails the developer configured for each country. */
    methodsByCountry: methods.reduce<Record<string, PublicMethod[]>>((acc, m) => {
      (acc[m.countryCode] ||= []).push(m);
      return acc;
    }, {}),
  });
}

type Body = {
  countryCode: string;
  methodKey: string;
  payerName: string;
  payerEmail?: string;
  transactionId?: string;
  proofImage?: string;
};

export async function POST(request: NextRequest) {
  const body = (await request.json()) as Body;
  const [access, user] = await Promise.all([getAccess(), getSessionUser()]);
  if (access.deviceId === "anonymous") {
    return NextResponse.json({ ok: false, error: "Enable cookies to submit a payment." }, { status: 400 });
  }
  const country = countryByCode(body.countryCode);
  if (!country) return NextResponse.json({ ok: false, error: "Select your country." }, { status: 400 });
  if (!body.payerName || body.payerName.trim().length < 2) {
    return NextResponse.json({ ok: false, error: "Enter the name used for the payment." }, { status: 400 });
  }
  if (!body.proofImage || body.proofImage.length < 200) {
    return NextResponse.json({ ok: false, error: "Upload a screenshot of your payment proof." }, { status: 400 });
  }

  const configured = await db
    .select()
    .from(paymentMethods)
    .where(and(eq(paymentMethods.countryCode, country.code), eq(paymentMethods.methodKey, body.methodKey)))
    .limit(1);
  const cfg = await getSettings();
  const raw = configured[0];
  const method = raw
    ? {
        ...raw,
        // Legacy rows predating the structured details column.
        details:
          raw.details?.length
            ? raw.details
            : [
                { label: "Account / address", value: raw.address },
                { label: "Account name", value: raw.accountName },
              ].filter((d) => d.value),
      }
    : undefined;
  const amount = method && Number(method.amount) > 0 ? Number(method.amount) : cfg.monthlyPrice;
  const currency = method?.currency || country.currency;

  const [row] = await db
    .insert(payments)
    .values({
      deviceId: access.deviceId,
      userId: user?.id ?? null,
      countryCode: country.code,
      countryName: country.name,
      methodKey: body.methodKey,
      methodLabel: method?.label ?? body.methodKey,
      amount: String(amount),
      currency,
      payerName: body.payerName.trim().slice(0, 80),
      payerEmail: (body.payerEmail ?? "").trim().slice(0, 120),
      transactionId: (body.transactionId ?? "").trim().slice(0, 120),
      proofImage: body.proofImage.slice(0, 3_500_000),
      status: "pending",
    })
    .returning({ id: payments.id, createdAt: payments.createdAt });

  await firebaseSet(`live/payments/${row.id}`, {
    deviceId: access.deviceId,
    country: country.code,
    method: body.methodKey,
    amount,
    currency,
    at: Date.now(),
  });

  return NextResponse.json({
    ok: true,
    paymentId: row.id,
    message: "Payment submitted. Verification usually takes a few minutes.",
  });
}
