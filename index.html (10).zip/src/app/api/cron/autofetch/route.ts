import { NextResponse, type NextRequest } from "next/server";
import { db } from "@/db";
import { fetchRuns } from "@/db/schema";
import { and, desc, eq, isNull } from "drizzle-orm";
import { videos, dubTracks } from "@/db/schema";
import { getSettings } from "@/lib/settings";
import { autoFetch, pruneDeadVideos } from "@/lib/ingest";
import { ensureBootstrap } from "@/lib/bootstrap";
import { firebaseSet } from "@/lib/firebase";

export const dynamic = "force-dynamic";

/**
 * Hourly trending refresh. Called by the app shell every hour and safe to wire
 * to an external cron (e.g. `curl /api/cron/autofetch?key=...`).
 */
const STARTED = Date.now();

async function handle(request: NextRequest) {
  await ensureBootstrap();
  // Serverless platforms kill long functions. Never start a sweep that cannot
  // finish inside a short budget — the dev console can always run it manually.
  const BUDGET_MS = Number(process.env.DUB_FETCH_BUDGET_MS ?? 20_000);
  if (Date.now() - STARTED > BUDGET_MS) {
    return NextResponse.json({ ok: true, skipped: "time budget exhausted" });
  }
  const cfg = await getSettings();
  if (!cfg.autoFetchEnabled) {
    return NextResponse.json({ ok: true, skipped: "auto fetch disabled" });
  }
  const key = request.nextUrl.searchParams.get("key");
  if (process.env.CRON_KEY && key !== process.env.CRON_KEY) {
    return NextResponse.json({ ok: false, error: "unauthorized" }, { status: 401 });
  }
  const last = await db.select().from(fetchRuns).orderBy(desc(fetchRuns.createdAt)).limit(1);
  const lastAt = last[0]?.createdAt?.getTime() ?? 0;
  const ageMinutes = (Date.now() - lastAt) / 60_000;
  if (lastAt && ageMinutes < 55) {
    return NextResponse.json({ ok: true, skipped: `last run ${Math.round(ageMinutes)} minutes ago` });
  }
  const perQuery = Math.max(12, Math.ceil(cfg.autoFetchLimit / Math.max(1, cfg.autoFetchQueries.length)) + 5);
  const [result, pruned] = await Promise.all([
    autoFetch(cfg.autoFetchQueries, perQuery, cfg.autoFetchLimit),
    pruneDeadVideos(18),
  ]);
  // Progressively generate real Whisper captions for the catalog.
  try {
    const { warmTranscript } = await import("@/lib/captions");
    const missing = await db
      .select({ id: videos.id })
      .from(videos)
      .leftJoin(dubTracks, eq(dubTracks.videoId, videos.id))
      .where(and(eq(videos.hidden, false), isNull(dubTracks.id)))
      .orderBy(desc(videos.trendingScore))
      .limit(2);
    for (const row of missing) await warmTranscript(row.id, 120);
  } catch {
    /* caption warm-up is best effort */
  }
  await firebaseSet("catalog/lastAutoFetch", { at: Date.now(), added: result.added });
  return NextResponse.json({ ok: true, ...result, pruned });
}

export async function GET(request: NextRequest) {
  return handle(request);
}
export async function POST(request: NextRequest) {
  return handle(request);
}
