import { NextResponse, type NextRequest } from "next/server";
import { ingestById, ingestFromSearch } from "@/lib/ingest";

export const dynamic = "force-dynamic";

type Body = {
  input?: string;
  item?: {
    dmId: string;
    title: string;
    thumbnail?: string;
    duration?: number;
    owner?: string;
    views?: number;
    category?: string;
    description?: string;
  };
};

/**
 * Public endpoint: viewers can open any Dailymotion result they find via search.
 * Falls back to the search payload if the video endpoint is unavailable.
 */
export async function POST(request: NextRequest) {
  let body: Body;
  try {
    body = (await request.json()) as Body;
  } catch {
    return NextResponse.json({ ok: false, error: "Bad request" }, { status: 400 });
  }
  const input = (body.input ?? "").trim();
  if (!input && !body.item?.dmId) {
    return NextResponse.json({ ok: false, error: "input required" }, { status: 400 });
  }

  const res = input ? await ingestById(input) : { ok: false as const, error: "no input" };
  if (res.ok) return NextResponse.json({ ok: true, id: res.video.id, video: res.video });

  if (body.item?.dmId && body.item.title) {
    const fallback = await ingestFromSearch(body.item);
    if (fallback.ok) return NextResponse.json({ ok: true, id: fallback.video.id, video: fallback.video });
  }

  return NextResponse.json({ ok: false, error: res.ok ? "unreachable" : res.error }, { status: 404 });
}
