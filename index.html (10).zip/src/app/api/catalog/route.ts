import { NextResponse } from "next/server";
import { db } from "@/db";
import { channels, videos } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";
import { ensureBootstrap } from "@/lib/bootstrap";
import { getAccess } from "@/lib/access";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

/** Only the fields the catalog grid needs — keeps the payload small and fast. */
const CATALOG_COLUMNS = {
  id: videos.id,
  dmId: videos.dmId,
  title: videos.title,
  thumbnail: videos.thumbnail,
  duration: videos.duration,
  owner: videos.owner,
  category: videos.category,
  platform: videos.platform,
  views: videos.views,
  trendingScore: videos.trendingScore,
  featured: videos.featured,
  createdAt: videos.createdAt,
};

/**
 * Seeds an empty catalog in the background. Fire-and-forget so the response is
 * returned immediately — a long-running sweep would blow the function timeout
 * on Netlify and leave the viewer with an empty page.
 */
async function seedInBackground() {
  try {
    const { autoFetch } = await import("@/lib/ingest");
    const { getSettings } = await import("@/lib/settings");
    const cfg = await getSettings();
    await autoFetch(cfg.autoFetchQueries.slice(0, 8), 8, cfg.autoFetchLimit);
    const { seedPaymentMethods } = await import("@/lib/seedPayments");
    await seedPaymentMethods(DEFAULT_PRICE);
  } catch {
    /* seeding is best effort */
  }
}
const DEFAULT_PRICE = 4.99;

export async function GET() {
  const started = Date.now();
  await ensureBootstrap();

  const [cfg, access, rows, chans, cats] = await Promise.all([
    getSettings(),
    getAccess(),
    db
      .select(CATALOG_COLUMNS)
      .from(videos)
      .where(eq(videos.hidden, false))
      .orderBy(desc(videos.trendingScore), desc(videos.createdAt))
      .limit(240),
    db.select().from(channels).where(eq(channels.active, true)).orderBy(channels.stepOrder),
    db
      .select({ category: videos.category, n: sql<number>`count(*)::int` })
      .from(videos)
      .where(eq(videos.hidden, false))
      .groupBy(videos.category),
  ]);

  if (rows.length === 0) void seedInBackground();

  return NextResponse.json(
    {
      settings: {
        platformName: cfg.platformName,
        logoUrl: cfg.logoUrl,
        tagline: cfg.tagline,
        heroHeadline: cfg.heroHeadline,
        heroSubline: cfg.heroSubline,
        accent: cfg.accent,
        categories: cfg.categories,
        monthlyPrice: cfg.monthlyPrice,
        monthlyCurrency: cfg.monthlyCurrency,
        freePreviewSeconds: cfg.freePreviewSeconds,
        freeAccessSteps: cfg.freeAccessSteps,
        appLinks: cfg.appLinks,
        dubLanguages: cfg.dubLanguages,
        dailyCodeActive: cfg.dailyCodeActive,
      },
      access,
      user: null,
      videos: rows,
      channels: chans,
      categoryCounts: cats,
      seeding: rows.length === 0,
      elapsedMs: Date.now() - started,
    },
    { headers: { "Cache-Control": "no-store" } },
  );
}
