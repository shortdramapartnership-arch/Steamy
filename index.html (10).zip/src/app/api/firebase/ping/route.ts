import { NextResponse } from "next/server";
import { firebaseConfig, firebasePing } from "@/lib/firebase";

export const dynamic = "force-dynamic";

/** Reports whether the Realtime Database mirror accepts writes. */
export async function GET() {
  const ok = await firebasePing();
  return NextResponse.json({
    ok,
    reason: ok ? null : "RTDB rules denied the write or the project is unreachable",
    project: firebaseConfig.projectId,
    databaseURL: firebaseConfig.databaseURL,
  });
}
