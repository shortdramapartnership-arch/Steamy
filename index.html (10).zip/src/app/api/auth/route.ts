import { NextResponse, type NextRequest } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { getAccess, getSessionUser, linkSessionToDevice, USER_COOKIE } from "@/lib/access";
import { firebaseSet, firebasePushLog } from "@/lib/firebase";

export const dynamic = "force-dynamic";

/** Current session: account + live access level. */
export async function GET() {
  const [user, access] = await Promise.all([getSessionUser(), getAccess()]);
  return NextResponse.json({
    user: user ? { id: user.id, provider: user.provider, name: user.name, email: user.email, picture: user.picture } : null,
    access,
  });
}

type SignInBody = {
  provider?: "google" | "email";
  uid?: string;
  email?: string;
  name?: string;
  picture?: string;
};

/** Sign in / sign up. Works with Firebase Google sign-in or a plain email account. */
export async function POST(request: NextRequest) {
  const body = (await request.json()) as SignInBody;
  const provider = body.provider === "email" ? "email" : "google";
  const email = (body.email ?? "").trim().toLowerCase().slice(0, 160);
  const name = (body.name ?? "").trim().slice(0, 80);
  const uid = (body.uid ?? "").trim().slice(0, 80);

  if (provider === "email" && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    return NextResponse.json({ ok: false, error: "Enter a valid email address." }, { status: 400 });
  }
  if (provider === "google" && !uid && !email) {
    return NextResponse.json({ ok: false, error: "Google did not return an account." }, { status: 400 });
  }
  if (!name && !email) {
    return NextResponse.json({ ok: false, error: "Enter your name." }, { status: 400 });
  }

  const key = uid || email;
  const existing = await db
    .select()
    .from(users)
    .where(and(eq(users.provider, provider), eq(users.providerUid, key)))
    .limit(1);

  let user = existing[0];
  if (user) {
    await db
      .update(users)
      .set({
        name: name || user.name,
        email: email || user.email,
        picture: (body.picture ?? "").slice(0, 400) || user.picture,
        lastSeenAt: new Date(),
      })
      .where(eq(users.id, user.id));
  } else {
    const inserted = await db
      .insert(users)
      .values({
        provider,
        providerUid: key,
        email,
        name: name || email.split("@")[0],
        picture: (body.picture ?? "").slice(0, 400),
      })
      .returning();
    user = inserted[0];
  }

  const access = await getAccess();
  const wasNew = !existing;
  await linkSessionToDevice(user, access.deviceId);

  // Notify the developer: the name and Gmail of every new account is pushed to
  // the realtime database so a subscription can be matched to a real person.
  if (wasNew) {
    await firebaseSet(`signups/${user.id}`, {
      id: user.id,
      name: user.name,
      email: user.email,
      provider: user.provider,
      at: Date.now(),
    });
    await firebasePushLog("signup", { name: user.name, email: user.email, provider: user.provider });
  }

  const response = NextResponse.json({
    ok: true,
    user: { id: user.id, provider: user.provider, name: user.name, email: user.email, picture: user.picture },
    access: await getAccess(),
  });
  response.cookies.set(USER_COOKIE, `${user.id}.${Date.now().toString(36)}`, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 120,
  });
  return response;
}

export async function DELETE() {
  const response = NextResponse.json({ ok: true });
  response.cookies.set(USER_COOKIE, "", { path: "/", maxAge: 0 });
  return response;
}
