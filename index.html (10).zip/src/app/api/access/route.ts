import { NextResponse, type NextRequest } from "next/server";
import { db } from "@/db";
import { accessGrants, channels } from "@/db/schema";
import { and, eq, gt } from "drizzle-orm";
import { getAccess } from "@/lib/access";
import { getSettings } from "@/lib/settings";
import { firebaseSet } from "@/lib/firebase";

export const dynamic = "force-dynamic";

export async function GET() {
  const access = await getAccess();
  return NextResponse.json({
    access,
    debug: {
      hasDevice: access.deviceId !== "anonymous",
      level: access.level,
      // How much time is left, for the client to show a countdown if it wants.
      hoursLeft: access.hoursLeft,
    },
  });
}

type Body = {
  mode: "code" | "steps";
  code?: string;
  steps?: { proof: string }[];
};

export async function POST(request: NextRequest) {
  const body = (await request.json()) as Body;
  const access = await getAccess();
  const deviceId = access.deviceId;
  if (deviceId === "anonymous") {
    return NextResponse.json({ ok: false, error: "Enable cookies to unlock access." }, { status: 400 });
  }

  if (body.mode === "code") {
    const cfg = await getSettings();
    const entered = (body.code ?? "").replace(/\D/g, "").slice(0, 8);
    if (!cfg.dailyCodeActive) {
      return NextResponse.json({ ok: false, error: "The daily code is currently paused. Try a subscription." }, { status: 403 });
    }
    if (entered.length < 4) {
      return NextResponse.json({ ok: false, error: "Enter the full code." }, { status: 400 });
    }
    if (entered !== cfg.dailyCode.replace(/\D/g, "")) {
      await firebaseSet(`live/attempts/${Date.now()}`, { deviceId, ok: false });
      return NextResponse.json(
        {
          ok: false,
          error: cfg.dailyCode
            ? "That code is not valid. The code changes every day — get today's code from our channel or support."
            : "No day code is set right now. Please use a subscription or the free steps.",
        },
        { status: 401 },
      );
    }
    const expiresAt = new Date();
    expiresAt.setHours(23, 59, 59, 999);
    await db.insert(accessGrants).values({
      deviceId,
      kind: "daily_code",
      label: "Day Pass",
      expiresAt,
    });
    await firebaseSet(`live/grants/${deviceId}`, { kind: "daily_code", at: Date.now() });
    const next = await getAccess();
    return NextResponse.json({ ok: true, access: next, message: "Day pass active until midnight." });
  }

  if (body.mode === "steps") {
    const cfg = await getSettings();
    const proofs = (body.steps ?? []).map((s) => (s.proof ?? "").trim());
    const required = cfg.freeAccessSteps.length;
    if (proofs.filter((p) => p.length >= 2).length < Math.min(3, required)) {
      return NextResponse.json({ ok: false, error: "Complete all steps and fill every proof field." }, { status: 400 });
    }
    const chans = await db.select().from(channels).where(eq(channels.active, true));
    if (chans.length) {
      const existing = await db
        .select()
        .from(accessGrants)
        .where(and(eq(accessGrants.deviceId, deviceId), eq(accessGrants.kind, "free_steps"), gt(accessGrants.expiresAt, new Date())))
        .limit(1);
      if (existing[0]) return NextResponse.json({ ok: true, access: await getAccess(), message: "Already unlocked." });
    }
    await db.insert(accessGrants).values({
      deviceId,
      kind: "free_steps",
      label: "3-step free access",
      expiresAt: new Date(Date.now() + 30 * 3_600_000),
    });
    await firebaseSet(`live/grants/${deviceId}`, { kind: "free_steps", at: Date.now() });
    const next = await getAccess();
    return NextResponse.json({ ok: true, access: next, message: "Free access unlocked for 30 hours." });
  }

  return NextResponse.json({ ok: false, error: "Unknown mode" }, { status: 400 });
}
