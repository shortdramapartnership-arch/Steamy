"use client";

import Link from "next/link";
import { useCatalog } from "@/components/AppShell";
import { Badge, SectionTitle } from "@/components/ui";

export default function AppsPage() {
  const { settings, channels } = useCatalog();
  return (
    <div className="mx-auto max-w-[1000px] space-y-8 px-4 py-12 sm:px-6">
      <SectionTitle eyebrow="Everywhere you are" title="Get the apps & follow us" desc="Take your dramas everywhere — install the app or join the community for daily codes and new episode drops." />

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {(settings?.appLinks ?? []).map((l, i) => (
          <a
            key={l.label}
            href={l.url}
            target="_blank"
            rel="noreferrer"
            className="card card-hover anim-fade-up flex flex-col items-center gap-2 rounded-3xl p-6 text-center"
            style={{ animationDelay: `${i * 60}ms` }}
          >
            <span className="text-3xl">{l.icon || "🔗"}</span>
            <span className="text-[13px] font-bold text-white">{l.label}</span>
            <span className="text-[11px] text-white/35">Open ↗</span>
          </a>
        ))}
      </div>

      {channels.length ? (
        <div className="space-y-4">
          <h3 className="text-lg font-bold text-white">Our channels</h3>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {channels.map((c) => (
              <a key={c.id} href={c.url} target="_blank" rel="noreferrer" className="card card-hover rounded-3xl p-5">
                <Badge tone="brand">{c.platform}</Badge>
                <h4 className="mt-2 text-base font-bold text-white">{c.title}</h4>
                <p className="mt-1 line-clamp-3 text-[13px] text-white/45">{c.description}</p>
                <span className="mt-3 inline-block text-[12px] font-bold text-[var(--accent-soft)]">Subscribe ↗</span>
              </a>
            ))}
          </div>
        </div>
      ) : null}

      <div className="card rounded-3xl p-6 text-center">
        <h3 className="text-base font-bold text-white">How to watch free</h3>
        <p className="mx-auto mt-2 max-w-xl text-[13px] text-white/50">
          Complete the three steps on the unlock page — subscribe, like &amp; comment on the pinned trailer, and share with two friends —
          and the entire platform unlocks for you.
        </p>
        <Link href="/access" className="btn-brand mt-4 inline-flex rounded-full px-6 py-3 text-sm font-bold">
          Start the 3 steps →
        </Link>
      </div>
    </div>
  );
}
