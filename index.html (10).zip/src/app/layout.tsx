import type { Metadata, Viewport } from "next";
import "./globals.css";
import { AppShell } from "@/components/AppShell";

export const metadata: Metadata = {
  title: "Steamy — Micro Dramas, Dubbed In Your Language",
  description:
    "Stream the world's trending micro dramas, short dramas, Korean, Chinese and Turkish series with studio-grade AI dubbing and word-by-word captions.",
  applicationName: "Steamy",
  openGraph: {
    title: "Steamy — Micro Dramas, Dubbed In Your Language",
    description: "Trending micro dramas from around the world, dubbed into your language.",
    type: "website",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  themeColor: "#05050a",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen antialiased">
        <AppShell>{children}</AppShell>
      </body>
    </html>
  );
}
