"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState } from "react";
import type { SettingsData } from "@/db/schema";
import type { ApiVideo } from "@/lib/types";
import { DUB_LANGUAGES } from "@/lib/languages";
import { Badge, Field, Spinner, cx, formatViews, inputCls, useToast } from "@/components/ui";
import type { CountryDef, MethodDef } from "@/lib/countries";

type MethodRow = {
  id: number;
  countryCode: string;
  methodKey: string;
  label: string;
  icon: string;
  address: string;
  accountName: string;
  details?: { label: string; value: string }[];
  instructions: string;
  amount: string;
  currency: string;
  active: boolean;
};

type PaymentRow = {
  id: number;
  accountName?: string;
  accountEmail?: string;
  accountPicture?: string;
  accountProvider?: string;
  accountDeviceId?: string;
  countryCode: string;
  countryName: string;
  methodLabel: string;
  amount: string;
  currency: string;
  payerName: string;
  payerEmail: string;
  transactionId: string;
  proofImage: string;
  status: string;
  reviewNote: string;
  createdAt: string;
};

type ChannelRow = { id: number; title: string; url: string; description: string; active: boolean; stepOrder: number };

type PanelData = {
  settings: SettingsData;
  videos: ApiVideo[];
  channels: ChannelRow[];
  payments: PaymentRow[];
  methods: MethodRow[];
  fetchRuns: { id: number; added: number; found: number; createdAt: string; message: string }[];
  platformCounts: { platform: string; n: number }[];
  accounts: { id: number; provider: string; name: string; email: string; picture: string; lastDeviceId: string; createdAt: string; lastSeenAt: string }[];
  signups: { id: number; provider: string; name: string; email: string; picture: string; createdAt: string; lastSeenAt: string }[];
  activeGrants: number;
  dubTracks: number;
  countries: CountryDef[];
  methodCatalog: MethodDef[];
};

type Draft = {
  methodKey: string;
  instructions: string;
  amount: string;
  currency: string;
  active: boolean;
  /** One value per field defined for that rail in the catalogue. */
  values: string[];
};

const TABS = [
  { key: "overview", label: "Overview" },
  { key: "catalog", label: "Catalog" },
  { key: "branding", label: "Branding" },
  { key: "dubbing", label: "Dubbing" },
  { key: "payments", label: "Payments" },
  { key: "subs", label: "Verify payments" },
  { key: "channels", label: "Channels & apps" },
  { key: "access", label: "Codes & plan" },
] as const;

export default function DevPage() {
  const [tab, setTab] = useState<(typeof TABS)[number]["key"]>("overview");
  const [data, setData] = useState<PanelData | null>(null);
  const [busy, setBusy] = useState(false);
  const toast = useToast();

  const call = useCallback(
    async (action: string, payload: Record<string, unknown> = {}) => {
      setBusy(true);
      try {
        const res = await fetch("/api/dev", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action, payload }),
        });
        const json = (await res.json()) as { ok: boolean; data?: PanelData; error?: string; message?: string; result?: unknown };
        if (json.data) setData(json.data);
        if (!json.ok) toast.err(json.error ?? "Action failed");
        else if (json.message) toast.ok(json.message);
        return json;
      } finally {
        setBusy(false);
      }
    },
    [toast],
  );

  const reload = useCallback(async () => {
    const res = await fetch("/api/dev", { cache: "no-store" });
    if (res.ok) setData(await res.json());
  }, []);

  useEffect(() => {
    reload();
  }, [reload]);

  const s = data?.settings;

  return (
    <div className="min-h-screen bg-[#05050a]">
      {toast.node}
      <div className="mx-auto max-w-[1400px] space-y-6 px-4 py-8 sm:px-6">
        <header className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-[11px] font-bold uppercase tracking-[0.22em] text-[var(--accent-soft)]">Developer console</p>
            <h1 className="text-2xl font-black tracking-tight text-white">{s?.platformName ?? "Steamy"} control room</h1>
          </div>
          <div className="flex items-center gap-2">
            {busy ? <Spinner size={16} /> : null}
            <Link href="/" className="btn-ghost rounded-full px-4 py-2 text-[12px] font-bold text-white/70">
              ← Back to platform
            </Link>
          </div>
        </header>

        <nav className="no-scrollbar flex gap-2 overflow-x-auto pb-1">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={cx(
                "shrink-0 rounded-full border px-4 py-2 text-[12.5px] font-bold transition",
                tab === t.key ? "border-transparent bg-[var(--accent)] text-white" : "border-white/10 bg-white/5 text-white/55 hover:text-white",
              )}
            >
              {t.label}
            </button>
          ))}
        </nav>

        {!data || !s ? (
          <div className="flex justify-center py-20">
            <Spinner size={22} />
          </div>
        ) : (
          <>
            {tab === "overview" ? <Overview data={data} toast={toast} onRun={() => call("run_autofetch")} /> : null}
            {tab === "catalog" ? <Catalog data={data} call={call} /> : null}
            {tab === "branding" ? <Branding s={s} call={call} /> : null}
            {tab === "dubbing" ? <Dubbing s={s} call={call} tracks={data.dubTracks} toast={toast} /> : null}
            {tab === "payments" ? <Payments data={data} call={call} /> : null}
            {tab === "subs" ? <Subscriptions data={data} call={call} /> : null}
            {tab === "channels" ? <ChannelsApps s={s} data={data} call={call} /> : null}
            {tab === "access" ? <CodesPlan s={s} call={call} data={data} /> : null}
          </>
        )}
      </div>
    </div>
  );
}

/* -------------------------------- overview -------------------------------- */

function Overview({ data, onRun, toast }: { data: PanelData; onRun: () => void; toast: { ok: (m: string) => void; err: (m: string) => void } }) {
  const [copied, setCopied] = useState(false);
  const stats = [
    { k: data.videos.length, v: "Titles in catalog" },
    { k: data.dubTracks, v: "Dub tracks built" },
    { k: data.activeGrants, v: "Active access grants" },
    { k: data.payments.filter((p) => p.status === "pending").length, v: "Payments to verify" },
    { k: data.channels.length, v: "Channels added" },
    { k: data.methods.length, v: "Payment rails configured" },
  ];
  const last = data.fetchRuns[0];
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        {stats.map((s, i) => (
          <div key={s.v} className="card anim-fade-up rounded-2xl p-4" style={{ animationDelay: `${i * 40}ms` }}>
            <p className="text-2xl font-black text-white">{s.k}</p>
            <p className="text-[10.5px] uppercase tracking-wider text-white/40">{s.v}</p>
          </div>
        ))}
      </div>

      <div className="card space-y-3 rounded-3xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-white">New sign-ups</h3>
            <p className="text-[12px] text-white/45">Every account name and Gmail, sent to you the moment someone registers — match it against the payment receipt.</p>
          </div>
          <Badge tone="brand">{data.signups.length} recent</Badge>
        </div>
        {data.signups.length === 0 ? (
          <p className="py-4 text-center text-[13px] text-white/35">No sign-ups yet. When a viewer signs up with Google their name and Gmail appear here instantly.</p>
        ) : (
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {data.signups.map((account) => (
              <div key={account.id} className="flex items-center gap-3 rounded-2xl border border-white/10 bg-black/30 p-3">
                {account.picture ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={account.picture} alt="" className="h-10 w-10 rounded-full object-cover" />
                ) : (
                  <span className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-[var(--accent)] to-violet-600 text-[13px] font-bold">
                    {account.name.slice(0, 1).toUpperCase()}
                  </span>
                )}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13px] font-bold text-white">{account.name}</p>
                  <p className="truncate text-[11.5px] text-white/50">{account.email}</p>
                  <p className="text-[10px] text-white/30">
                    {account.provider === "google" ? "Google" : "Email"} · {new Date(account.createdAt).toLocaleString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="card space-y-3 rounded-3xl border-[var(--accent)]/30 p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-[var(--accent-soft)]">Today&apos;s day code</p>
            <div className="mt-1 flex items-center gap-3">
              <span className="font-mono text-4xl font-black tracking-[0.3em] text-white">
                {data.settings.dailyCode || "—"}
              </span>
              <Badge tone={data.settings.dailyCodeActive ? "brand" : "live"}>
                {data.settings.dailyCodeActive ? "active" : "paused"}
              </Badge>
            </div>
            <p className="mt-1 text-[12px] text-white/45">
              Viewers who enter this code get <strong className="text-white/70">everything for the rest of the day</strong>.
            </p>
          </div>
          <button
            onClick={() => {
              navigator.clipboard?.writeText(data.settings.dailyCode || "");
              setCopied(true);
              setTimeout(() => setCopied(false), 1800);
            }}
            className="btn-brand rounded-full px-6 py-3 text-[13px] font-bold"
          >
            {copied ? "Copied ✓" : "Copy code"}
          </button>
        </div>
      </div>

      <div className="card space-y-3 rounded-3xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-white">Automatic trending refresh</h3>
            <p className="text-[12px] text-white/45">
              {data.settings.autoFetchEnabled
                ? `Runs every hour · target ${data.settings.autoFetchLimit} dramas · last run ${
                    last ? `${new Date(last.createdAt).toLocaleString()} (+${last.added} added)` : "never"
                  }`
                : "Currently disabled"}
            </p>
          </div>
          <button onClick={onRun} className="btn-brand rounded-full px-5 py-2.5 text-[13px] font-bold">
            Fetch trending now
          </button>
        </div>
        <div className="flex flex-wrap gap-2">
          {data.fetchRuns.slice(0, 10).map((r) => (
            <span key={r.id} className="rounded-full bg-white/5 px-2.5 py-1 text-[11px] text-white/45">
              {new Date(r.createdAt).toLocaleDateString()} · +{r.added}/{r.found}
            </span>
          ))}
        </div>
      </div>

      <div className="card space-y-3 rounded-3xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-white">Firebase Realtime Database</h3>
            <p className="text-[12px] leading-relaxed text-white/45">
              Project <code className="text-white/70">steamy-26f21</code> · new accounts, comments, payments and grant events are mirrored to the
              Realtime Database so they reach you instantly. Postgres remains the source of truth, so the platform keeps working (and building)
              even if the RTDB rules deny access.
            </p>
          </div>
          <button
            onClick={async () => {
              const res = await fetch("/api/firebase/ping", { cache: "no-store" });
              const json = await res.json();
              toast.ok(json.ok ? "Firebase reachable ✓" : `Mirror not writable (${json.reason ?? "denied"}) — platform unaffected`);
            }}
            className="btn-ghost rounded-full px-4 py-2 text-[12px] font-bold"
          >
            Test connection
          </button>
        </div>
        <div className="flex flex-wrap gap-2">
          <Badge tone="gold">projectId steamy-26f21</Badge>
          <Badge>appId 1:89514758713:web:77748f9b172347c5a2b3e8</Badge>
          <Badge>RTDB steamy-26f21-default-rtdb</Badge>
          <Badge>measurementId G-7TMPXLTK4H</Badge>
        </div>
      </div>
    </div>
  );
}

/* --------------------------------- catalog -------------------------------- */

function Catalog({
  data,
  call,
}: {
  data: PanelData;
  call: (a: string, p?: Record<string, unknown>) => Promise<{ ok: boolean; results?: { dmId: string; title: string; thumbnail: string; duration: number; owner: string }[] }>;
}) {
  const [input, setInput] = useState("");
  const [title, setTitle] = useState("");
  const [max, setMax] = useState(6);
  const [results, setResults] = useState<{ dmId: string; title: string; thumbnail: string; duration: number; owner: string }[]>([]);
  const [queries, setQueries] = useState(data.settings.autoFetchQueries.join("\n"));
  const [limit, setLimit] = useState(data.settings.autoFetchLimit);

  useEffect(() => {
    setQueries(data.settings.autoFetchQueries.join("\n"));
    setLimit(data.settings.autoFetchLimit);
  }, [data.settings.autoFetchQueries, data.settings.autoFetchLimit]);

  return (
    <div className="space-y-5">
      <div className="card space-y-4 rounded-3xl p-5">
        <h3 className="text-base font-bold text-white">Auto search — trending dramas</h3>
        <div className="grid gap-3 sm:grid-cols-[1fr_auto_auto]">
          <Field label="Search queries (one per line)">
            <textarea value={queries} onChange={(e) => setQueries(e.target.value)} rows={7} className={cx(inputCls, "font-mono text-[12px]")} />
          </Field>
          <div className="space-y-3">
            <Field label="Minimum dramas to keep">
              <input type="number" min={30} max={300} value={limit} onChange={(e) => setLimit(Number(e.target.value))} className={cx(inputCls, "w-32")} />
            </Field>
            <button
              onClick={() => call("save_autofetch", { autoFetchQueries: queries.split("\n").map((q) => q.trim()).filter(Boolean), autoFetchLimit: limit, autoFetchEnabled: data.settings.autoFetchEnabled })}
              className="btn-ghost w-full rounded-full px-4 py-2.5 text-[12px] font-bold"
            >
              Save settings
            </button>
            <button
              onClick={() => call("save_autofetch", { autoFetchQueries: queries.split("\n").map((q) => q.trim()).filter(Boolean), autoFetchLimit: limit, autoFetchEnabled: !data.settings.autoFetchEnabled })}
              className="btn-ghost w-full rounded-full px-4 py-2.5 text-[12px] font-bold"
            >
              {data.settings.autoFetchEnabled ? "Pause hourly refresh" : "Enable hourly refresh"}
            </button>
            <button onClick={() => call("run_autofetch")} className="btn-brand w-full rounded-full px-4 py-2.5 text-[12px] font-bold">
              Run now
            </button>
          </div>
        </div>
        <p className="text-[11px] text-white/35">
          Queries sweep Dailymotion&apos;s trending feed, de-duplicate results, keep only drama-like titles and store up to {limit} dramas automatically.
        </p>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="card space-y-3 rounded-3xl p-5">
          <h3 className="text-base font-bold text-white">Add by Dailymotion link or ID</h3>
          <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="https://www.dailymotion.com/video/x7tgad0" className={inputCls} />
          <button onClick={() => input && call("add_video", { input }).then(() => setInput(""))} className="btn-brand rounded-full px-5 py-2.5 text-[13px] font-bold">
            Add to catalog
          </button>
        </div>

        <div className="card space-y-3 rounded-3xl p-5">
          <h3 className="text-base font-bold text-white">Add by title (auto search)</h3>
          <div className="flex gap-2">
            <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Married by Mistake" className={inputCls} />
            <button
              onClick={async () => {
                if (!title.trim()) return;
                const res = await call("search_dailymotion", { query: title, limit: 12 });
                setResults(res?.results ?? []);
              }}
              className="btn-ghost shrink-0 rounded-full px-4 py-2.5 text-[12px] font-bold"
            >
              Preview
            </button>
          </div>
          {results.length ? (
            <>
              <div className="max-h-52 space-y-2 overflow-y-auto">
                {results.map((r) => (
                  <div key={r.dmId} className="flex items-center gap-2 rounded-xl bg-white/5 p-2">
                    <span className="h-10 w-8 shrink-0 overflow-hidden rounded bg-black/40">
                      {r.thumbnail ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={r.thumbnail} alt="" className="h-full w-full object-cover" />
                      ) : null}
                    </span>
                    <span className="min-w-0 flex-1 truncate text-[12px] text-white/70">{r.title}</span>
                  </div>
                ))}
              </div>
              <button onClick={() => call("add_video_title", { title, max }).then(() => setResults([]))} className="btn-brand rounded-full px-5 py-2.5 text-[13px] font-bold">
                Add top {max} results
              </button>
            </>
          ) : null}
          <div className="flex items-center gap-2">
            <span className="text-[11px] uppercase tracking-wider text-white/40">Max</span>
            <input type="number" min={1} max={20} value={max} onChange={(e) => setMax(Number(e.target.value))} className={cx(inputCls, "w-20")} />
          </div>
        </div>
      </div>

      <div className="card space-y-3 rounded-3xl p-5">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-white">Catalog ({data.videos.length})</h3>
          <span className="text-[11px] text-white/35">Feature · hide · rebuild dub · delete</span>
        </div>
        <div className="max-h-[520px] overflow-y-auto">
          <table className="w-full text-left text-[12px]">
            <thead className="sticky top-0 bg-[#0c0c14] text-white/40">
              <tr>
                <th className="p-2">Title</th>
                <th className="p-2">Category</th>
                <th className="p-2">Views</th>
                <th className="p-2 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {data.videos.map((v) => (
                <tr key={v.id} className="border-t border-white/5">
                  <td className="max-w-[420px] p-2">
                    <div className="flex items-center gap-2">
                      <span className="h-8 w-6 shrink-0 overflow-hidden rounded bg-black/40">
                        {v.thumbnail ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img src={v.thumbnail} alt="" className="h-full w-full object-cover" />
                        ) : null}
                      </span>
                      <span className="truncate text-white/80">{v.title}</span>
                      {v.featured ? <span className="text-[10px] text-amber-300">★</span> : null}
                    </div>
                  </td>
                  <td className="p-2 text-white/50">{v.category}</td>
                  <td className="p-2 text-white/50">{formatViews(v.views)}</td>
                  <td className="p-2">
                    <div className="flex justify-end gap-1">
                      <button onClick={() => call("update_video", { id: v.id, featured: !v.featured })} className="btn-ghost rounded-lg px-2 py-1 text-[11px]">
                        {v.featured ? "★" : "☆"}
                      </button>
                      <button onClick={() => call("update_video", { id: v.id, hidden: !v.hidden })} className="btn-ghost rounded-lg px-2 py-1 text-[11px]">
                        {v.hidden ? "Show" : "Hide"}
                      </button>
                      <button
                        onClick={() => call("build_transcript", { videoId: v.id, seconds: 300 })}
                        className="btn-ghost rounded-lg px-2 py-1 text-[11px] font-bold"
                        title="Transcribe the real audio with Linly-Dubbing (faster-whisper)"
                      >
                        🎙 ASR
                      </button>
                      <button onClick={() => call("delete_video", { id: v.id })} className="rounded-lg bg-red-500/15 px-2 py-1 text-[11px] text-red-200">
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

/* -------------------------------- branding -------------------------------- */

function Branding({ s, call }: { s: SettingsData; call: (a: string, p?: Record<string, unknown>) => Promise<{ ok: boolean }> }) {
  const [form, setForm] = useState({
    platformName: s.platformName,
    logoUrl: s.logoUrl,
    tagline: s.tagline,
    heroHeadline: s.heroHeadline,
    heroSubline: s.heroSubline,
    accent: s.accent,
    categories: s.categories.join(", "),
  });

  const upload = (file: File) => {
    const fr = new FileReader();
    fr.onload = () => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const size = 256;
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext("2d");
        if (!ctx) return;
        const min = Math.min(img.width, img.height);
        ctx.drawImage(img, (img.width - min) / 2, (img.height - min) / 2, min, min, 0, 0, size, size);
        setForm((f) => ({ ...f, logoUrl: canvas.toDataURL("image/png") }));
      };
      img.src = String(fr.result);
    };
    fr.readAsDataURL(file);
  };

  return (
    <div className="card space-y-4 rounded-3xl p-5">
      <h3 className="text-base font-bold text-white">Platform identity</h3>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Platform name">
          <input value={form.platformName} onChange={(e) => setForm({ ...form, platformName: e.target.value })} className={inputCls} />
        </Field>
        <Field label="Accent colour">
          <div className="flex items-center gap-3">
            <input type="color" value={form.accent} onChange={(e) => setForm({ ...form, accent: e.target.value })} className="h-11 w-16 rounded-xl border border-white/10 bg-black/40" />
            <input value={form.accent} onChange={(e) => setForm({ ...form, accent: e.target.value })} className={inputCls} />
          </div>
        </Field>
        <Field label="Tagline">
          <input value={form.tagline} onChange={(e) => setForm({ ...form, tagline: e.target.value })} className={inputCls} />
        </Field>
        <Field label="Hero headline">
          <input value={form.heroHeadline} onChange={(e) => setForm({ ...form, heroHeadline: e.target.value })} className={inputCls} />
        </Field>
        <div className="sm:col-span-2">
          <Field label="Hero subline">
            <textarea value={form.heroSubline} onChange={(e) => setForm({ ...form, heroSubline: e.target.value })} rows={3} className={inputCls} />
          </Field>
        </div>
        <div className="sm:col-span-2">
          <Field label="Categories (comma separated)">
            <textarea value={form.categories} onChange={(e) => setForm({ ...form, categories: e.target.value })} rows={3} className={inputCls} />
          </Field>
        </div>
        <Field label="Logo upload" hint="Square PNG recommended · cropped to 256×256">
          <input
            type="file"
            accept="image/*"
            onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])}
            className="w-full rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-[12px] text-white/60 file:mr-3 file:rounded-lg file:border-0 file:bg-[var(--accent)] file:px-3 file:py-1.5 file:text-[11px] file:font-bold file:text-white"
          />
        </Field>
        <div className="flex items-center gap-3">
          {form.logoUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={form.logoUrl} alt="logo" className="h-14 w-14 rounded-2xl ring-1 ring-white/15" />
          ) : (
            <span className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-[var(--accent)] to-violet-600 text-xl font-black">S</span>
          )}
          {form.logoUrl ? (
            <button onClick={() => setForm({ ...form, logoUrl: "" })} className="btn-ghost rounded-full px-3 py-1.5 text-[11px] font-bold">
              Remove
            </button>
          ) : null}
        </div>
      </div>
      <button
        onClick={() =>
          call("save_branding", {
            ...form,
            categories: form.categories.split(",").map((c) => c.trim()).filter(Boolean),
          })
        }
        className="btn-brand rounded-full px-6 py-3 text-[13px] font-bold"
      >
        Save branding
      </button>
    </div>
  );
}

/* --------------------------------- dubbing -------------------------------- */

type EngineStatus = {
  engine?: string;
  engineLabel?: string;
  probe?: { edge_tts?: boolean; faster_whisper?: boolean; ffmpeg?: boolean; pyav?: boolean };
  asr?: { faster_whisper?: boolean; edge_tts?: boolean; ffmpeg?: boolean; pyav?: boolean };
  pipeline?: Record<string, string>;
  languages?: string[];
};

type Pipeline = { asr: string; translation: string; tts: string; vocalSeparation: string };

function Dubbing({ s, call, tracks, toast }: { s: SettingsData; call: (a: string, p?: Record<string, unknown>) => Promise<{ ok: boolean }>; tracks: number; toast: { ok: (m: string) => void; err: (m: string) => void } }) {
  const [engineStatus, setEngineStatus] = useState<EngineStatus | null>(null);
  const [pipeline, setPipeline] = useState<Pipeline | null>(null);
  useEffect(() => {
    fetch("/api/dub/render", { cache: "no-store" })
      .then((r) => r.json())
      .then((json: EngineStatus) => setEngineStatus(json))
      .catch(() => undefined);
  }, []);
  const [langs, setLangs] = useState<string[]>(s.dubLanguages);
  const [tts, setTts] = useState({ ttsProvider: s.ttsProvider, ttsApiKey: s.ttsApiKey, ttsModel: s.ttsModel, ttsVoice: s.ttsVoice });

  const toggle = (code: string) => setLangs((l) => (l.includes(code) ? l.filter((c) => c !== code) : [...l, code]));

  return (
    <div className="space-y-5">
      <div className="card space-y-4 rounded-3xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-white">Dubbing languages</h3>
            <p className="text-[12px] text-white/45">{langs.length} languages enabled · {tracks} dub tracks cached</p>
          </div>
          <button onClick={() => call("save_dub", { dubLanguages: langs, ...tts })} className="btn-brand rounded-full px-6 py-2.5 text-[13px] font-bold">
            Save languages
          </button>
        </div>
        <div className="flex flex-wrap gap-2">
          {DUB_LANGUAGES.map((l) => (
            <button
              key={l.code}
              onClick={() => toggle(l.code)}
              className={cx(
                "rounded-2xl border px-3.5 py-2 text-[12px] font-bold transition",
                langs.includes(l.code) ? "border-transparent bg-[var(--accent)] text-white" : "border-white/10 bg-white/5 text-white/55 hover:text-white",
              )}
            >
              {l.flag} {l.nativeLabel}
            </button>
          ))}
        </div>
      </div>

      <div className="card space-y-4 rounded-3xl p-5">
        <h3 className="text-base font-bold text-white">Voice engine</h3>
        <p className="text-[12px] leading-relaxed text-white/45">
          <strong>Browser neural voices</strong> (default) plays the dub with the on-device neural voices from the viewer&apos;s OS — instant,
          free and perfectly synced to the timeline. If you have a commercial TTS key, select a provider below and the Dub Studio will prefer it.
        </p>
        <div className="grid gap-4 sm:grid-cols-4">
          <Field label="Provider">
            <select value={tts.ttsProvider} onChange={(e) => setTts({ ...tts, ttsProvider: e.target.value as SettingsData["ttsProvider"] })} className={inputCls}>
              <option value="openai">OpenAI neural TTS (studio dub)</option>
              <option value="browser">Device neural voices (fallback)</option>
              <option value="elevenlabs">ElevenLabs</option>
            </select>
          </Field>
          <Field label="API key" hint="Server-side only. Falls back to the OPENAI_API_KEY env var.">
            <input value={tts.ttsApiKey} onChange={(e) => setTts({ ...tts, ttsApiKey: e.target.value })} placeholder="sk-… (env key in use)" className={inputCls} />
          </Field>
          <Field label="Model">
            <select value={tts.ttsModel} onChange={(e) => setTts({ ...tts, ttsModel: e.target.value })} className={inputCls}>
              {["gpt-4o-mini-tts", "gpt-4o-mini-tts-2025-12-15", "tts-1-hd", "tts-1"].map((m) => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </Field>
          <Field label="Voice">
            <select value={tts.ttsVoice} onChange={(e) => setTts({ ...tts, ttsVoice: e.target.value })} className={inputCls}>
              {["alloy", "ash", "ballad", "coral", "echo", "fable", "nova", "onyx", "sage", "shimmer"].map((v) => (
                <option key={v} value={v}>{v}</option>
              ))}
            </select>
          </Field>
        </div>
        <p className="text-[11px] text-white/35">
          Phrases are cached in Postgres after the first synthesis, so a drama only costs one pass per language. If the API is unavailable or out
          of credit, the player automatically falls back to on-device neural voices — dubbing never stops.
        </p>
        <button onClick={() => call("save_dub", { dubLanguages: langs, ...tts })} className="btn-brand rounded-full px-6 py-3 text-[13px] font-bold">
          Save voice engine
        </button>
      </div>

      <div className="card space-y-4 rounded-3xl border-[var(--accent)]/30 p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-white">Linly-Dubbing pipeline</h3>
            <p className="text-[12px] text-white/45">
              Built on{" "}
              <a href="https://github.com/Kedreamix/Linly-Dubbing" target="_blank" rel="noreferrer" className="text-[var(--accent-soft)] underline">
                Kedreamix/Linly-Dubbing
              </a>{" "}
              — captions and the dub are timed from the <strong className="text-white/70">real audio</strong> of each title.
            </p>
          </div>
          <button
            onClick={async () => {
              const res = await fetch("/api/dub/render", { cache: "no-store" });
              const json = await res.json();
              setPipeline(json.pipeline ?? null);
              setEngineStatus(json);
              toast.ok(json.pipeline ? "Pipeline checked" : "Checked");
            }}
            className="btn-brand rounded-full px-5 py-2.5 text-[13px] font-bold"
          >
            Check pipeline
          </button>
        </div>
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {(pipeline
            ? [
                { k: "ASR", v: pipeline.asr },
                { k: "Translation", v: pipeline.translation },
                { k: "TTS", v: pipeline.tts },
                { k: "Vocal separation", v: pipeline.vocalSeparation },
              ]
            : [
                { k: "ASR", v: engineStatus?.asr?.faster_whisper ? "faster-whisper ready" : "checking…" },
                { k: "TTS", v: engineStatus?.probe?.edge_tts ? "Edge neural voices" : "checking…" },
                { k: "ffmpeg", v: engineStatus?.asr?.ffmpeg ? "available" : "checking…" },
                { k: "PyAV", v: engineStatus?.asr?.pyav ? "available" : "checking…" },
              ]
          ).map((row) => (
            <div key={row.k} className="rounded-2xl border border-white/10 bg-black/30 p-3">
              <p className="text-[10.5px] font-bold uppercase tracking-widest text-white/35">{row.k}</p>
              <p className="text-[12.5px] font-semibold text-white/80">{row.v}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="card space-y-3 rounded-3xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-white">Dubbing engine status</h3>
            <p className="text-[12px] text-white/45">
              Runs <code className="text-white/70">worker/linly_dub.py</code> — built on{" "}
              <a href="https://github.com/Kedreamix/Linly-Dubbing" target="_blank" rel="noreferrer" className="text-[var(--accent-soft)] underline">
                Kedreamix/Linly-Dubbing
              </a>
              . faster-whisper transcribes the real audio, Edge neural voices speak the dub.
            </p>
          </div>
          <button
            onClick={async () => {
              const res = await fetch("/api/dub/render", { cache: "no-store" });
              const json = await res.json();
              setEngineStatus(json);
              toast.ok(json.engineLabel ? `Engine: ${json.engineLabel}` : "Engine checked");
            }}
            className="btn-brand rounded-full px-5 py-2.5 text-[13px] font-bold"
          >
            Check engine
          </button>
        </div>
        {engineStatus ? (
          <div className="grid gap-2 sm:grid-cols-4">
            {[
              { k: "Engine", v: engineStatus.engineLabel ?? engineStatus.engine },
              { k: "Edge TTS (free)", v: engineStatus.probe?.edge_tts ? "available" : "missing" },
              { k: "faster-whisper", v: engineStatus.asr?.faster_whisper ? "ready" : "not installed" },
              { k: "Languages", v: `${engineStatus.languages?.length ?? 0} neural voices` },
            ].map((row) => (
              <div key={row.k} className="rounded-2xl border border-white/10 bg-black/30 p-3">
                <p className="text-[10.5px] font-bold uppercase tracking-widest text-white/35">{row.k}</p>
                <p className="text-[13px] font-semibold text-white/80">{row.v}</p>
              </div>
            ))}
          </div>
        ) : null}
      </div>

      <div className="card space-y-2 rounded-3xl p-5">
        <h3 className="text-base font-bold text-white">How the dub track is built</h3>
        <ol className="space-y-1.5 text-[13px] text-white/50">
          <li>1 · If the Dailymotion video ships a subtitle track, it is used as the timed script (studio-accurate).</li>
          <li>2 · Otherwise a timed dialogue script is generated scene-by-scene, unique per title, and cached.</li>
          <li>3 · Every line is machine-translated into the viewer&apos;s chosen language and cached in Postgres.</li>
          <li>4 · The player ducks the original audio, assigns a voice per character and speaks each line inside its time window.</li>
          <li>5 · Captions highlight every word in sync with the dub, with dual-language caption support.</li>
        </ol>
      </div>
    </div>
  );
}

/* -------------------------------- payments -------------------------------- */

function Payments({ data, call }: { data: PanelData; call: (a: string, p?: Record<string, unknown>) => Promise<{ ok: boolean }> }) {
  const [countryCode, setCountryCode] = useState(data.methods[0]?.countryCode ?? "PK");
  const country = data.countries.find((c) => c.code === countryCode);
  const existing = useMemo(() => data.methods.filter((m) => m.countryCode === countryCode), [data.methods, countryCode]);
  const [drafts, setDrafts] = useState<Draft[]>([]);

  useEffect(() => {
    setDrafts(
      existing.map((m) => {
        const def = data.methodCatalog.find((c) => c.key === m.methodKey);
        const labels = def?.fields ?? [];
        const values = labels.map((label, i) => m.details?.find((d) => d.label === label)?.value ?? m.details?.[i]?.value ?? "");
        return {
          methodKey: m.methodKey,
          instructions: m.instructions,
          amount: m.amount,
          currency: m.currency,
          active: m.active,
          values,
        };
      }),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [existing]);

  const suggested = useMemo(() => {
    const keys = country?.methods ?? [];
    const extra = data.methodCatalog.filter((m) => m.group === "crypto").map((m) => m.key);
    return [...new Set([...keys, ...extra])].filter((k) => !drafts.some((d) => d.methodKey === k));
  }, [country, data.methodCatalog, drafts]);

  const add = (key: string) => {
    const def = data.methodCatalog.find((m) => m.key === key);
    if (!def) return;
    setDrafts((d) => [
      ...d,
      {
        methodKey: key,
        instructions: "",
        amount: "",
        currency: country?.currency ?? "USD",
        active: true,
        values: def.fields.map(() => ""),
      },
    ]);
  };

  const patch = (i: number, next: Partial<Draft>) => setDrafts((d) => d.map((x, idx) => (idx === i ? { ...x, ...next } : x)));
  const patchValue = (i: number, fieldIndex: number, value: string) =>
    setDrafts((d) => d.map((x, idx) => (idx === i ? { ...x, values: x.values.map((v, vi) => (vi === fieldIndex ? value : v)) } : x)));

  return (
    <div className="space-y-5">
      <div className="card space-y-3 rounded-3xl p-5">
        <h3 className="text-base font-bold text-white">Country → payment methods</h3>
        <p className="text-[12px] text-white/45">Pick a country, enable the rails available there, and set the local price. Viewers only ever see their own country&apos;s methods.</p>
        <div className="grid gap-2 sm:grid-cols-4">
          {data.countries.map((c) => (
            <button
              key={c.code}
              onClick={() => setCountryCode(c.code)}
              className={cx(
                "flex items-center gap-2 rounded-xl border px-3 py-2 text-left text-[12px] font-semibold transition",
                countryCode === c.code ? "border-transparent bg-[var(--accent)] text-white" : "border-white/10 bg-white/5 text-white/60 hover:text-white",
              )}
            >
              <span>{c.flag}</span>
              <span className="truncate">{c.name}</span>
              <span className="ml-auto text-[10px] opacity-60">{c.currency}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="card space-y-4 rounded-3xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h3 className="text-base font-bold text-white">{country?.flag} {country?.name} · {drafts.length} methods</h3>
          <button
            onClick={() =>
              call("save_methods", {
                countryCode,
                defaultAmount: data.settings.monthlyPrice,
                methods: drafts.map((d) => ({
                  methodKey: d.methodKey,
                  label: data.methodCatalog.find((c) => c.key === d.methodKey)?.label ?? d.methodKey,
                  instructions: d.instructions,
                  amount: d.amount,
                  currency: d.currency,
                  active: d.active,
                  details: (data.methodCatalog.find((c) => c.key === d.methodKey)?.fields ?? ["Account / address"]).map(
                    (label, fi) => ({ label, value: d.values?.[fi] ?? "" }),
                  ),
                })),
              })
            }
            className="btn-brand rounded-full px-6 py-2.5 text-[13px] font-bold"
          >
            Save {country?.name} methods
          </button>
        </div>

        <div className="space-y-3">
          {drafts.map((d, i) => {
            const def = data.methodCatalog.find((m) => m.key === d.methodKey);
            return (
              <div key={d.methodKey} className="space-y-3 rounded-2xl border border-white/10 bg-black/30 p-4">
                <div className="flex items-center justify-between gap-3">
                  <p className="flex items-center gap-2 text-[13px] font-bold text-white">
                    <span className="text-base">{def?.icon}</span> {def?.label ?? d.methodKey}
                    <Badge tone={d.active ? "brand" : "default"}>{d.active ? "active" : "off"}</Badge>
                  </p>
                  <div className="flex gap-2">
                    <button onClick={() => patch(i, { active: !d.active })} className="btn-ghost rounded-full px-3 py-1.5 text-[11px] font-bold">
                      {d.active ? "Disable" : "Enable"}
                    </button>
                    <button onClick={() => setDrafts((x) => x.filter((_, idx) => idx !== i))} className="rounded-full bg-red-500/15 px-3 py-1.5 text-[11px] font-bold text-red-200">
                      Remove
                    </button>
                  </div>
                </div>
                <p className="text-[11px] font-bold uppercase tracking-widest text-white/35">Where the viewer pays</p>
                <div className="grid gap-3 sm:grid-cols-3">
                  {(def?.fields ?? ["Account / address"]).map((fieldName, fi) => (
                    <Field key={`${d.methodKey}-${fi}`} label={fieldName}>
                      <input
                        value={d.values?.[fi] ?? ""}
                        onChange={(e) => patchValue(i, fi, e.target.value)}
                        placeholder={fi === 0 ? "e.g. 0300-1234567" : ""}
                        className={inputCls}
                      />
                    </Field>
                  ))}
                </div>
                <div className="grid gap-3 sm:grid-cols-3">
                  <Field label="Price / month">
                    <input value={d.amount} onChange={(e) => patch(i, { amount: e.target.value })} placeholder={String(data.settings.monthlyPrice)} className={inputCls} />
                  </Field>
                  <Field label="Currency">
                    <input value={d.currency} onChange={(e) => patch(i, { currency: e.target.value.toUpperCase() })} placeholder={country?.currency} className={inputCls} />
                  </Field>
                  <Field label="Amount" hint="Shown on the pay screen">
                    <input
                      readOnly
                      value={`${d.currency || country?.currency || "USD"} ${d.amount || data.settings.monthlyPrice} / month`}
                      className={cx(inputCls, "cursor-default text-white/60")}
                    />
                  </Field>
                </div>
                <Field label="Payment instructions shown to the viewer">
                  <textarea value={d.instructions} onChange={(e) => patch(i, { instructions: e.target.value })} rows={2} className={inputCls} />
                </Field>
              </div>
            );
          })}
        </div>

        {suggested.length ? (
          <div className="space-y-2">
            <p className="text-[11px] font-bold uppercase tracking-widest text-white/40">Add a rail available in {country?.name}</p>
            <div className="flex flex-wrap gap-2">
              {suggested.map((k) => {
                const def = data.methodCatalog.find((m) => m.key === k);
                if (!def) return null;
                return (
                  <button key={k} onClick={() => add(k)} className="btn-ghost rounded-full px-3 py-1.5 text-[11.5px] font-bold text-white/70">
                    + {def.icon} {def.label}
                  </button>
                );
              })}
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}

/* ------------------------------ subscriptions ----------------------------- */

function Subscriptions({ data, call }: { data: PanelData; call: (a: string, p?: Record<string, unknown>) => Promise<{ ok: boolean }> }) {
  const [open, setOpen] = useState<number | null>(null);
  const [note, setNote] = useState("");
  const [filter, setFilter] = useState("all");
  const list = data.payments.filter((p) => filter === "all" || p.status === filter);

  return (
    <div className="card space-y-4 rounded-3xl p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h3 className="text-base font-bold text-white">Payment verification</h3>
        <div className="flex gap-2">
          {["all", "pending", "approved", "rejected"].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cx("rounded-full px-3 py-1.5 text-[11px] font-bold uppercase", filter === f ? "bg-[var(--accent)] text-white" : "bg-white/5 text-white/50")}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {list.length === 0 ? (
        <p className="py-8 text-center text-sm text-white/35">No payments yet.</p>
      ) : (
        <div className="space-y-3">
          {list.map((p) => (
            <div key={p.id} className="rounded-2xl border border-white/10 bg-black/30 p-4">
              {p.accountEmail || p.accountName ? (
                <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-[var(--accent)]/8 p-3">
                  {p.accountPicture ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={p.accountPicture} alt="" className="h-11 w-11 rounded-full object-cover ring-2 ring-[var(--accent)]/40" />
                  ) : (
                    <span className="grid h-11 w-11 place-items-center rounded-full bg-gradient-to-br from-[var(--accent)] to-violet-600 text-sm font-bold">
                      {(p.accountName || p.accountEmail || "?").slice(0, 1).toUpperCase()}
                    </span>
                  )}
                  <div className="min-w-0 flex-1">
                    <p className="text-[10.5px] font-bold uppercase tracking-widest text-[var(--accent-soft)]">
                      Verified Google account
                    </p>
                    <p className="truncate text-[14px] font-bold text-white">{p.accountName || "—"}</p>
                    <p className="truncate text-[12px] text-white/55">{p.accountEmail}</p>
                  </div>
                  <div className="hidden shrink-0 text-right sm:block">
                    <Badge tone={p.accountProvider === "google" ? "brand" : "default"}>{p.accountProvider === "google" ? "Google" : "Email"}</Badge>
                    <p className="mt-1 text-[10px] text-white/35">joined {new Date(p.createdAt).toLocaleDateString()}</p>
                  </div>
                </div>
              ) : (
                <div className="rounded-2xl border border-amber-400/25 bg-amber-500/10 px-3 py-2.5 text-[12px] text-amber-100/80">
                  ⚠ No account attached — this viewer paid without signing in. Confirm the receipt details carefully.
                </div>
              )}

              <div className="grid gap-3 sm:grid-cols-[1fr_auto]">
                <div className="space-y-1.5">
                  <p className="flex flex-wrap items-center gap-2">
                    <span className="text-[13px] font-bold text-white">#{p.id} · {p.payerName}</span>
                    <Badge tone={p.status === "approved" ? "brand" : p.status === "rejected" ? "live" : "gold"}>{p.status}</Badge>
                  </p>
                  <p className="text-[12px] text-white/50">
                    {p.countryName} · {p.methodLabel} · <strong className="text-white/80">{p.amount} {p.currency}</strong>
                  </p>
                  <p className="text-[12px] text-white/40">
                    Txn: {p.transactionId || "—"} {p.payerEmail ? `· ${p.payerEmail}` : ""} · {new Date(p.createdAt).toLocaleString()}
                  </p>
                  <div className="flex flex-wrap gap-2 pt-1">
                    <button onClick={() => setOpen(open === p.id ? null : p.id)} className="btn-ghost rounded-full px-3 py-1.5 text-[11px] font-bold">
                      {open === p.id ? "Hide proof" : "View proof"}
                    </button>
                    {p.status !== "approved" ? (
                      <button
                        onClick={() => call("review_payment", { id: p.id, status: "approved", note })}
                        className="rounded-full bg-emerald-500/20 px-3 py-1.5 text-[11px] font-bold text-emerald-100"
                      >
                        ✓ Approve · 30 days
                      </button>
                    ) : null}
                    {p.status !== "rejected" ? (
                      <button
                        onClick={() => call("review_payment", { id: p.id, status: "rejected", note })}
                        className="rounded-full bg-red-500/20 px-3 py-1.5 text-[11px] font-bold text-red-100"
                      >
                        ✕ Reject
                      </button>
                    ) : null}
                  </div>
                </div>
                <div className="h-24 w-32 overflow-hidden rounded-xl border border-white/10 bg-black/50">
                  {p.proofImage ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={p.proofImage} alt="proof" className="h-full w-full object-cover" />
                  ) : null}
                </div>
              </div>
              {open === p.id ? (
                <div className="anim-fade-in mt-3 space-y-2">
                  {p.proofImage ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={p.proofImage} alt="payment proof" className="max-h-[420px] w-full rounded-2xl object-contain bg-black/60" />
                  ) : (
                    <p className="text-[12px] text-white/40">No proof image attached.</p>
                  )}
                  <input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Optional note to the viewer" className={inputCls} />
                </div>
              ) : null}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ------------------------------ channels & apps --------------------------- */

function ChannelsApps({
  s,
  data,
  call,
}: {
  s: SettingsData;
  data: PanelData;
  call: (a: string, p?: Record<string, unknown>) => Promise<{ ok: boolean }>;
}) {
  const [ch, setCh] = useState({ title: "", url: "", handle: "", description: "", stepOrder: data.channels.length + 1 });
  const [apps, setApps] = useState(s.appLinks);

  return (
    <div className="space-y-5">
      <div className="card space-y-4 rounded-3xl p-5">
        <div>
          <h3 className="text-base font-bold text-white">YouTube channel & free-access steps</h3>
          <p className="text-[12px] text-white/45">Add the channel viewers must subscribe to. Channels are shown in order as the unlock steps.</p>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Channel title">
            <input value={ch.title} onChange={(e) => setCh({ ...ch, title: e.target.value })} className={inputCls} />
          </Field>
          <Field label="Channel URL">
            <input value={ch.url} onChange={(e) => setCh({ ...ch, url: e.target.value })} placeholder="https://youtube.com/@channel" className={inputCls} />
          </Field>
          <Field label="Handle">
            <input value={ch.handle} onChange={(e) => setCh({ ...ch, handle: e.target.value })} placeholder="@channel" className={inputCls} />
          </Field>
          <Field label="Step order">
            <input type="number" value={ch.stepOrder} onChange={(e) => setCh({ ...ch, stepOrder: Number(e.target.value) })} className={inputCls} />
          </Field>
          <div className="sm:col-span-2">
            <Field label="What the viewer must do">
              <textarea value={ch.description} onChange={(e) => setCh({ ...ch, description: e.target.value })} rows={2} className={inputCls} />
            </Field>
          </div>
        </div>
        <button onClick={() => ch.url && call("add_channel", ch).then(() => setCh({ title: "", url: "", handle: "", description: "", stepOrder: data.channels.length + 2 }))} className="btn-brand rounded-full px-6 py-2.5 text-[13px] font-bold">
          Add channel
        </button>

        <div className="space-y-2">
          {data.channels.map((c) => (
            <div key={c.id} className="flex items-center gap-3 rounded-2xl border border-white/10 bg-black/30 p-3">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-red-500/20 text-sm">▶</span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-[13px] font-bold text-white">{c.title}</p>
                <p className="truncate text-[11px] text-white/40">{c.url}</p>
              </div>
              <button onClick={() => call("update_channel", { id: c.id, active: !c.active })} className="btn-ghost rounded-full px-3 py-1.5 text-[11px] font-bold">
                {c.active ? "Hide" : "Show"}
              </button>
              <button onClick={() => call("delete_channel", { id: c.id })} className="rounded-full bg-red-500/15 px-3 py-1.5 text-[11px] font-bold text-red-200">
                Delete
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="card space-y-4 rounded-3xl p-5">
        <h3 className="text-base font-bold text-white">App links</h3>
        <div className="space-y-2">
          {apps.map((a, i) => (
            <div key={i} className="grid gap-2 sm:grid-cols-[70px_1fr_1fr_auto]">
              <input value={a.icon} onChange={(e) => setApps(apps.map((x, idx) => (idx === i ? { ...x, icon: e.target.value } : x)))} placeholder="🤖" className={cx(inputCls, "text-center")} />
              <input value={a.label} onChange={(e) => setApps(apps.map((x, idx) => (idx === i ? { ...x, label: e.target.value } : x)))} placeholder="Label" className={inputCls} />
              <input value={a.url} onChange={(e) => setApps(apps.map((x, idx) => (idx === i ? { ...x, url: e.target.value } : x)))} placeholder="https://…" className={inputCls} />
              <button onClick={() => setApps(apps.filter((_, idx) => idx !== i))} className="rounded-full bg-red-500/15 px-3 py-2 text-[11px] font-bold text-red-200">
                Remove
              </button>
            </div>
          ))}
        </div>
        <div className="flex gap-2">
          <button onClick={() => setApps([...apps, { label: "", url: "", icon: "🔗" }])} className="btn-ghost rounded-full px-4 py-2 text-[12px] font-bold">
            + Add link
          </button>
          <button onClick={() => call("save_apps", { appLinks: apps })} className="btn-brand rounded-full px-6 py-2 text-[12px] font-bold">
            Save links
          </button>
        </div>
      </div>
    </div>
  );
}

/* -------------------------------- codes & plan ---------------------------- */

function CodesPlan({ s, data, call }: { s: SettingsData; data: PanelData; call: (a: string, p?: Record<string, unknown>) => Promise<{ ok: boolean }> }) {
  const [code, setCode] = useState(s.dailyCode);
  const [codeOn, setCodeOn] = useState(s.dailyCodeActive);
  const [plan, setPlan] = useState({ monthlyPrice: String(s.monthlyPrice), monthlyCurrency: s.monthlyCurrency, freePreviewSeconds: String(s.freePreviewSeconds) });
  const [steps, setSteps] = useState(s.freeAccessSteps);
  const [grant, setGrant] = useState({ deviceId: "", days: 30 });

  return (
    <div className="space-y-5">
      <div className="card space-y-4 rounded-3xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h3 className="text-base font-bold text-white">Daily 4-digit code</h3>
          <p className="font-mono text-2xl font-black tracking-[0.3em] text-[var(--accent-soft)]">{s.dailyCode || "—"}</p>
        </div>
        <div className="flex flex-wrap items-end gap-3">
          <Field label="Code">
            <input
              value={code}
              onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 4))}
              className={cx(inputCls, "w-32 text-center text-xl font-black tracking-[0.4em]")}
            />
          </Field>
          <button onClick={() => setCodeOn((v) => !v)} className="btn-ghost rounded-full px-4 py-2.5 text-[12px] font-bold">
            {codeOn ? "Active ✓" : "Paused"}
          </button>
          <button onClick={() => call("save_code", { dailyCode: code, dailyCodeActive: codeOn })} className="btn-brand rounded-full px-6 py-2.5 text-[13px] font-bold">
            Save code
          </button>
        </div>
        <p className="text-[12px] text-white/45">Viewers who enter this code get everything until midnight. Change it every day.</p>
      </div>

      <div className="card space-y-4 rounded-3xl p-5">
        <h3 className="text-base font-bold text-white">Subscription plan & free preview</h3>
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="Monthly price (default, USD)">
            <input value={plan.monthlyPrice} onChange={(e) => setPlan({ ...plan, monthlyPrice: e.target.value })} className={inputCls} />
          </Field>
          <Field label="Currency">
            <input value={plan.monthlyCurrency} onChange={(e) => setPlan({ ...plan, monthlyCurrency: e.target.value.toUpperCase() })} className={inputCls} />
          </Field>
          <Field label="Free preview seconds">
            <input value={plan.freePreviewSeconds} onChange={(e) => setPlan({ ...plan, freePreviewSeconds: e.target.value })} className={inputCls} />
          </Field>
        </div>
        <button onClick={() => call("save_plan", { monthlyPrice: Number(plan.monthlyPrice), monthlyCurrency: plan.monthlyCurrency, freePreviewSeconds: Number(plan.freePreviewSeconds) })} className="btn-brand rounded-full px-6 py-2.5 text-[13px] font-bold">
          Save plan
        </button>
      </div>

      <div className="card space-y-4 rounded-3xl p-5">
        <h3 className="text-base font-bold text-white">3 free-access steps</h3>
        <div className="space-y-3">
          {steps.map((st, i) => (
            <div key={i} className="space-y-3 rounded-2xl border border-white/10 bg-black/30 p-4">
              <div className="grid gap-3 sm:grid-cols-2">
                <Field label="Step title">
                  <input value={st.title} onChange={(e) => setSteps(steps.map((x, idx) => (idx === i ? { ...x, title: e.target.value } : x)))} className={inputCls} />
                </Field>
                <Field label="Button label">
                  <input value={st.ctaLabel} onChange={(e) => setSteps(steps.map((x, idx) => (idx === i ? { ...x, ctaLabel: e.target.value } : x)))} className={inputCls} />
                </Field>
                <Field label="Button URL">
                  <input value={st.ctaUrl} onChange={(e) => setSteps(steps.map((x, idx) => (idx === i ? { ...x, ctaUrl: e.target.value } : x)))} className={inputCls} />
                </Field>
                <Field label="Proof field label">
                  <input value={st.proofLabel} onChange={(e) => setSteps(steps.map((x, idx) => (idx === i ? { ...x, proofLabel: e.target.value } : x)))} className={inputCls} />
                </Field>
              </div>
              <Field label="Instructions">
                <textarea value={st.body} onChange={(e) => setSteps(steps.map((x, idx) => (idx === i ? { ...x, body: e.target.value } : x)))} rows={2} className={inputCls} />
              </Field>
            </div>
          ))}
        </div>
        <div className="flex gap-2">
          <button onClick={() => setSteps([...steps, { title: "", body: "", ctaLabel: "", ctaUrl: "", proofLabel: "" }])} className="btn-ghost rounded-full px-4 py-2 text-[12px] font-bold">
            + Add step
          </button>
          <button onClick={() => call("save_steps", { freeAccessSteps: steps })} className="btn-brand rounded-full px-6 py-2 text-[12px] font-bold">
            Save steps
          </button>
        </div>
      </div>

      <div className="card space-y-4 rounded-3xl p-5">
        <h3 className="text-base font-bold text-white">Manual grant</h3>
        <p className="text-[12px] text-white/45">Grant premium to a device id (shown on the viewer&apos;s device cookie). {data.activeGrants} grants currently active.</p>
        <div className="grid gap-3 sm:grid-cols-[1fr_120px_auto]">
          <input value={grant.deviceId} onChange={(e) => setGrant({ ...grant, deviceId: e.target.value })} placeholder="device uuid" className={inputCls} />
          <input type="number" value={grant.days} onChange={(e) => setGrant({ ...grant, days: Number(e.target.value) })} className={inputCls} />
          <button onClick={() => call("grant_manual", grant)} className="btn-brand rounded-full px-5 py-2.5 text-[12px] font-bold">
            Grant
          </button>
        </div>
      </div>
    </div>
  );
}
