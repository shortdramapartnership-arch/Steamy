"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useCatalog } from "@/components/AppShell";
import { DUB_LANGUAGES, languageByCode } from "@/lib/languages";
import { PLATFORMS } from "@/lib/platforms";
import { Badge, PosterCard, Rail, SectionTitle, Spinner, cx, formatDuration, formatViews } from "@/components/ui";

export default function HomePage() {
  const { videos, settings, channels, loading, access } = useCatalog();
  const [category, setCategory] = useState("All");

  useEffect(() => {
    const c = new URLSearchParams(window.location.search).get("c");
    if (c) setCategory(c);
  }, []);

  const hero = useMemo(() => videos.find((v) => v.thumbnail) ?? videos[0], [videos]);
  const filtered = useMemo(
    () => (category === "All" ? videos : videos.filter((v) => v.category === category)),
    [videos, category],
  );

  const groups = useMemo(() => {
    const map = new Map<string, typeof videos>();
    for (const v of filtered) {
      const list = map.get(v.category) ?? [];
      list.push(v);
      map.set(v.category, list);
    }
    return [...map.entries()].sort((a, b) => b[1].length - a[1].length);
  }, [filtered]);

  /** One rail per short-drama platform: ReelShort, DramaBox, FlexTV, … */
  const platformRails = useMemo(
    () =>
      PLATFORMS.map((platform) => ({
        platform,
        list: videos.filter((v) => (v as unknown as { platform?: string }).platform === platform.key),
      }))
        .filter((row) => row.list.length > 0)
        .sort((a, b) => b.list.length - a.list.length),
    [videos],
  );
  const platformCounts = useMemo(() => {
    const map = new Map<string, number>();
    videos.forEach((v) => {
      const key = (v as unknown as { platform?: string }).platform ?? "other";
      map.set(key, (map.get(key) ?? 0) + 1);
    });
    return map;
  }, [videos]);

  const trending = useMemo(() => [...filtered].sort((a, b) => b.trendingScore - a.trendingScore), [filtered]);
  const newest = useMemo(() => [...filtered].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()), [filtered]);
  const langCount = settings?.dubLanguages.length ?? 0;
  const premium = access?.level === "day" || access?.level === "month";

  return (
    <div className="mx-auto max-w-[1500px] px-4 sm:px-6">
      {/* ---------------------------------- hero --------------------------------- */}
      <section className="relative -mt-16 overflow-hidden">
        <div className="absolute inset-0">
          {hero?.thumbnail ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={hero.thumbnail} alt="" className="anim-slow-zoom h-full w-full object-cover opacity-35" />
          ) : null}
          <div className="absolute inset-0 bg-gradient-to-t from-[#05050a] via-[#05050a]/85 to-[#05050a]/60" />
        </div>

        <div className="relative flex min-h-[78vh] flex-col justify-center gap-6 py-16">
          <div className="anim-fade-up max-w-2xl space-y-5">
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone="brand">● {settings?.platformName ?? "Steamy"} ORIGINALS</Badge>
              <Badge tone="gold">🤖 AI Dub Studio</Badge>
              <Badge>Hourly auto-refresh</Badge>
            </div>
            <h1 className="text-4xl font-black leading-[1.05] tracking-tight text-white sm:text-6xl">
              {settings?.heroHeadline ?? "Micro dramas. Dubbed in your language."}
            </h1>
            <p className="max-w-xl text-[15px] leading-relaxed text-white/55">{settings?.heroSubline}</p>

            <div className="flex flex-wrap items-center gap-3 pt-1">
              {hero ? (
                <Link href={`/watch/${hero.id}`} className="btn-brand flex items-center gap-2 rounded-full px-6 py-3 text-sm font-bold text-white">
                  ▶ Watch now
                </Link>
              ) : null}
              <Link href="/subscribe" className="btn-ghost rounded-full px-6 py-3 text-sm font-bold text-white">
                {premium ? "Manage plan" : `Premium · $${settings?.monthlyPrice ?? "4.99"}/mo`}
              </Link>
              {!premium ? (
                <Link href="/access" className="text-sm font-semibold text-[var(--accent-soft)] underline-offset-4 hover:underline">
                  Have a day code?
                </Link>
              ) : null}
            </div>

            <div className="flex flex-wrap items-center gap-2 pt-2">
              <span className="text-[11px] font-bold uppercase tracking-widest text-white/35">Dubbed in</span>
              {(settings?.dubLanguages ?? []).slice(0, 8).map((code) => {
                const l = languageByCode(code);
                return (
                  <span key={code} className="rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-[11px] font-medium text-white/70">
                    {l?.flag} {l?.nativeLabel ?? code}
                  </span>
                );
              })}
              {langCount > 8 ? <span className="text-[11px] text-white/40">+{langCount - 8} more</span> : null}
            </div>
          </div>
        </div>
      </section>

      {/* --------------------------------- trust -------------------------------- */}
      <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { k: `${videos.length}+`, v: "Dramas & movies" },
          { k: `${platformCounts.size}`, v: "Platforms tracked" },
          { k: `${langCount} langs`, v: "AI dubbing + captions" },
          { k: "190+", v: "Countries supported" },
          { k: "Hourly", v: "Trending auto-refresh" },
        ].map((s, i) => (
          <div key={s.v} className="card anim-fade-up rounded-2xl p-4" style={{ animationDelay: `${i * 60}ms` }}>
            <p className="text-xl font-black text-white">{s.k}</p>
            <p className="text-[11px] uppercase tracking-wider text-white/40">{s.v}</p>
          </div>
        ))}
      </section>

      {/* ------------------------------- categories ----------------------------- */}
      <section className="mt-10 space-y-5">
        <div className="no-scrollbar flex items-center gap-2 overflow-x-auto pb-1">
          {["All", ...(settings?.categories ?? [])].map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              className={cx(
                "shrink-0 rounded-full border px-4 py-1.5 text-[12px] font-semibold transition",
                category === c
                  ? "border-transparent bg-[var(--accent)] text-white shadow-lg"
                  : "border-white/10 bg-white/5 text-white/55 hover:border-white/25 hover:text-white",
              )}
            >
              {c}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-6">
            {Array.from({ length: 12 }).map((_, i) => (
              <div key={i} className="skeleton aspect-[2/3] rounded-2xl" />
            ))}
          </div>
        ) : (
          <div className="space-y-10">
            <Rail title="🔥 Trending now" subtitle="Auto-fetched from Dailymotion's trending feed">
              {trending.slice(0, 20).map((v, i) => (
                <div key={v.id} className="w-[150px] shrink-0 snap-start sm:w-[172px]">
                  <PosterCard item={v} href={`/watch/${v.id}`} index={i} />
                </div>
              ))}
            </Rail>

            {hero ? (
              <div className="card anim-fade-up grid gap-5 overflow-hidden rounded-3xl p-5 md:grid-cols-[300px_1fr] md:p-7">
                <div className="overflow-hidden rounded-2xl">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={hero.thumbnail} alt={hero.title} className="aspect-[2/3] w-full object-cover" />
                </div>
                <div className="flex flex-col justify-center gap-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge tone="brand">{hero.category}</Badge>
                    <Badge>{formatDuration(hero.duration)}</Badge>
                    <Badge>{formatViews(hero.views)} views</Badge>
                    {premium ? <Badge tone="gold">Premium unlocked</Badge> : <Badge>Free preview</Badge>}
                  </div>
                  <h3 className="text-2xl font-black leading-tight text-white">{hero.title}</h3>
                  <p className="line-clamp-3 text-sm leading-relaxed text-white/45">{hero.description || "A brand new micro drama, dubbed in your language."}</p>
                  <div className="flex flex-wrap gap-2">
                    <Link href={`/watch/${hero.id}`} className="btn-brand rounded-full px-5 py-2.5 text-sm font-bold">
                      ▶ Play with dubbing
                    </Link>
                    <Link href="/subscribe" className="btn-ghost rounded-full px-5 py-2.5 text-sm font-bold">
                      Unlock all languages
                    </Link>
                  </div>
                </div>
              </div>
            ) : null}

            <Rail title="🆕 Fresh episodes" subtitle="Newest additions to the catalog">
              {newest.slice(0, 20).map((v, i) => (
                <div key={v.id} className="w-[150px] shrink-0 snap-start sm:w-[172px]">
                  <PosterCard item={v} href={`/watch/${v.id}`} index={i} />
                </div>
              ))}
            </Rail>

            {/* ---------------------- platform sections ---------------------- */}
            <div className="space-y-4 pt-2">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[11px] font-bold uppercase tracking-[0.2em] text-white/35">Browse by platform</span>
                {platformRails.map(({ platform, list }) => (
                  <span key={platform.key} className="rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-[11px] font-semibold text-white/60">
                    {platform.icon} {platform.label} · {list.length}
                  </span>
                ))}
              </div>
              {platformRails.map(({ platform, list }) => (
                <Rail
                  key={platform.key}
                  title={`${platform.icon} ${platform.label}`}
                  subtitle={`${platform.tagline} · ${list.length} titles`}
                >
                  {list.slice(0, 24).map((v, i) => (
                    <div key={v.id} className="w-[150px] shrink-0 snap-start sm:w-[172px]">
                      <PosterCard item={v} href={`/watch/${v.id}`} index={i} />
                    </div>
                  ))}
                </Rail>
              ))}
            </div>

            {groups.map(([cat, list]) => (
              <Rail key={cat} title={cat} subtitle={`${list.length} titles`}>
                {list.slice(0, 20).map((v, i) => (
                  <div key={v.id} className="w-[150px] shrink-0 snap-start sm:w-[172px]">
                    <PosterCard item={v} href={`/watch/${v.id}`} index={i} />
                  </div>
                ))}
              </Rail>
            ))}
          </div>
        )}
      </section>

      {/* ------------------------------ dub showcase ---------------------------- */}
      <section className="mt-16 space-y-6">
        <SectionTitle
          eyebrow="Dub Studio"
          title="Watch in your language. Really."
          desc="Every title ships with a studio-grade dubbing engine: multi-language voice tracks, per-character voices and karaoke-style word-by-word captions."
        />
        <div className="grid gap-4 md:grid-cols-3">
          {[
            {
              icon: "🎙️",
              t: "Multi-language audio dubbing",
              d: `Pick from ${langCount} languages — Hindi, Urdu, Spanish, Japanese, Chinese, Korean, Turkish, Arabic and more. Original audio is ducked automatically while the dub plays.`,
            },
            {
              icon: "💬",
              t: "Word-by-word captions",
              d: "Captions highlight each word exactly as it is spoken, in your chosen language, so you never lose the line.",
            },
            {
              icon: "🎭",
              t: "Character voices & presets",
              d: "Narrator, male lead, female lead and cinematic presets with per-speaker voice assignment — just like a professional dub.",
            },
          ].map((f, i) => (
            <div key={f.t} className="card anim-fade-up rounded-3xl p-6" style={{ animationDelay: `${i * 80}ms` }}>
              <div className="mb-3 grid h-11 w-11 place-items-center rounded-2xl bg-[var(--accent)]/15 text-xl">{f.icon}</div>
              <h3 className="mb-1.5 text-base font-bold text-white">{f.t}</h3>
              <p className="text-[13px] leading-relaxed text-white/45">{f.d}</p>
            </div>
          ))}
        </div>
        <div className="card flex flex-wrap items-center justify-center gap-2 rounded-3xl p-5">
          {(settings?.dubLanguages ?? []).map((code) => {
            const l = languageByCode(code);
            return (
              <span key={code} className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-medium text-white/70">
                {l?.flag} {l?.label}
              </span>
            );
          })}
        </div>
      </section>

      {/* ------------------------------- free steps ----------------------------- */}
      {channels.length ? (
        <section className="mt-16 space-y-5">
          <SectionTitle eyebrow="Free access" title="Watch free in 3 steps" desc="Complete the steps below and the whole platform unlocks for you." />
          <div className="grid gap-4 md:grid-cols-3">
            {channels.slice(0, 3).map((c, i) => (
              <a key={c.id} href={c.url} target="_blank" rel="noreferrer" className="card card-hover anim-fade-up block rounded-3xl p-6">
                <p className="mb-2 text-[11px] font-bold uppercase tracking-widest text-[var(--accent-soft)]">Step {i + 1}</p>
                <h3 className="mb-1.5 text-base font-bold text-white">{c.title}</h3>
                <p className="text-[13px] leading-relaxed text-white/45">{c.description}</p>
                <span className="mt-3 inline-flex items-center gap-1.5 text-xs font-bold text-[var(--accent-soft)]">Open ↗</span>
              </a>
            ))}
          </div>
          <div className="text-center">
            <Link href="/access" className="btn-brand inline-flex rounded-full px-6 py-3 text-sm font-bold">
              Complete the steps →
            </Link>
          </div>
        </section>
      ) : null}

      {/* -------------------------------- pricing ------------------------------- */}
      <section className="mt-16">
        <div className="card relative overflow-hidden rounded-3xl p-8 text-center sm:p-12">
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(600px_240px_at_50%_-10%,color-mix(in_srgb,var(--accent)_28%,transparent),transparent)]" />
          <div className="relative space-y-4">
            <Badge tone="gold">Limited launch pricing</Badge>
            <h2 className="text-3xl font-black tracking-tight text-white sm:text-4xl">
              {settings?.monthlyCurrency ?? "USD"} {settings?.monthlyPrice ?? "4.99"} <span className="text-lg font-semibold text-white/40">/ month</span>
            </h2>
            <p className="mx-auto max-w-xl text-sm text-white/50">
              Unlimited streaming, every dubbing language, word-by-word captions, no ads and priority access to new episodes.
            </p>
            <div className="flex flex-wrap justify-center gap-3 pt-2">
              <Link href="/subscribe" className="btn-brand rounded-full px-7 py-3 text-sm font-bold">
                Choose your country →
              </Link>
              <Link href="/access" className="btn-ghost rounded-full px-7 py-3 text-sm font-bold">
                Enter day code
              </Link>
            </div>
          </div>
        </div>
      </section>

      {loading ? (
        <div className="mt-8 flex justify-center">
          <Spinner />
        </div>
      ) : null}
    </div>
  );
}
