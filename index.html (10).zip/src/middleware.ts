import { NextResponse, type NextRequest } from "next/server";

const COOKIE = "steam_device";

/**
 * Stable per-viewer identity derived from the request fingerprint.
 *
 * In-app webviews (Instagram, TikTok, Facebook) and private browsing often drop
 * cookies. If we generated a random id on every request, a day pass or an
 * approved subscription would be written under one id and then read under
 * another — which is exactly what made access look like it never activated.
 * A deterministic fingerprint keeps the same key with or without cookies.
 */
function fingerprint(request: NextRequest): string {
  const ip = (request.headers.get("x-forwarded-for") ?? request.headers.get("x-real-ip") ?? "local")
    .split(",")[0]
    .trim();
  const ua = request.headers.get("user-agent") ?? "unknown";
  const accept = request.headers.get("accept-language") ?? "";
  const raw = `${ip}|${ua}|${accept}`;
  let h1 = 0x811c9dc5;
  let h2 = 0x01000193;
  for (let i = 0; i < raw.length; i++) {
    const code = raw.charCodeAt(i);
    h1 = Math.imul(h1 ^ code, 16777619) >>> 0;
    h2 = Math.imul(h2 ^ code, 2246822519) >>> 0;
  }
  return `fp_${h1.toString(36)}${h2.toString(36)}`;
}

export function middleware(request: NextRequest) {
  const existing = request.cookies.get(COOKIE)?.value;
  const id = existing ?? fingerprint(request);

  // Forward to the current request so server components read it immediately.
  const requestHeaders = new Headers(request.headers);
  const cookieHeader = requestHeaders.get("cookie");
  if (!existing) {
    requestHeaders.set("cookie", cookieHeader ? `${cookieHeader}; ${COOKIE}=${id}` : `${COOKIE}=${id}`);
  }

  const response = NextResponse.next({ request: { headers: requestHeaders } });
  if (!existing) {
    response.cookies.set(COOKIE, id, {
      httpOnly: false,
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 400,
    });
  }
  return response;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
