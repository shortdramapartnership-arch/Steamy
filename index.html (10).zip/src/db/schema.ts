import {
  boolean,
  integer,
  jsonb,
  numeric,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/** Single-row platform configuration (branding, codes, plans, app links, steps). */
export const settings = pgTable("settings", {
  id: text("id").primaryKey(),
  data: jsonb("data").notNull().default({}),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const videos = pgTable(
  "videos",
  {
    id: serial("id").primaryKey(),
    dmId: text("dm_id").notNull(),
    title: text("title").notNull(),
    description: text("description").default("").notNull(),
    thumbnail: text("thumbnail").default("").notNull(),
    url: text("url").default("").notNull(),
    duration: integer("duration").default(0).notNull(),
    owner: text("owner").default("").notNull(),
    category: text("category").default("Micro Drama").notNull(),
    /** Originating short-drama platform (reelshort, dramabox, flextv, …). */
    platform: text("platform").default("other").notNull(),
    tags: jsonb("tags").$type<string[]>().default([]).notNull(),
    language: text("language").default("en").notNull(),
    views: integer("views").default(0).notNull(),
    trendingScore: integer("trending_score").default(0).notNull(),
    featured: boolean("featured").default(false).notNull(),
    hidden: boolean("hidden").default(false).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("videos_dm_id_unique").on(table.dmId)],
);

export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  videoId: integer("video_id").notNull(),
  author: text("author").notNull(),
  body: text("body").notNull(),
  likes: integer("likes").default(0).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    provider: text("provider").default("google").notNull(),
    providerUid: text("provider_uid").default("").notNull(),
    email: text("email").default("").notNull(),
    name: text("name").default("").notNull(),
    picture: text("picture").default("").notNull(),
    lastDeviceId: text("last_device_id").default("").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    lastSeenAt: timestamp("last_seen_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("users_provider_uid_unique").on(table.provider, table.providerUid)],
);

/** Neural dub clips rendered by the Linly-Dubbing worker (Edge TTS). */
export const dubClips = pgTable("dub_clips", {
  hash: text("hash").primaryKey(),
  videoId: integer("video_id"),
  lang: text("lang").notNull(),
  voice: text("voice").notNull(),
  audio: text("audio").notNull(),
  durationMs: integer("duration_ms").default(0).notNull(),
  speed: text("speed").default("1").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const ttsCache = pgTable("tts_cache", {
  hash: text("hash").primaryKey(),
  lang: text("lang").default("en").notNull(),
  voice: text("voice").default("alloy").notNull(),
  audio: text("audio").notNull(),
  bytes: integer("bytes").default(0).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const accessGrants = pgTable("access_grants", {
  id: serial("id").primaryKey(),
  deviceId: text("device_id").notNull(),
  userId: integer("user_id"),
  kind: text("kind").notNull(), // daily_code | subscription | free_steps | promo
  label: text("label").default("").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  deviceId: text("device_id").notNull(),
  userId: integer("user_id"),
  countryCode: text("country_code").notNull(),
  countryName: text("country_name").default("").notNull(),
  methodKey: text("method_key").notNull(),
  methodLabel: text("method_label").default("").notNull(),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  currency: text("currency").notNull(),
  payerName: text("payer_name").notNull(),
  payerEmail: text("payer_email").default("").notNull(),
  transactionId: text("transaction_id").default("").notNull(),
  proofImage: text("proof_image").default("").notNull(),
  status: text("status").default("pending").notNull(), // pending | approved | rejected
  reviewNote: text("review_note").default("").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
});

export const paymentMethods = pgTable("payment_methods", {
  id: serial("id").primaryKey(),
  countryCode: text("country_code").notNull(),
  methodKey: text("method_key").notNull(),
  label: text("label").notNull(),
  icon: text("icon").default("💳").notNull(),
  address: text("address").default("").notNull(),
  accountName: text("account_name").default("").notNull(),
  /** Structured "where to pay" rows: [{ label, value }] */
  details: jsonb("details").$type<{ label: string; value: string }[]>().default([]).notNull(),
  instructions: text("instructions").default("").notNull(),
  amount: numeric("amount", { precision: 12, scale: 2 }).default("0").notNull(),
  currency: text("currency").default("USD").notNull(),
  active: boolean("active").default(true).notNull(),
  sortOrder: integer("sort_order").default(0).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const channels = pgTable("channels", {
  id: serial("id").primaryKey(),
  platform: text("platform").default("youtube").notNull(),
  title: text("title").notNull(),
  url: text("url").notNull(),
  handle: text("handle").default("").notNull(),
  thumbnail: text("thumbnail").default("").notNull(),
  description: text("description").default("").notNull(),
  stepOrder: integer("step_order").default(0).notNull(),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const dubTracks = pgTable("dub_tracks", {
  id: serial("id").primaryKey(),
  videoId: integer("video_id").notNull(),
  lang: text("lang").notNull(),
  source: text("source").default("auto").notNull(),
  cues: jsonb("cues").$type<DubCue[]>().default([]).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const fetchRuns = pgTable("fetch_runs", {
  id: serial("id").primaryKey(),
  kind: text("kind").default("auto").notNull(),
  queries: jsonb("queries").$type<string[]>().default([]).notNull(),
  found: integer("found").default(0).notNull(),
  added: integer("added").default(0).notNull(),
  ok: boolean("ok").default(true).notNull(),
  message: text("message").default("").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type DubCue = {
  start: number;
  end: number;
  speaker: string;
  text: string;
  translated?: string;
  words?: { w: string; t: number; d: number }[];
};

export type SettingsData = {
  platformName: string;
  logoUrl: string;
  tagline: string;
  heroHeadline: string;
  heroSubline: string;
  accent: string;
  dailyCode: string;
  dailyCodeActive: boolean;
  categories: string[];
  autoFetchEnabled: boolean;
  autoFetchQueries: string[];
  autoFetchLimit: number;
  monthlyPrice: number;
  monthlyCurrency: string;
  freePreviewSeconds: number;
  freeAccessSteps: { title: string; body: string; ctaLabel: string; ctaUrl: string; proofLabel: string }[];
  appLinks: { label: string; url: string; icon: string }[];
  dubLanguages: string[];
  dubCast: string;
  ttsProvider: "browser" | "openai" | "elevenlabs";
  ttsApiKey: string;
  ttsModel: string;
  ttsVoice: string;
  firebaseEnabled: boolean;
};

export type UserRow = typeof users.$inferSelect;
export type VideoRow = typeof videos.$inferSelect;
export type CommentRow = typeof comments.$inferSelect;
export type PaymentRow = typeof payments.$inferSelect;
export type PaymentDetail = { label: string; value: string };
export type PaymentMethodRow = typeof paymentMethods.$inferSelect;
export type ChannelRow = typeof channels.$inferSelect;
