import { drizzle, type NodePgDatabase } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

type DbClient = NodePgDatabase<Record<string, never>>;

const globalForDb = globalThis as typeof globalThis & {
  __steamPool?: Pool;
  __steamDb?: DbClient;
};

/**
 * The client is created on the first query, never at import time.
 *
 * `next build` evaluates route modules while collecting page data. If this
 * module threw on import when DATABASE_URL was absent, the build would fail on
 * hosts such as Netlify that compile without database credentials. Deferring
 * the check keeps `npm run build` environment-independent.
 */
function createDb(): DbClient {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    throw new Error(
      "DATABASE_URL is not set. Add it in Netlify under Site configuration → Environment variables (scoped to Builds and Functions), then redeploy.",
    );
  }
  if (!globalForDb.__steamPool) {
    globalForDb.__steamPool = new Pool({
      connectionString: databaseUrl,
      max: 5,
      idleTimeoutMillis: 30_000,
      connectionTimeoutMillis: 10_000,
    });
  }
  if (!globalForDb.__steamDb) {
    globalForDb.__steamDb = drizzle(globalForDb.__steamPool) as DbClient;
  }
  return globalForDb.__steamDb;
}

export function getDb(): DbClient {
  return createDb();
}

export function getPool(): Pool {
  createDb();
  return globalForDb.__steamPool as Pool;
}

/** True when a database is configured, without initialising a connection. */
export function hasDatabase(): boolean {
  return Boolean(process.env.DATABASE_URL);
}

/**
 * `db` behaves exactly like a Drizzle client, but only touches the environment
 * the first time a query is actually issued.
 */
export const db = new Proxy({} as DbClient, {
  get(_target, prop) {
    const client = createDb() as unknown as Record<string | symbol, unknown>;
    const value = client[prop];
    return typeof value === "function" ? (value as (...args: unknown[]) => unknown).bind(client) : value;
  },
}) as DbClient;
