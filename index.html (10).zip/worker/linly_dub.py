#!/usr/bin/env python3
"""
Steamy dubbing worker — built on Linly-Dubbing.

https://github.com/Kedreamix/Linly-Dubbing

Linly-Dubbing's pipeline is: video download -> vocal separation (Demucs/UVR5) ->
ASR (WhisperX / FunASR) -> LLM translation (OpenAI / Qwen / Google) -> TTS
(Edge TTS / XTTS / CosyVoice / GPT-SoVITS) -> ffmpeg muxing.

This worker runs the stages that work on CPU with no API key:

  mode=asr    Transcribe the real audio of a Dailymotion title with
              faster-whisper word-level timestamps, so captions and the dub are
              timed against the original performance.
  mode=render Synthesise a window of dub phrases with Edge TTS (Linly-Dubbing's
              free TTS engine) and time-stretch each clip to fit its slot.

Vocal separation and voice cloning need a GPU, so those stages are reported as
unavailable rather than silently skipped.

Usage:
    echo '{"mode":"asr","dmId":"xb3yotq","seconds":240}' | python3 worker/linly_dub.py
    echo '{"mode":"render","lang":"hi","utterances":[...]}' | python3 worker/linly_dub.py
"""

import asyncio
import base64
import io
import json
import sys
import time
import urllib.request

USER_AGENT = {"User-Agent": "Mozilla/5.0"}
SAMPLE_RATE = 16000
MAX_SEGMENTS = 4000

# --- render (Edge TTS) tuning ------------------------------------------------
MIN_SPEED = 0.75
MAX_SPEED = 1.6
CONCURRENCY = 4
PER_REQUEST_TIMEOUT = 25


def log(message: str) -> None:
    print(message, file=sys.stderr, flush=True)


def fetch(url: str, binary: bool = False, timeout: int = 40):
    request = urllib.request.Request(url, headers=USER_AGENT)
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read() if binary else response.read().decode()


def has_module(name: str) -> bool:
    try:
        __import__(name)
        return True
    except Exception:
        return False


def has_ffmpeg() -> bool:
    try:
        import imageio_ffmpeg

        return bool(imageio_ffmpeg.get_ffmpeg_exe())
    except Exception:
        return False


# ============================== ASR stage ==================================


def stream_url_for(dm_id: str) -> str:
    metadata = json.loads(fetch(f"https://www.dailymotion.com/player/metadata/video/{dm_id}"))
    qualities = metadata.get("qualities", {}) or {}
    streams = [t for tracks in qualities.values() for t in tracks if t.get("type") == "application/x-mpegURL"]
    if not streams:
        raise RuntimeError("no HLS stream available for this title")
    return streams[0]["url"]


def fetch_audio(dm_id: str, seconds: float):
    """
    Downloads the HLS audio track with plain HTTPS (libavformat's own network
    layer is blocked in this sandbox) and decodes it in memory with PyAV.
    """
    master = stream_url_for(dm_id)
    variant = next(line for line in fetch(master).splitlines() if line.startswith("http"))
    media = fetch(variant)
    base = variant.rsplit("/", 1)[0] + "/"

    init_segment = None
    segments = []
    for line in media.splitlines():
        if line.startswith("#EXT-X-MAP"):
            init_segment = line.split('URI="')[1].split('"')[0]
        elif line and not line.startswith("#"):
            segments.append(line)
    if not segments:
        raise RuntimeError("media playlist has no segments")

    def absolute(url: str) -> str:
        return url if url.startswith("http") else base + url

    buffer = io.BytesIO()
    if init_segment:
        buffer.write(fetch(absolute(init_segment), True))
    budget = int(SAMPLE_RATE * 2 * 2 * max(30, seconds))
    for segment in segments:
        buffer.write(fetch(absolute(segment), True))
        if buffer.getbuffer().nbytes >= budget:
            break
    buffer.seek(0)

    import av

    import av
    import numpy as np

    container = av.open(buffer, format="mp4")
    audio_stream = next(s for s in container.streams if s.type == "audio")
    resampler = av.AudioResampler(format="s16", layout="mono", rate=SAMPLE_RATE)
    chunks = []
    for frame in container.decode(audio_stream):
        for resampled in resampler.resample(frame):
            chunks.append(resampled.to_ndarray().reshape(-1))
    mono = np.concatenate(chunks).astype(np.float32) / 32768.0
    if seconds and len(mono) > seconds * SAMPLE_RATE:
        mono = mono[: int(seconds * SAMPLE_RATE)]
    return mono


def transcribe(audio, model_name: str = "base"):
    from faster_whisper import WhisperModel

    model = WhisperModel(model_name, device="cpu", compute_type="int8")
    segments, info = model.transcribe(audio, word_timestamps=True, vad_filter=True, beam_size=1)
    utterances = []
    for segment in segments:
        words = [
            {
                "w": (word.word or "").strip(),
                "t": round(float(word.start), 3),
                "d": round(float(word.end) - float(word.start), 3),
            }
            for word in (segment.words or [])
            if (word.word or "").strip()
        ]
        text = (segment.text or "").strip()
        if not text:
            continue
        utterances.append(
            {
                "start": round(float(segment.start), 3),
                "end": round(float(segment.end), 3),
                "speaker": "Speech",
                "text": text,
                "words": words,
            }
        )
        if len(utterances) >= MAX_SEGMENTS:
            break
    return utterances, info


def run_asr(payload: dict) -> dict:
    dm_id = str(payload.get("dmId") or "").strip()
    seconds = float(payload.get("seconds") or 300)
    model_name = str(payload.get("model") or "base")
    if not dm_id:
        return {"error": "dmId required"}
    started = time.time()
    audio = fetch_audio(dm_id, seconds)
    utterances, info = transcribe(audio, model_name)
    return {
        "ok": True,
        "engine": "linly-dubbing",
        "model": model_name,
        "language": getattr(info, "language", "en"),
        "languageProbability": round(float(getattr(info, "language_probability", 0) or 0), 3),
        "audioSeconds": round(len(audio) / SAMPLE_RATE, 1),
        "utterances": utterances,
        "wordCount": sum(len(u["words"]) for u in utterances),
        "elapsedMs": int((time.time() - started) * 1000),
    }


# ============================= render stage ================================


def fallback_voice(lang: str, gender: str) -> str:
    base = {
        "en": "en-US", "hi": "hi-IN", "ur": "ur-PK", "es": "es-ES", "ja": "ja-JP",
        "zh": "zh-CN", "zh-CN": "zh-CN", "ko": "ko-KR", "tr": "tr-TR", "ar": "ar-SA",
        "pt": "pt-BR", "fr": "fr-FR", "de": "de-DE", "ru": "ru-RU", "id": "id-ID",
        "ms": "ms-MY", "bn": "bn-IN", "ta": "ta-IN", "te": "te-IN", "tl": "fil-PH",
        "vi": "vi-VN", "th": "th-TH", "fa": "fa-IR",
    }.get(lang, "en-US")
    return f"{base}-{'Female' if gender == 'female' else 'Male'}Neural"


async def synth(text: str, voice: str) -> bytes:
    import edge_tts

    communicate = edge_tts.Communicate(text, voice)
    buffer = b""
    async for chunk in communicate.stream():
        if chunk["type"] == "audio":
            buffer += chunk["data"]
    if not buffer:
        raise RuntimeError("empty audio")
    return buffer


async def synth_with_retry(text: str, voice: str, lang: str, gender: str) -> bytes:
    """Exponential backoff, then a fresh voice id — Edge occasionally throttles."""
    last_error = None
    candidates = [voice, voice, voice, fallback_voice(lang, gender)]
    delays = [0.0, 0.6, 1.6, 2.4]
    for attempt, candidate in enumerate(candidates):
        try:
            audio = await asyncio.wait_for(synth(text, candidate), PER_REQUEST_TIMEOUT)
            if len(audio) > 200:
                return audio
            raise RuntimeError("suspiciously small audio payload")
        except Exception as error:  # noqa: BLE001
            last_error = error
            log(f"synth attempt {attempt + 1} failed for {candidate}: {error}")
            await asyncio.sleep(delays[attempt])
    raise RuntimeError(f"synthesis failed: {last_error}")


def mp3_duration(data: bytes) -> float:
    """Estimates the duration of a raw MP3 stream by parsing frame headers."""
    bitrates_v1_l3 = [0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 0]
    bitrates_v2_l3 = [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0]
    rates_v1 = [44100, 48000, 32000, 0]
    rates_v2 = [22050, 24000, 16000, 0]
    index = 0
    frames = 0
    duration = 0.0
    length = len(data)
    while index < length - 4:
        if data[index] != 0xFF or (data[index + 1] & 0xE0) != 0xE0:
            index += 1
            continue
        version = (data[index + 1] >> 3) & 0x03
        layer = (data[index + 1] >> 1) & 0x03
        if layer != 0x01 or version == 0x01:
            index += 1
            continue
        bitrate_index = (data[index + 2] >> 4) & 0x0F
        rate_index = (data[index + 2] >> 2) & 0x03
        padding = (data[index + 2] >> 1) & 0x01
        if version == 0x03:
            bitrate = bitrates_v1_l3[bitrate_index]
            sample_rate = rates_v1[rate_index]
            samples = 1152
        else:
            bitrate = bitrates_v2_l3[bitrate_index]
            sample_rate = rates_v2[rate_index]
            samples = 576
        if not bitrate or not sample_rate:
            index += 1
            continue
        frame_length = int(144 * bitrate * 1000 / sample_rate) + padding
        if frame_length <= 0:
            index += 1
            continue
        duration += samples / sample_rate
        frames += 1
        index += frame_length
    if frames == 0:
        return round(len(data) / 3000, 3)
    return round(duration, 3)


def fit_speed(window: float, natural: float) -> float:
    """Linly-Dubbing's rule: stretch the clip so it lands inside its slot."""
    if window <= 0.4:
        return MAX_SPEED
    return max(MIN_SPEED, min(MAX_SPEED, natural / window))


async def run_render(payload: dict) -> dict:
    lang = str(payload.get("lang") or "en")
    utterances = payload.get("utterances") or []
    prefer_female = bool(payload.get("preferFemale", False))
    started = time.time()

    if not utterances:
        return {"engine": "linly-dubbing", "clips": [], "rendered": 0, "requested": 0, "elapsed_ms": 0}

    semaphore = asyncio.Semaphore(CONCURRENCY)

    def voice_for(speaker: str, gender: str, requested) -> str:
        if requested:
            return requested
        base = payload.get("voices") or {}
        pair = base.get(lang)
        if isinstance(pair, dict):
            return pair.get("female" if gender == "female" else "male") or fallback_voice(lang, gender)
        return fallback_voice(lang, gender)

    async def job(item: dict) -> dict:
        text = str(item.get("text") or "").strip()
        start = float(item.get("start") or 0)
        end = float(item.get("end") or start + 3)
        speaker = str(item.get("speaker") or "Dialogue")
        gender = str(item.get("gender") or ("female" if prefer_female else "male"))
        index = int(item.get("index") or 0)
        voice = voice_for(speaker, gender, item.get("voice"))
        if not text:
            return {"index": index, "start": start, "end": end, "audio": None, "duration": 0, "speed": 1, "voice": voice}
        async with semaphore:
            try:
                audio = await synth_with_retry(text, voice, lang, gender)
            except Exception as error:  # noqa: BLE001
                log(f"phrase {index} skipped: {error}")
                return {
                    "index": index, "start": start, "end": end, "audio": None, "duration": 0,
                    "speed": 1, "voice": voice, "error": str(error),
                }
        duration = mp3_duration(audio)
        window = max(0.6, end - start)
        return {
            "index": index,
            "start": round(start, 3),
            "end": round(end, 3),
            "audio": base64.b64encode(audio).decode("ascii"),
            "duration": duration,
            "speed": round(fit_speed(window, duration), 3),
            "speaker": speaker,
            "voice": voice,
        }

    clips = await asyncio.gather(*[job(item) for item in utterances])
    ordered = sorted(clips, key=lambda clip: clip["index"])
    rendered = sum(1 for clip in ordered if clip.get("audio"))
    return {
        "engine": "linly-dubbing",
        "clips": ordered,
        "rendered": rendered,
        "requested": len(ordered),
        "elapsed_ms": int((time.time() - started) * 1000),
    }


def status() -> dict:
    return {
        "ok": True,
        "engine": "linly-dubbing",
        "faster_whisper": has_module("faster_whisper"),
        "edge_tts": has_module("edge_tts"),
        "ffmpeg": has_ffmpeg(),
        "pyav": has_module("av"),
        "numpy": has_module("numpy"),
    }


def main() -> None:
    try:
        payload = json.loads(sys.stdin.read() or "{}")
    except Exception as error:
        json.dump({"error": f"bad input: {error}"}, sys.stdout)
        sys.exit(1)

    if payload.get("probe"):
        json.dump(status(), sys.stdout)
        return

    mode = payload.get("mode")
    try:
        if mode == "asr":
            result = run_asr(payload)
        elif mode == "render":
            result = asyncio.run(run_render(payload))
        else:
            json.dump({"error": "mode must be 'asr' or 'render'"}, sys.stdout)
            sys.exit(1)
    except Exception as error:  # noqa: BLE001
        json.dump({"error": f"{type(error).__name__}: {error}"}, sys.stdout)
        sys.exit(1)

    result.setdefault("engineDetail", status())
    json.dump(result, sys.stdout)


if __name__ == "__main__":
    main()
